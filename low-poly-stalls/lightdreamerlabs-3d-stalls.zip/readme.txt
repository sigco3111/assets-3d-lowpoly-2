

LICENSE INFO (CC0 1.0 Universal)

Thank you for using these 3D assets!

Allowed:
- Commercial and non-commercial use (games, films, apps, etc.).

Prohibited:
- Reselling or redistributing the original or modified source files.
- Claiming ownership or re-packaging as part of another asset store collection.


LightDreamer Labs
https://lightdreamerlabs.itch.io/