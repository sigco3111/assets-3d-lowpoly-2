AbilityCastingThreeJS (Elemental Sandbox) 자작 확인 3D 모델 6종 + 결투장 텍스처 + 환경 HDRI

models/
  duel_hall.glb          결투장 환경 (텍스처 미내장, 머티리얼은 원본 src/world 참고)
  wolf.glb               늑대, 리그 + 클립 6종 (01_Run, 02_walk, 03_creep, 04_Idle, 05_site, Gallop)
  shark.glb              백상어, 전용 클립 Breach/Swim
  arcane_tome.glb        마법서
  wildroot_reliquary.glb 뿌리 아치와 룬스톤
  amethyst_stones.glb    자수정 결정 5종
textures/
  cloth_color.jpg / cloth_orm.png / cloth_emissive.jpg  결투장 천 게임용 텍스처
  T_DuelCloth_Color.png / T_DuelCloth_Mask.png / T_DuelCloth_Color_day.png  원본 작업 텍스처
env/
  spruit_sunrise.hdr     Poly Haven Spruit Sunrise 2K, Greg Zaal, CC0 (https://polyhaven.com/a/spruit_sunrise)

제외: dragon.glb, magical_gyroscope.glb (Sketchfab 서드파티, 원라이선스 불명),
Mixamo FBX 4종과 diffuse.png (재배포 금지), cathedral/배너/스테인드글라스/rune_glow 텍스처 (출처 미확인).
Blender 원본(.blend)은 원본 저장소 art/ 에 있습니다 (duel_hall, duel_hall_day, wolf).
원본: https://github.com/achrefelouafi/AbilityCastingThreeJS (MIT)
