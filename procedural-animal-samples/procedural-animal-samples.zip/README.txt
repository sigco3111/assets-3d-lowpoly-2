Procedural Animals 샘플 (.animal 베이크 파일 6종)

threejs-procedural-animals(MIT)의 베이크 도구로 생성한 개체 샘플입니다.
프로젝트에서 즉시 로드해 쓰는 파일이며, 로드에는 같은 라이브러리가 필요합니다:
  createAnimal('wolf', { baked: await (await fetch('wolf.animal')).arrayBuffer() })

종/시드/품질: wolf, horse, eagle, shark, snake, spider / seed 3 / quality high
라이선스: MIT (Copyright (c) 2026 Majid Manzarpour and procedural-animals contributors) - LICENSE 파일 참조
코드 팩: sigco3111/assets-code 저장소 procedural-animals-threejs
원본: https://github.com/majidmanzarpour/threejs-procedural-animals
