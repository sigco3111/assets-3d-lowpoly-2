Lowpoly Tree 샘플 모델 6종 (GLB)

Rand Monster contributors의 MIT 라이선스 생성기(lowpoly-tree-generator)로 2026-11-23 생성한 샘플 나무 모델입니다.
생성기 코드: https://github.com/pajama-studio/lowpoly-tree-generator (코드 팩: assets-code lowpoly-tree-generator)
라이선스: MIT (Copyright (c) 2026 Rand Monster contributors) — LICENSE 동봉, 재배포 시 저작권 표기와 MIT 전문 유지.
버텍스 컬러, 텍스처 없음. 덩굴(vines)이 켜진 아키타입은 덩굴 메시 포함.

모델(삼각형 수):
- ancientGuardian: 1708
- forkedShrine: 1480
- groveBloom: 1312
- stormClaw: 1012
- weepingLantern: 1694
- windCrownedSentinel: 705
