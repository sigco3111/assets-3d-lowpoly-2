AbilityCastingThreeJS (Elemental Sandbox) 권리 미확인 모델·텍스처

models/
  shark.glb              백상어, 클립 Breach/Swim (Blender 내보내기 메타뿐 자작 명시 근거 없음)
  dragon.glb             드래곤 (GLB 메타데이터: Sketchfab 다운로드)
  magical_gyroscope.glb  마법 자이로스코프, 클립 gyro_spin·gyro rune enchanting (GLB 메타데이터: Sketchfab 다운로드)
textures/
  cathedral-color/normal/roughness/ao.jpg  대성당 PBR 4종 (출처 미확인)
  banner_amber/crimson/emerald/sapphire.jpg, stained_glass.jpg, rune_glow.jpg  결투장 장식 (출처 미확인)

주의: 원본 저장소 README는 "HDR probe·캐릭터 FBX·서드파티 모델은 원라이선스 유지"라고만 명시하고
개별 라이선스를 밝히지 않습니다. 재사용 허락 미확인이므로 사용 전 원권리자 확인이 필요하고,
권리자 요청 시 즉시 내립니다. Mixamo 캐릭터 FBX 4종과 diffuse.png는 재배포 금지라 수집하지 않았습니다.
원본: https://github.com/achrefelouafi/AbilityCastingThreeJS
