# Small helpers for building the ship in Blender from a script (see build.py).
#
# Everything is in metres. The ship stands at the origin on its feet, +Z up, its window toward +Y, its right +X
# (exported, that is +Y up and the window toward -Z, as the game has it). Angles round the ship ("theta") are
# measured from the front, toward the right.
import bpy, bmesh, random
from math import sin, cos, pi, radians as rad, sqrt, atan2, hypot
from mathutils import Matrix, Vector, Color

I4 = Matrix.Identity(4)
COL = {}


def collections(names):
    for n in names:
        c = bpy.data.collections.new(n)
        bpy.context.scene.collection.children.link(c)
        COL[n] = c


def lin(h):
    f = lambda c: c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    return tuple(f(int(h[i:i + 2], 16) / 255) for i in (1, 3, 5))


def at(theta, r, z):
    """The frame at a place on the wall: its +Y points outward, its +X along the wall, to the right of someone inside looking out."""
    return Matrix.Rotation(-theta, 4, 'Z') @ Matrix.Translation((0, r, z))


def T(x, y, z): return Matrix.Translation((x, y, z))
def R(a, axis): return Matrix.Rotation(a, 4, axis)
def S(x, y, z): return Matrix.Diagonal((x, y, z, 1))


def aim(frm, to, up=Vector((0, 0, 1))):
    """A frame at `frm` whose +Z points at `to`."""
    z = (Vector(to) - Vector(frm)).normalized()
    x = up.cross(z)
    x = x.normalized() if x.length > 1e-5 else Vector((1, 0, 0))
    y = z.cross(x)
    m = Matrix((x, y, z)).transposed().to_4x4()
    m.translation = Vector(frm)
    return m


# ------------------------------------------------------------------------------------------------ shapes (bmesh)
def box(sx, sy, sz, o=(0, 0, 0)):
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)
    bmesh.ops.scale(bm, vec=(sx, sy, sz), verts=bm.verts)
    bmesh.ops.translate(bm, vec=o, verts=bm.verts)
    return bm


def cyl(r, h, n=20, r2=None, o=(0, 0, 0)):
    """Along Z, centred."""
    bm = bmesh.new()
    bmesh.ops.create_cone(bm, cap_ends=True, cap_tris=False, segments=n, radius1=r, radius2=r if r2 is None else r2, depth=h)
    bmesh.ops.translate(bm, vec=o, verts=bm.verts)
    return bm


def ball(r, n=20, m=12, s=(1, 1, 1), o=(0, 0, 0)):
    bm = bmesh.new()
    bmesh.ops.create_uvsphere(bm, u_segments=n, v_segments=m, radius=r)
    bmesh.ops.scale(bm, vec=s, verts=bm.verts)
    bmesh.ops.translate(bm, vec=o, verts=bm.verts)
    return bm


def lathe(prof, n=48, a0=0.0, a1=2 * pi, close=False):
    """Turns a profile [(r, z)] about Z, from theta a0 to a1. close: the profile is a closed outline (a ring, a slab)."""
    bm = bmesh.new()
    bm.loops.layers.uv.new('UVMap'); bm.loops.layers.uv.new('grain'); g = bm.loops.layers.uv['grain']
    full = abs((a1 - a0) - 2 * pi) < 1e-6
    k = n if full else n + 1
    cols = []
    for i in range(k):
        a = a0 + (a1 - a0) * i / n
        cols.append([bm.verts.new((r * sin(a), r * cos(a), z)) for r, z in prof])
    m = len(prof)
    rmax = max(r for r, z in prof)
    S = [0.0]
    for j in range(m): S.append(S[-1] + hypot(prof[(j + 1) % m][0] - prof[j][0], prof[(j + 1) % m][1] - prof[j][1]))
    along = max(hypot(prof[j][0] - prof[0][0], prof[j][1] - prof[0][1]) for j in range(m)) > (a1 - a0) * rmax
    for i in range(n):
        A, B = cols[i], cols[(i + 1) % k]
        for j in range(m if close else m - 1):
            j2 = (j + 1) % m
            try: f = bm.faces.new((A[j], A[j2], B[j2], B[j]))
            except ValueError: continue
            for l, (ii, jj) in zip(f.loops, ((i, j), (i, j + 1), (i + 1, j + 1), (i + 1, j))):
                # (the grain runs the long way of it: round, for a hoop; along, for a board laid like a spoke)
                u, v = (a0 + (a1 - a0) * ii / n) * rmax, S[jj]
                l[g].uv = (v, 1 - u) if along else (u, 1 - v)
    if close and not full:
        bm.faces.new(cols[0]); bm.faces.new(list(reversed(cols[-1])))
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-5)
    for f in [f for f in bm.faces if f.calc_area() < 1e-9]: bm.faces.remove(f)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    return bm


def slab(r0, r1, z0, z1, a0, a1, n=24):
    """A piece of a flat ring: a curved shelf, a hoop, a desk top."""
    return lathe([(r0, z0), (r1, z0), (r1, z1), (r0, z1)], n, a0, a1, close=True)


def crom(P, sub, cyclic=False):
    out, m = [], len(P)
    for i in range(m if cyclic else m - 1):
        p0 = P[(i - 1) % m] if (cyclic or i > 0) else P[i] * 2 - P[i + 1]
        p1, p2 = P[i], P[(i + 1) % m]
        p3 = P[(i + 2) % m] if (cyclic or i < m - 2) else P[i + 1] * 2 - P[i]
        for s in range(sub):
            t = s / sub
            out.append(0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t * t + (-p0 + 3 * p1 - 3 * p2 + p3) * t * t * t))
    if not cyclic: out.append(P[-1].copy())
    return out


def tube(pts, r, n=8, sub=4, cyclic=False):
    """A pipe through points. r: its radius, or a rule for it along the way (0 to 1)."""
    P = [Vector(p) for p in pts]
    if sub > 1 and len(P) > 2: P = crom(P, sub, cyclic)
    m = len(P)
    bm = bmesh.new()
    bm.loops.layers.uv.new('UVMap'); bm.loops.layers.uv.new('grain'); g = bm.loops.layers.uv['grain']
    Ls = [0.0]
    for i in range(m): Ls.append(Ls[-1] + (P[(i + 1) % m] - P[i]).length)
    tan = []
    for i in range(m):
        a = P[(i - 1) % m] if (cyclic or i > 0) else P[i]
        b = P[(i + 1) % m] if (cyclic or i < m - 1) else P[i]
        tan.append((b - a).normalized())
    nrm = tan[0].orthogonal().normalized()
    rings = []
    for i in range(m):
        t = tan[i]
        nrm = (nrm - t * nrm.dot(t)).normalized()
        bn = t.cross(nrm)
        rr = r(i / (m - 1)) if callable(r) else r
        rings.append([bm.verts.new(P[i] + (nrm * cos(2 * pi * k / n) + bn * sin(2 * pi * k / n)) * rr) for k in range(n)])
    for i in range(m if cyclic else m - 1):
        A, B = rings[i], rings[(i + 1) % m]
        rr = r(i / (m - 1)) if callable(r) else r
        for k in range(n):
            f = bm.faces.new((A[k], A[(k + 1) % n], B[(k + 1) % n], B[k]))
            for l, (ii, kk) in zip(f.loops, ((i, k), (i, k + 1), (i + 1, k + 1), (i + 1, k))): l[g].uv = (Ls[ii], 1 - 2 * pi * rr * kk / n)
    if not cyclic:
        bm.faces.new(list(reversed(rings[0]))); bm.faces.new(rings[-1])
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    return bm


def sheet(nu, nv, fn, thick=0.0):
    """A cloth: fn(u, v) -> (x, y, z) for u, v in 0..1."""
    bm = bmesh.new()
    V = [[bm.verts.new(fn(i / nu, j / nv)) for j in range(nv + 1)] for i in range(nu + 1)]
    for i in range(nu):
        for j in range(nv): bm.faces.new((V[i][j], V[i + 1][j], V[i + 1][j + 1], V[i][j + 1]))
    if thick:
        bmesh.ops.solidify(bm, geom=bm.faces[:], thickness=thick)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    return bm


def plane(w, h, cell=None):
    """In its own XZ, facing -Y; u runs along +X and v along +Z. cell: (u0, v0, u1, v1), where in a sheet of prints it shows (v up)."""
    bm = bmesh.new()
    vs = [bm.verts.new(p) for p in ((-w / 2, 0, -h / 2), (w / 2, 0, -h / 2), (w / 2, 0, h / 2), (-w / 2, 0, h / 2))]
    f = bm.faces.new(vs)
    bm.loops.layers.uv.new('UVMap'); bm.loops.layers.uv.new('grain')
    uv, g = bm.loops.layers.uv['UVMap'], bm.loops.layers.uv['grain']
    u0, v0, u1, v1 = cell or (0, 0, 1, 1)
    for l, c in zip(f.loops, ((0, 0), (1, 0), (1, 1), (0, 1))):
        l[uv].uv = c
        l[g].uv = (u0 + (u1 - u0) * c[0], 1 - (v0 + (v1 - v0) * c[1]))
    return bm


def disc(r, n=24, cell=None):
    """A round print, facing -Y in its own XZ."""
    bm = bmesh.new()
    bm.loops.layers.uv.new('UVMap'); bm.loops.layers.uv.new('grain'); g = bm.loops.layers.uv['grain']
    u0, v0, u1, v1 = cell or (0, 0, 1, 1)
    f = bm.faces.new([bm.verts.new((r * cos(2 * pi * i / n), 0, r * sin(2 * pi * i / n))) for i in range(n)])
    for l in f.loops: l[g].uv = (u0 + (u1 - u0) * (0.5 + 0.5 * l.vert.co.x / r), 1 - (v0 + (v1 - v0) * (0.5 + 0.5 * l.vert.co.z / r)))
    bm.normal_update()
    if f.normal.y > 0: f.normal_flip()
    return bm


# ------------------------------------------------------------------------------------------------------- parts
# What a piece can be made of: the game paints each in its own way (shipPaint in src/ship.js has the same numbers).
KINDS = {n: i for i, n in enumerate(('paint', 'wood', 'pwood', 'copper', 'brass', 'iron', 'cloth', 'leather', 'rope', 'paper', 'enamel', 'rubber', 'lamp', 'stripe', 'quilt', 'steel', 'glaze', 'soot'))}
KINDS.update({'canvas': 18, 'glassy': 19, 'wicker': 26, 'knit': 27, 'tin': 28})
KINDS.update({'push_right': 20, 'push_left': 21, 'push_up': 22, 'push_down': 23, 'push_fwd': 24, 'push_back': 25})
KINDS.update({'lit%d' % i: 30 + i for i in range(8)})
KINDS.update({'print': 40, 'dial': 41})
BYCOL = {}      # '#rrggbb' -> what a piece of that colour is made of, unless it says otherwise


def part(bm, col, grp='out', M=I4, bevel=0.008, gloss=0.0, glow=0.0, jit=0.05, seg=2, name='p', cuts=None, sharp=48, mat=None, val=None, tag=None, rough=0.0, grit=6.0, sub=0):
    """
    Makes a piece of the ship of a shape. col: '#rrggbb', or a rule (where a face is, in the ship) -> '#rrggbb'.
    gloss 0..0.8: how much it shines (metal). glow: how brightly it shines of itself (a lamp), 0..10.
    cuts: heights (in the ship) to cut the shape at first, so a rule for colour has clean edges to follow.
    mat: what it is made of (KINDS), if its colour does not say. val: a number that kind reads (a bead's place in
    its row); otherwise one drawn by lot, so that no two boards are alike. tag: pieces with the same tag are taken
    out afterward as a thing of their own, to be moved in the game.
    rough: metres by which every corner of it is pushed about, smoothly (grit: how many lumps to a metre), so that
    nothing soft or beaten is a clean shape; sub: cut every edge so many times first, to give that something to move.
    (Only for things nothing is fixed to: what sits on a face that has been pushed about no longer sits on it.)
    """
    if cuts:
        inv = M.inverted()
        for z in cuts:
            bmesh.ops.bisect_plane(bm, geom=bm.verts[:] + bm.edges[:] + bm.faces[:], plane_co=inv @ Vector((0, 0, z)), plane_no=(inv.to_3x3() @ Vector((0, 0, 1))).normalized())
    if bevel > 0:
        bm.normal_update()
        es = [e for e in bm.edges if len(e.link_faces) == 2 and e.calc_face_angle(0) > rad(40)]
        if es: bmesh.ops.bevel(bm, geom=es, offset=bevel, segments=seg, profile=0.5, affect='EDGES', clamp_overlap=True)
    if sub: bmesh.ops.subdivide_edges(bm, edges=bm.edges[:], cuts=sub, use_grid_fill=True)
    if rough:
        from mathutils import noise
        o = Vector((random.uniform(0, 50), random.uniform(0, 50), random.uniform(0, 50))); Ri = M.to_3x3().inverted()
        for v in bm.verts: v.co += Ri @ (noise.noise_vector((M @ v.co) * grit + o) * rough)
    bm.normal_update()
    for f in bm.faces: f.smooth = True
    for e in bm.edges:
        if len(e.link_faces) == 2 and e.calc_face_angle(0) > rad(sharp): e.smooth = False
    # three sheets of places on it: where its light is kept (worked out later), how its grain runs, what it is made of
    if bm.loops.layers.uv.get('UVMap') is None: bm.loops.layers.uv.new('UVMap')
    own = bm.loops.layers.uv.get('grain') is not None
    if not own: bm.loops.layers.uv.new('grain')
    bm.loops.layers.uv.new('kind')
    if not own and bm.verts:
        # (the grain runs the long way of the piece, on every face of it)
        g = bm.loops.layers.uv['grain']
        lo = [min(v.co[i] for v in bm.verts) for i in range(3)]; hi = [max(v.co[i] for v in bm.verts) for i in range(3)]
        order = sorted(range(3), key=lambda i: lo[i] - hi[i])
        ou, ov = random.uniform(0, 7), random.uniform(0, 3)
        for f in bm.faces:
            A = max(range(3), key=lambda i: abs(f.normal[i]))
            ua, va = [i for i in order if i != A]
            for l in f.loops: l[g].uv = (l.vert.co[ua] + ou, 1 - (l.vert.co[va] + ov))
    me = bpy.data.meshes.new(name)
    bm.to_mesh(me); bm.free()
    rnd = random.random() if val is None else val
    def made(h):
        if mat: return KINDS[mat]
        if glow > 0: return KINDS['lamp']
        k = BYCOL.get(h)
        return KINDS[k] if k else KINDS['steel'] if gloss >= 0.45 else KINDS['paint']
    j = (random.uniform(-jit, jit), random.uniform(-jit, jit), random.uniform(-jit, jit))
    a = 0.9 + 0.01 * min(glow, 10) if glow > 0 else min(gloss, 0.8)
    def shade(h):
        c = Color(lin(h))
        hh, ss, vv = c.hsv
        c.hsv = ((hh + j[0] * 0.12) % 1.0, max(0, min(1, ss * (1 + j[1]))), max(0, vv * (1 + j[2])))
        return (c.r, c.g, c.b, a)
    data, kinds = [], []
    if callable(col):
        for p in me.polygons:
            h = col(M @ p.center)
            data += shade(h) * p.loop_total
            kinds += (made(h), 1 - rnd) * p.loop_total
    else:
        data = shade(col) * len(me.loops)
        kinds = (made(col), 1 - rnd) * len(me.loops)
    attr = me.color_attributes.new('Col', 'FLOAT_COLOR', 'CORNER')
    attr.data.foreach_set('color', data)
    me.uv_layers['kind'].data.foreach_set('uv', kinds)
    ob = bpy.data.objects.new(name, me)
    ob.matrix_world = M
    if tag: ob.vertex_groups.new(name=tag).add(range(len(me.vertices)), 1.0, 'REPLACE')
    COL[grp].objects.link(ob)
    return ob


def take(ob, tag, name, origin=I4):
    """Takes the pieces with a tag out of a joined thing, as a thing of their own with its own origin."""
    if tag not in ob.vertex_groups: return None
    for x in bpy.context.view_layer.objects: x.select_set(x is ob)
    bpy.context.view_layer.objects.active = ob
    before = set(bpy.context.view_layer.objects)
    bpy.ops.object.mode_set(mode='EDIT'); bpy.ops.mesh.select_mode(type='VERT'); bpy.ops.mesh.select_all(action='DESELECT')
    ob.vertex_groups.active_index = ob.vertex_groups[tag].index
    bpy.ops.object.vertex_group_select(); bpy.ops.mesh.separate(type='SELECTED')
    bpy.ops.object.mode_set(mode='OBJECT')
    new = [x for x in bpy.context.view_layer.objects if x not in before][0]
    new.name = name; new.data.name = name
    new.data.transform(origin.inverted() @ new.matrix_world); new.matrix_world = origin
    return new


def join(grp, name, origin=I4):
    """Makes one thing of every piece in a group, its own origin at `origin`."""
    obs = list(COL[grp].objects)
    if not obs: return None
    bpy.context.view_layer.update()
    with bpy.context.temp_override(active_object=obs[0], object=obs[0], selected_objects=obs, selected_editable_objects=obs):
        bpy.ops.object.join()
    ob = obs[0]
    ob.name = name; ob.data.name = name
    bpy.context.view_layer.update()
    ob.data.transform(origin.inverted() @ ob.matrix_world)
    ob.matrix_world = origin
    return ob


def ang(a):
    while a > pi: a -= 2 * pi
    while a < -pi: a += 2 * pi
    return a
