# What the ship's builders share: its colours, its sizes, a few ways of making things (see build.py).
import random
from lib import *
import lib
from math import asin, hypot, floor

CREAM, TAR, RED, COPPER, BRASS, IRON, DARK = '#d6c7a6', '#5b4134', '#9c3b28', '#b86a3b', '#b3934f', '#3b3d49', '#24252d'
WOOD, WOOD_D, FLOOR, HONEY, SAGE, CEIL = '#8d5f3e', '#553a2a', '#a67c55', '#b99a6e', '#7b8f7d', '#d9cfb8'
CANVAS, ROPE, LEATHER, TEAL, WARM, STEEL = '#cbb88f', '#b0935f', '#8a3c28', '#3f7272', '#ffd6a0', '#8b8e96'

RO, TS, RI, RL = 2.55, 0.05, 2.40, 2.4125          # the staves' outer face; their thickness; the lining's inner face, and its middle
ZF, ZW, ZB = 1.05, 3.40, 0.93                       # floor, top of the wall, bottom of the wall
SILL, HEAD, WS = 1.92, 3.14, rad(60)                # the window round the front
DA, DOOR_TOP = rad(15), 3.0                         # the door at the back
PORTS = [(rad(100), 2.62, 0.33), (rad(-100), 2.62, 0.33)]
SEAT_Y = 0.86                                       # how far forward of the ship's middle the pilot sits: close to the desk and the glass
EYE = Vector((0, SEAT_Y + 0.02, ZF + 1.30))         # the pilot's eye
HINGE = T(0, -(RO + 0.03), ZF)
RAMP_L, RAMP_W = 2.36, 1.06
LIGHTS = []                                         # (where, colour, watts): the lamps, for working out their light
import lib
lib.BYCOL.update({WOOD: 'wood', WOOD_D: 'wood', FLOOR: 'wood', HONEY: 'wood', TAR: 'pwood', RED: 'pwood', CREAM: 'pwood', SAGE: 'pwood', CEIL: 'pwood',
                  COPPER: 'copper', BRASS: 'brass', IRON: 'iron', DARK: 'iron', STEEL: 'steel', CANVAS: 'cloth', ROPE: 'rope', LEATHER: 'leather', TEAL: 'enamel'})
P = lambda th, r, z: Vector((r * sin(th), r * cos(th), z))
lerp = lambda a, b, t: a + (b - a) * t


def spans(theta, Rr, z0, z1):
    """What is left of a board from z0 to z1 at an angle round the wall, once the window, door and portholes are cut."""
    cuts = []
    if abs(theta) < WS: cuts.append((SILL, HEAD))
    if abs(abs(theta) - pi) < DA: cuts.append((z0 - 1, DOOR_TOP))
    for tp, zp, rp in PORTS:
        d = max(abs(Rr * ang(theta - tp)) - 0.09, 0.0); rc = rp + 0.05
        if d < rc: h = sqrt(rc * rc - d * d); cuts.append((zp - h, zp + h))
    out = [(z0, z1)]
    for a, b in cuts:
        nxt = []
        for s, e in out:
            if b <= s or a >= e: nxt.append((s, e)); continue
            if a > s: nxt.append((s, a))
            if b < e: nxt.append((b, e))
        out = nxt
    return [(s, e) for s, e in out if e - s > 0.04]


def lantern(grp, pos, s=1.0, glow=7.0, watts=40, colour=WARM):
    M = T(*pos)
    part(cyl(0.05 * s, 0.13 * s, 12), '#ffb96a', grp, M, bevel=0, glow=glow)
    part(cyl(0.085 * s, 0.05 * s, 12, r2=0.02 * s), BRASS, grp, M @ T(0, 0, 0.095 * s), bevel=0.004, gloss=0.6)
    part(cyl(0.075 * s, 0.02 * s, 12), BRASS, grp, M @ T(0, 0, -0.075 * s), bevel=0.004, gloss=0.6)
    for k in range(4):
        a = pi / 4 + k * pi / 2
        part(box(0.008 * s, 0.008 * s, 0.14 * s), BRASS, grp, M @ T(0.066 * s * cos(a), 0.066 * s * sin(a), 0), bevel=0, gloss=0.6)
    part(tube([(0.03 * s * cos(a), 0, 0.12 * s + 0.03 * s * sin(a)) for a in [i * pi / 6 for i in range(12)]], 0.005 * s, 5, 1, cyclic=True), BRASS, grp, M, bevel=0, gloss=0.6)
    # (under it a drip cup and a ring to trim it by; over it a cowl with its vents; ribs down the glass)
    part(lathe([(0.0, -0.118 * s), (0.03 * s, -0.112 * s), (0.05 * s, -0.095 * s), (0.075 * s, -0.086 * s), (0.075 * s, -0.08 * s), (0.0, -0.08 * s)], 12, close=True), BRASS, grp, M, bevel=0, gloss=0.6)
    part(tube([(0.022 * s * cos(a), 0.022 * s * sin(a), -0.135 * s) for a in [i * pi / 5 for i in range(10)]], 0.004 * s, 5, 1, cyclic=True), BRASS, grp, M, bevel=0, gloss=0.6)
    part(tube([(0, 0, -0.112 * s), (0, 0, -0.134 * s)], 0.004 * s, 5, 1), BRASS, grp, M, bevel=0, gloss=0.6)
    for k in range(6):
        a = k * pi / 3 + 0.3
        part(box(0.014 * s, 0.006 * s, 0.012 * s), DARK, grp, M @ R(a, 'Z') @ T(0.062 * s, 0, 0.1 * s), bevel=0)
    for k in range(4):
        a = k * pi / 2
        part(tube([(0.052 * s * cos(a), 0.052 * s * sin(a), -0.064 * s), (0.052 * s * cos(a), 0.052 * s * sin(a), 0.064 * s)], 0.003 * s, 4, 1), BRASS, grp, M, bevel=0, gloss=0.6)
    LIGHTS.append((Vector(pos), colour, watts))


# ------------------------------------------------------------------------------------- things printed, and small fittings
import json, os
PRINTS = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'prints.json')))
ENAMEL, RUBBER, GREEN_D, PAD = '#cfc8b2', '#1c1c20', '#48584c', '#b9823e'
lib.BYCOL.update({ENAMEL: 'enamel', RUBBER: 'rubber', GREEN_D: 'leather', PAD: 'quilt'})
FLAT = R(-pi / 2, 'X')      # lays a print down on a frame's own top (its +Z), its top edge toward +Y
YA = R(pi / 2, 'X')         # turns a thing made along +Z to point toward whoever a panel faces (a panel's own -Y)


def cell(name):
    """Where a print is in the sheet of prints (src/prints.js draws them): (u0, v0, u1, v1), v up."""
    S = PRINTS['size']
    if name in PRINTS['cells']: x, y, w, h = PRINTS['cells'][name]
    else:
        lw, lh, per = PRINTS['label']; i = (PRINTS['labels'] + PRINTS['labels_cockpit'] + PRINTS['labels_room'] + PRINTS['labels_out']).index(name)
        x, y, w, h = (i % per) * lw, (i // per) * lh, lw, lh
    return (x / S, 1 - (y + h) / S, (x + w) / S, 1 - y / S)


def dcell(name):
    """Where a dial is in the sheet of dials, which the game draws afresh as it goes."""
    D = PRINTS['dials']; S, c = D['size'], D['cell']; i = D['names'].index(name)
    x, y = (i % 4) * c, (i // 4) * c
    return (x / S, 1 - (y + c) / S, (x + c) / S, 1 - y / S)


def facing(x, y, z, tilt=24.0, eye=None, turn=0.0):
    """A panel's frame at a place, turned to face the pilot (its own -Y toward them), leaning back by `tilt` degrees."""
    e = EYE if eye is None else eye
    return T(x, y, z) @ R(-atan2(x - e.x, y - e.y) + turn, 'Z') @ R(-rad(tilt), 'X')


def label(name, M, w=0.06, grp='in', tint='#ffffff', gloss=0.0):
    """Something printed, flat on a panel's face: `w` wide, as tall as its print is."""
    c = cell(name); S = PRINTS['size']
    return part(plane(w, w * (c[3] - c[1]) / (c[2] - c[0]), c), tint, grp, M, bevel=0, mat='print', jit=0, gloss=gloss)


def screw(M, r=0.006, grp='in', col=None):
    part(cyl(r, 0.004, 8), col or STEEL, grp, M @ T(0, -0.002, 0) @ YA, bevel=0.001, gloss=0.6)
    part(box(r * 1.5, 0.001, r * 0.28), DARK, grp, M @ T(0, -0.0045, 0) @ R(random.uniform(0, 3), 'Y'), bevel=0)


def gauge(M, r, name, grp='in', live=True, bez=None):
    """A round dial in a brass ring, on a panel's face."""
    part(lathe([(r - 0.002, 0), (r + 0.012, 0), (r + 0.014, 0.008), (r + 0.007, 0.015), (r - 0.002, 0.011)], 28, close=True), bez or BRASS, grp, M @ YA, bevel=0, gloss=0.6)
    part(disc(r, 28, dcell(name) if live else cell(name)), '#ffffff', grp, M @ T(0, -0.004, 0), bevel=0, mat='dial' if live else 'print', jit=0)
    part(cyl(r + 0.009, 0.034, 20), DARK, grp, M @ T(0, 0.017, 0) @ YA, bevel=0.004, gloss=0.3)


def knob(M, r=0.016, h=0.02, col=None, grp='in', turn=0.0):
    col = col or RUBBER
    part(cyl(r * 1.28, 0.004, 16), STEEL, grp, M @ T(0, -0.002, 0) @ YA, bevel=0, gloss=0.6)
    part(cyl(r, h, 16, r2=r * 0.86), col, grp, M @ T(0, -0.004 - h / 2, 0) @ YA, bevel=0.003, gloss=0.3, mat='rubber' if col == RUBBER else 'enamel')
    part(box(0.0035, 0.002, r * 0.8), CREAM, grp, M @ R(turn, 'Y') @ T(0, -0.0045 - h, r * 0.42), bevel=0, mat='paint')


def toggle(M, up=True, grp='in', tip=None):
    part(cyl(0.011, 0.004, 10), STEEL, grp, M @ T(0, -0.002, 0) @ YA, bevel=0.001, gloss=0.6)
    part(cyl(0.0075, 0.008, 6), BRASS, grp, M @ T(0, -0.007, 0) @ YA, bevel=0, gloss=0.6)
    a = 0.5 if up else -0.5
    end = (0, -0.01 - 0.034 * cos(a), 0.034 * sin(a))
    part(tube([(0, -0.008, 0), end], lambda u: 0.0035 + 0.0022 * u, 7, 1), tip or STEEL, grp, M, bevel=0, gloss=0.6)


def bead(M, kind, col, r=0.011, grp='in', glow=0.0):
    """A small lamp in a brass collar. kind: what lights it ('lit0'..), or None for one that just glows."""
    part(lathe([(r - 0.001, 0), (r + 0.006, 0), (r + 0.006, 0.005), (r - 0.001, 0.008)], 14, close=True), BRASS, grp, M @ YA, bevel=0, gloss=0.6)
    part(ball(r, 12, 8, s=(1, 0.62, 1)), col, grp, M @ T(0, -0.004, 0), bevel=0, mat=kind, gloss=0.6, jit=0, glow=glow)


def bolts(grp, frames, r=0.012, h=0.01, col=None, gloss=0.5):
    """A row of bolt heads: each frame's +Z is the way the bolt sticks out."""
    for M in frames: part(cyl(r, h, 6), col or IRON, grp, M @ T(0, 0, h / 2), bevel=0.002, gloss=gloss)
