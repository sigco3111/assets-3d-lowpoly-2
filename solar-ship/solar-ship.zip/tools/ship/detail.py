# The small things: what makes the ship look lived in and worked on, outside and in.
#
# Outside: rafter tails under the eaves, four pods of jets on their struts, patches riveted over old damage, a
# hatch, the ship's mark by the door, a bell, grab bars, gauges and tags on the tanks, hoses down the legs, rivets
# along the roof's seams, a wind gauge on the mast, a bundle lashed to the roof, a box of herbs under a porthole,
# a spade and a coil of rope. Inside: padding by the pilot, prints on the walls, a net of bedding under the roof,
# a board of tools, a box of fuses, a water tank over the stove, a hatch in the floor, a plant, pans, lights on a string.
from dims import *


def out_at(th, r, z):
    """A frame on the outside of the wall, facing outward (its own -Y points away from the ship)."""
    return at(th, r, z) @ R(pi, 'Z')


def build():
    eaves(); pods(); patches(); hatch(); door_outside(); tank_things(); leg_things(); roof_things(); window_outside(); side_gear(); engine()
    pads(); prints(); net(); tools(); fuses(); water(); floor_hatch(); hung(); shelf_right(); door_inside()


# =============================================================================================== the outside
def eaves():
    for k in range(32):
        th = (k + 0.5) * 2 * pi / 32
        # (none over the door: shut, the ramp's head comes up between them)
        if abs(abs(ang(th)) - pi) < 0.12: continue
        part(box(0.06, 0.36, 0.085), WOOD_D, 'out', at(th, RO + 0.13, 3.255) @ R(rad(-8), 'X'), bevel=0.008, jit=0.06)
        # (each tail's end is cut on the slant and capped with a scrap of copper, nailed)
        part(box(0.064, 0.012, 0.07), COPPER, 'out', at(th, RO + 0.13, 3.255) @ R(rad(-8), 'X') @ T(0, 0.182, 0.004), bevel=0.002, gloss=0.55, jit=0.1)
    part(slab(RO + 0.012, RO + 0.05, 3.33, 3.39, 0, 2 * pi, 64), WOOD_D, 'out', bevel=0.006)
    # a lantern hung under the eave at each front corner
    for sgn in (-1, 1):
        a = sgn * rad(66)
        part(tube([P(a, RO + 0.2, 3.3), P(a, RO + 0.2, 3.16)], 0.006, 5, 1), IRON, 'out', bevel=0)
        lantern('out', P(a, RO + 0.2, 3.02), 1.0, 6, 26)


POD_R, POD_Z = 3.02, 3.62


def pods():
    """Four pods of small jets out past the eaves, one at each corner: they are built in outside2.py (pods2), with all that feeds and holds them."""
    return
    bell = lambda: lathe([(0.04, 0), (0.05, 0.05), (0.085, 0.14), (0.1, 0.2), (0.092, 0.2), (0.078, 0.14), (0.042, 0.05), (0.03, 0)], 18, close=True)
    scorch = lambda Mi: (lambda p: '#2a2630' if (Mi @ p).z > 0.15 else '#6d4a3a' if (Mi @ p).z > 0.1 else COPPER)
    for th in (rad(45), rad(135), rad(-45), rad(-135)):
        c = P(th, POD_R, POD_Z); M = at(th, POD_R, POD_Z)
        part(ball(0.15, 18, 12), ENAMEL, 'out', M, bevel=0, gloss=0.3, jit=0.03)
        part(slab(0.148, 0.158, -0.02, 0.02, 0, 2 * pi, 20), IRON, 'out', M, bevel=0.003, gloss=0.4)
        for k in range(8): part(cyl(0.01, 0.01, 6), STEEL, 'out', M @ R(k * pi / 4, 'Z') @ T(0, 0.158, 0) @ R(-pi / 2, 'X'), bevel=0, gloss=0.6)
        for Mj in (R(-pi / 2, 'X'), R(pi / 2, 'Y'), R(-pi / 2, 'Y'), R(pi, 'X')):
            Mb = M @ Mj @ T(0, 0, 0.13)
            part(bell(), scorch(Mb.inverted()), 'out', Mb, bevel=0, gloss=0.55, jit=0.03, mat='copper')
            part(cyl(0.034, 0.012, 14), '#120f10', 'out', Mb @ T(0, 0, 0.03), bevel=0, mat='soot')
            part(slab(0.05, 0.062, 0.0, 0.025, 0, 2 * pi, 14), IRON, 'out', Mb @ T(0, 0, -0.01), bevel=0.003, gloss=0.4)
        # three struts back to the roof and the wall, and its feed pipe
        for a, r, z in ((th - 0.16, 2.6, 3.55), (th + 0.16, 2.6, 3.55), (th, RO + 0.03, 3.26)):
            part(tube([P(a, r, z), lerp(P(a, r, z), c, 0.9)], 0.02, 8, 1), IRON, 'out', bevel=0, gloss=0.4)
        part(tube([P(th + 0.05, 2.35, 3.68), P(th + 0.05, 2.7, 3.67), c + Vector((0, 0, 0.14))], 0.014, 6, 4), COPPER, 'out', bevel=0, gloss=0.6)


def patches():
    for th, z, w, h, col in ((-123.5, 1.4, 0.34, 0.26, IRON), (137.5, 2.9, 0.3, 0.3, COPPER), (-128, 2.95, 0.36, 0.2, COPPER), (-144.5, 1.33, 0.3, 0.24, IRON), (48, 1.27, 0.26, 0.3, COPPER), (-75.5, 2.3, 0.22, 0.3, COPPER)):
        M = out_at(rad(th), RO + 0.007, z) @ R(random.uniform(-0.12, 0.12), 'Y')
        part(box(w, 0.012, h), col, 'out', M, bevel=0.004, gloss=0.5, jit=0.08)
        n = 4
        for i in range(n):
            for x, zz in ((-w / 2 + 0.03 + (w - 0.06) * i / (n - 1), h / 2 - 0.03), (-w / 2 + 0.03 + (w - 0.06) * i / (n - 1), -h / 2 + 0.03)):
                part(ball(0.011, 8, 6, s=(1, 0.6, 1)), col, 'out', M @ T(x, -0.006, zz), bevel=0, gloss=0.6)
        for zz in (-h / 6, h / 6):
            for x in (-w / 2 + 0.03, w / 2 - 0.03): part(ball(0.011, 8, 6, s=(1, 0.6, 1)), col, 'out', M @ T(x, -0.006, zz), bevel=0, gloss=0.6)


def hatch():
    M = out_at(rad(62), RO + 0.01, 1.42)
    part(box(0.46, 0.02, 0.36), IRON, 'out', M, bevel=0.006, gloss=0.4)
    part(box(0.4, 0.02, 0.3), ENAMEL, 'out', M @ T(0, -0.012, 0), bevel=0.012, gloss=0.3, jit=0.03)
    for z in (-0.09, 0.09):
        part(box(0.07, 0.014, 0.035), IRON, 'out', M @ T(-0.2, -0.024, z), bevel=0.004, gloss=0.4)
        part(cyl(0.012, 0.05, 8), STEEL, 'out', M @ T(-0.235, -0.024, z), bevel=0.002, gloss=0.6)
    part(tube([(0.13, -0.025, -0.04), (0.13, -0.06, -0.04), (0.13, -0.06, 0.04), (0.13, -0.025, 0.04)], 0.008, 6, 3), STEEL, 'out', M, bevel=0, gloss=0.6)
    label('No. 2', M @ T(-0.03, -0.0225, 0.08), 0.12, 'out')
    for k in range(6): part(box(0.2, 0.006, 0.012), '#2a2b30', 'out', M @ T(-0.03, -0.024, -0.1 + 0.025 * k) @ R(rad(25), 'X'), bevel=0, mat='iron')


def door_outside():
    # the ship's mark, on a round board by the door
    Me = out_at(pi - rad(34), RO + 0.012, 2.42)
    part(cyl(0.25, 0.024, 32), WOOD_D, 'out', Me @ YA @ T(0, 0, -0.012), bevel=0.006)
    part(lathe([(0.225, 0), (0.25, 0), (0.25, 0.014), (0.225, 0.014)], 32, close=True), BRASS, 'out', Me @ T(0, -0.012, 0) @ YA, bevel=0.003, gloss=0.6)
    part(disc(0.225, 32, cell('emblem')), '#ffffff', 'out', Me @ T(0, -0.026, 0), bevel=0, mat='print', jit=0)
    for k in range(6): part(ball(0.012, 8, 6, s=(1, 0.6, 1)), BRASS, 'out', Me @ R(k * pi / 3, 'Y') @ T(0, -0.026, 0.237), bevel=0, gloss=0.6)
    # a bell on a bracket, with its cord
    b = P(rad(-141), RO + 0.2, 2.62)
    part(tube([P(rad(-141), RO, 2.74), P(rad(-141), RO + 0.2, 2.76), b + Vector((0, 0, 0.07))], 0.012, 6, 4), IRON, 'out', bevel=0, gloss=0.4)
    part(lathe([(0, 0.07), (0.03, 0.065), (0.055, 0.02), (0.07, -0.05), (0.082, -0.07), (0.074, -0.07), (0.06, -0.045), (0, -0.04)], 18, close=True), BRASS, 'out', T(*b), bevel=0, gloss=0.7)
    part(ball(0.016, 8, 6), IRON, 'out', T(b.x, b.y, b.z - 0.075), bevel=0, gloss=0.4)
    part(tube([b + Vector((0, 0, -0.085)), b + Vector((0.005, 0.005, -0.4))], 0.004, 5, 1), ROPE, 'out', bevel=0)
    # a bar to hold either side of the door, a plate over it
    for sgn in (-1, 1):
        M = out_at(pi - sgn * rad(17.2), RO + 0.005, 2.05)
        part(tube([(0, -0.005, -0.3), (0, -0.07, -0.26), (0, -0.07, 0.26), (0, -0.005, 0.3)], 0.014, 8, 4), BRASS, 'out', M, bevel=0, gloss=0.6)
        for z in (-0.3, 0.3): part(cyl(0.028, 0.012, 10), BRASS, 'out', M @ T(0, -0.004, z) @ YA, bevel=0.003, gloss=0.6)
    label('WIPE YOUR FEET', out_at(pi, RO - 0.02, DOOR_TOP + 0.04) @ T(0, -0.033, 0), 0.34, 'out')
    # the sill of the door: a band of warning
    part(box(1.16, 0.3, 0.012), RED, 'out', at(pi, 2.47, ZF + 0.019), bevel=0.003, mat='stripe')


def tank_things():
    for sgn in (-1, 1):
        c = Vector((sgn * 3.03, -0.1, 1.60)); M = T(*c) @ R(-pi / 2, 'X')
        for z in (-0.62, 0.62):
            for k in range(16):
                a = k * pi / 8
                part(ball(0.012, 8, 6), IRON, 'out', M @ T(0.423 * cos(a), 0.423 * sin(a), z), bevel=0, gloss=0.5)
        # a gauge on top, and what is in it on a plate
        G = T(c.x, c.y + 0.2, c.z + 0.435) @ R(-rad(60), 'X') @ R(pi if sgn > 0 else 0, 'Z')
        Gf = T(c.x + sgn * 0.3, c.y + 0.25, c.z + 0.31) @ R(sgn * pi / 2, 'Z') @ R(-rad(40), 'X')
        part(cyl(0.02, 0.06, 8), BRASS, 'out', T(c.x + sgn * 0.28, c.y + 0.25, c.z + 0.31) @ R(sgn * rad(50), 'Y'), bevel=0.002, gloss=0.6)
        gauge(Gf @ T(0, -0.05, 0.04), 0.06, 'gauge_a' if sgn > 0 else 'gauge_b', 'out', live=False)
        # (what is in it, on a flat plate that stands off the round of the tank on four studs)
        Ml = T(c.x + sgn * 0.436, c.y - 0.15, c.z) @ R(sgn * pi / 2, 'Z')
        part(box(0.23, 0.004, 0.085), ENAMEL, 'out', Ml @ T(0, -0.002, 0), bevel=0.0015, gloss=0.3, jit=0.03)
        label('OIL' if sgn < 0 else 'WATER', Ml @ T(0, -0.005, 0), 0.2, 'out')
        for sx in (-1, 1):
            for sz in (-1, 1):
                part(cyl(0.006, 0.05, 6), IRON, 'out', Ml @ T(sx * 0.104, 0.021, sz * 0.032) @ YA, bevel=0, gloss=0.4)
                part(cyl(0.008, 0.004, 6), STEEL, 'out', Ml @ T(sx * 0.104, -0.006, sz * 0.032) @ YA, bevel=0, gloss=0.6)
        # a ribbed hose from its end round to the belly
        hose = [c + Vector((0, -0.98, 0.05)), c + Vector((-sgn * 0.1, -1.2, -0.1)), Vector((sgn * 2.4, -1.25, 0.95)), Vector((sgn * 1.9, -1.1, 0.72))]
        part(tube(hose, 0.03, 8, 6), RUBBER, 'out', bevel=0)
        Hp = crom([Vector(p) for p in hose], 6)
        for i in range(2, len(Hp) - 1, 2): part(tube([Hp[i], Hp[i] + (Hp[i + 1] - Hp[i]).normalized() * 0.012], 0.036, 8, 1), RUBBER, 'out', bevel=0)


def leg_things():
    for th in (rad(45), rad(135), rad(-45), rad(-135)):
        top, foot = P(th, RO + 0.02, 1.78), P(th, 3.62, 0.17)
        side = Vector((cos(th), -sin(th), 0))
        # a hose down it, in three clips; bolts round its bracket; a ring of rubber under the pad
        pts = [top + side * 0.2 + Vector((0, 0, 0.16)), lerp(top, foot, 0.2) + side * 0.105, lerp(top, foot, 0.5) + side * 0.105, lerp(top, foot, 0.575) + side * 0.1]
        part(tube(pts, 0.012, 6, 3), RUBBER, 'out', bevel=0)
        part(cyl(0.02, 0.03, 6), BRASS, 'out', aim(pts[-1], pts[-1] - side), bevel=0, gloss=0.6)
        part(cyl(0.02, 0.03, 6), BRASS, 'out', T(*pts[0]) @ R(pi / 2, 'X') @ R(th, 'Y'), bevel=0, gloss=0.6)
        for u in (0.15, 0.33, 0.5):
            p = lerp(top, foot, u)
            part(tube([p - side * 0.0, p + side * 0.115], 0.016, 6, 1), STEEL, 'out', bevel=0, gloss=0.6)
        Mb = at(th, RO + 0.09, 1.78)
        for x in (-0.11, 0.11):
            for z in (-0.11, 0.11): part(cyl(0.016, 0.014, 6), STEEL, 'out', Mb @ T(x, 0.004, z) @ R(-pi / 2, 'X'), bevel=0.002, gloss=0.6)
        part(slab(0.27, 0.345, 0.0, 0.035, 0, 2 * pi, 20), RUBBER, 'out', T(foot.x, foot.y, -0.004), bevel=0.006)
        part(slab(0.086, 0.1, -0.012, 0.012, 0, 2 * pi, 14), RED, 'out', aim(lerp(top, foot, 0.3), foot), bevel=0.002, mat='enamel')


def roof_things():
    NR, RA, ZA, RE, ZE = 20, 0.30, 4.52, 2.86, 3.37
    sl = (ZA - ZE) / (RE - RA); beta = atan2(ZA - ZE, RE - RA)
    zr = lambda r: ZA - (r - RA) * sl
    for i in range(NR):
        a0 = (i - 0.5) * 2 * pi / NR
        for r in (0.9, 1.5, 2.1, 2.7):
            if abs(ang(a0)) < 0.55 and abs(r - 1.3) < 0.6: continue
            for d in (-0.045, 0.045):
                part(ball(0.011, 6, 4, s=(1, 1, 0.6)), COPPER, 'out', at(a0, r, zr(r) + 0.002) @ R(-beta, 'X') @ T(d, 0, 0), bevel=0, gloss=0.55)
    # a wind gauge on the mast: three cups going round
    for k in range(3):
        a = k * 2 * pi / 3 + 0.4
        part(tube([(0, 0, 5.25), (0.2 * cos(a), 0.2 * sin(a), 5.25)], 0.006, 5, 1), STEEL, 'out', bevel=0, gloss=0.6)
        part(ball(0.045, 10, 8, s=(1, 1, 1)), COPPER, 'out', T(0.2 * cos(a), 0.2 * sin(a), 5.25), bevel=0, gloss=0.6)
    part(cyl(0.03, 0.05, 10), BRASS, 'out', T(0, 0, 5.25), bevel=0.004, gloss=0.6)
    # a second, whip aerial, with a coil at its foot
    b = P(rad(-110), 1.6, zr(1.6))
    part(cyl(0.05, 0.1, 12), ENAMEL, 'out', T(b.x, b.y, b.z + 0.05), bevel=0.008, gloss=0.3)
    part(tube([b + Vector((0.035 * cos(i * 0.9), 0.035 * sin(i * 0.9), 0.1 + 0.006 * i)) for i in range(30)], 0.005, 5, 1), COPPER, 'out', bevel=0, gloss=0.6)
    part(tube([b + Vector((0, 0, 0.28)), b + Vector((0.03, -0.05, 1.5))], lambda u: 0.007 - 0.005 * u, 5, 1), STEEL, 'out', bevel=0, gloss=0.6)
    # a bundle lashed to the roof under a cloth, at the back on the right
    th = rad(118); r = 1.85
    M = at(th, r, zr(r) + 0.11) @ R(-beta, 'X')
    part(box(0.9, 0.62, 0.2), '#7d8466', 'out', M, bevel=0.07, seg=3, mat='canvas', jit=0.04, sub=2, rough=0.016, grit=7)
    part(box(0.5, 0.4, 0.14), '#7d8466', 'out', M @ T(0.1, 0.02, 0.13), bevel=0.06, seg=3, mat='canvas', jit=0.04, sub=2, rough=0.014, grit=8)
    # (a corner of the cloth has come loose and hangs; a spare wheel for a valve is tied on top)
    part(sheet(5, 4, lambda u, v: (0.36 + 0.14 * u, -0.33 + 0.1 * v + 0.03 * sin(u * 5), -0.1 - 0.05 * u * (1 - v) + 0.012 * sin(v * 7 + u * 3)), 0.006), '#7d8466', 'out', M, bevel=0, mat='canvas', sharp=80, jit=0.05)
    part(tube([(0.085 * cos(i * pi / 7), 0.085 * sin(i * pi / 7), 0) for i in range(14)], 0.009, 5, 1, cyclic=True), RED, 'out', M @ T(-0.2, 0.05, 0.118) @ R(0.12, 'X'), bevel=0, mat='enamel')
    for a in (0.3, 2.4, 4.5): part(tube([(0, 0, 0), (0.085 * cos(a), 0.085 * sin(a), 0)], 0.005, 4, 1), RED, 'out', M @ T(-0.2, 0.05, 0.118) @ R(0.12, 'X'), bevel=0, mat='enamel')
    for x in (-0.28, 0.02, 0.3):
        part(tube([(x, -0.36, -0.1), (x, -0.31, 0.09), (x, -0.2, 0.125 + (0.12 if -0.1 < x < 0.33 else 0)), (x, 0.2, 0.125 + (0.12 if -0.1 < x < 0.33 else 0)), (x, 0.31, 0.09), (x, 0.36, -0.1)], 0.01, 6, 3), ROPE, 'out', M, bevel=0)
        for y in (-0.37, 0.37): part(tube([(x + 0.02 * cos(i * pi / 4), y, -0.1 + 0.02 * sin(i * pi / 4)) for i in range(8)], 0.005, 5, 1, cyclic=True), IRON, 'out', M, bevel=0)
    part(tube([(-0.5, 0, 0.02), (-0.47, 0.0, 0.11), (0.47, 0, 0.11), (0.5, 0, 0.02)], 0.01, 6, 3), ROPE, 'out', M, bevel=0)
    # stays for the stovepipe
    sp = Vector((-0.925, -1.60, 4.42))
    for a in (1.0, 2.8, 5.2):
        e = Vector((sp.x + 0.5 * cos(a), sp.y + 0.5 * sin(a), 0)); e.z = zr(hypot(e.x, e.y)) + 0.02
        part(cyl(0.012, 0.03, 6), IRON, 'out', T(*e), bevel=0, gloss=0.4)
        part(tube([sp, e], 0.004, 4, 1), DARK, 'out', bevel=0)


def window_outside():
    # a rail over the window to turn the rain
    part(slab(RO + 0.0, RO + 0.06, HEAD + 0.1, HEAD + 0.125, rad(-62), rad(62), 30), COPPER, 'out', bevel=0.004, gloss=0.55)
    # a box of herbs under the right-hand porthole
    Mh = out_at(rad(100), RO + 0.11, 2.1)
    part(box(0.6, 0.2, 0.16), WOOD, 'out', Mh, bevel=0.01, jit=0.05)
    for x in (-0.24, 0.24): part(box(0.03, 0.06, 0.22), IRON, 'out', Mh @ T(x, 0.09, -0.02), bevel=0.004, gloss=0.4)
    part(box(0.55, 0.15, 0.03), '#2a1c14', 'out', Mh @ T(0, 0, 0.075), bevel=0.004, mat='soot')
    for k in range(11):
        x = -0.24 + 0.048 * k; hgt = random.uniform(0.07, 0.17); g = random.choice(('#4f8a3c', '#5f9a46', '#3f7a3a', '#7aa24a'))
        for q in range(3):
            lean_ = Vector((random.uniform(-0.04, 0.04), random.uniform(-0.05, 0.03), hgt * random.uniform(0.7, 1)))
            part(ball(random.uniform(0.022, 0.034), 7, 5, s=(1, 0.5, 1.4)), g, 'out', Mh @ T(x, 0, 0.09) @ T(*lean_) @ R(random.uniform(0, 3), 'Z'), bevel=0, mat='paint', jit=0.08)
        if k % 3 == 1: part(ball(0.018, 7, 5), random.choice(('#e8d24a', '#e07a5a', '#e8e0d0')), 'out', Mh @ T(x, -0.03, 0.1 + hgt), bevel=0, mat='paint')


def side_gear():
    # a spade and a pick in two straps, on the left wall
    M = out_at(rad(-114), RO + 0.03, 2.05)
    part(tube([(0, -0.01, -0.62), (0, -0.01, 0.5)], 0.016, 8, 1), WOOD, 'out', M, bevel=0)
    part(box(0.2, 0.012, 0.26), STEEL, 'out', M @ T(0, -0.012, -0.72), bevel=0.004, gloss=0.6)
    part(tube([(-0.05, -0.01, 0.5), (0.05, -0.01, 0.5)], 0.016, 8, 1), WOOD, 'out', M, bevel=0)
    M2 = M @ T(0.2, 0, 0.05)
    part(tube([(0, -0.01, -0.5), (0, -0.01, 0.42)], 0.017, 8, 1), WOOD, 'out', M2, bevel=0)
    part(tube([(-0.2, -0.012, 0.36), (-0.08, -0.012, 0.43), (0.08, -0.012, 0.43), (0.2, -0.012, 0.36)], lambda u: 0.02 - 0.03 * abs(u - 0.5), 6, 3), IRON, 'out', M2, bevel=0, gloss=0.4)
    for z in (-0.3, 0.25):
        part(box(0.36, 0.05, 0.035), LEATHER, 'out', M @ T(0.1, -0.012, z), bevel=0.005)
        part(box(0.03, 0.055, 0.045), BRASS, 'out', M @ T(-0.06, -0.014, z), bevel=0.004, gloss=0.6)
    # a coil of rope on a hook, and a bucket
    Mr = out_at(rad(-126), RO + 0.02, 2.2)
    part(tube([(0, 0, 0.17), (0, -0.07, 0.17), (0, -0.07, 0.2)], 0.008, 6, 2), IRON, 'out', Mr, bevel=0)
    for k in range(4):
        part(tube([((0.14 + 0.004 * k) * cos(i * pi / 10 + k), -0.035 - 0.012 * k + 0.008 * sin(i * 1.3 + k), (0.17 + 0.005 * k) * sin(i * pi / 10 + k)) for i in range(20)], 0.011, 6, 1, cyclic=True), ROPE, 'out', Mr, bevel=0, jit=0.06)
    Mk = out_at(rad(-143), RO + 0.02, 1.62)
    part(tube([(0, 0, 0.36), (0, -0.09, 0.36), (0, -0.09, 0.4)], 0.008, 6, 2), IRON, 'out', Mk, bevel=0)
    part(lathe([(0, 0), (0.1, 0), (0.13, 0.24), (0.122, 0.24), (0.095, 0.012), (0, 0.012)], 16, close=True), STEEL, 'out', Mk @ T(0, -0.13, 0), bevel=0, gloss=0.5)
    part(tube([(0.125 * cos(i * pi / 10), -0.13 + 0.0, 0.23 + 0.13 * sin(i * pi / 10)) for i in range(11)], 0.005, 5, 1), STEEL, 'out', Mk, bevel=0, gloss=0.6)


def engine():
    # the heat has blued the lip of the big bell; a ring of bolts where it hangs
    for k in range(12):
        a = k * pi / 6
        part(cyl(0.016, 0.02, 6), STEEL, 'out', T(0.41 * cos(a), 0.41 * sin(a), 0.5), bevel=0.002, gloss=0.6)
    part(cyl(0.25, 0.012, 24), '#0e0c0d', 'out', T(0, 0, 0.455), bevel=0, mat='soot')


# ================================================================================================ the inside
def pads():
    # padding by the pilot's knees and along the foot of the walls either side
    for a0, a1 in ((61, 78), (-78, -61)):
        part(slab(RI - 0.055, RI - 0.012, ZF + 0.12, 1.83, rad(a0), rad(a1), 8), PAD, 'in', bevel=0.014, seg=3, jit=0.03)
        for a in (a0 + 0.8, a1 - 0.8):
            for z in (ZF + 0.2, 1.75): part(ball(0.012, 8, 6, s=(1, 1, 1)), BRASS, 'in', T(*P(rad(a), RI - 0.056, z)), bevel=0, gloss=0.6)


def prints():
    label('chart_wall', at(rad(-137.6), RI - 0.027, 2.6), 0.44)
    label('almanac', at(rad(-67.5), RI - 0.016, 2.55) @ R(0.03, 'Y'), 0.3)
    for k in range(4): part(ball(0.006, 6, 4), BRASS, 'in', at(rad(-67.5), RI - 0.018, 2.55) @ R(0.03, 'Y') @ T((-0.14, 0.14, -0.14, 0.14)[k], 0, (0.14, 0.14, -0.14, -0.14)[k]), bevel=0, gloss=0.6)
    label('postcard_a', at(rad(-80.6), RI - 0.012, 2.2) @ R(0.07, 'Y'), 0.17)
    label('postcard_b', at(rad(-75.2), RI - 0.012, 2.16) @ R(-0.06, 'Y'), 0.17)
    for th, z in ((-80.6, 2.255), (-75.2, 2.215)): part(ball(0.006, 6, 4), BRASS, 'in', at(rad(th), RI - 0.014, z), bevel=0, gloss=0.6)
    label('sketch', at(rad(-119.5), RI - 0.016, 2.3) @ R(-0.02, 'Y'), 0.3)
    label('calendar', at(rad(133), RI - 0.016, 1.95), 0.2)
    label('notes', at(rad(-86), RI - 0.016, 2.24) @ R(0.05, 'Y'), 0.17)
    label('stars', at(rad(67.5), RI - 0.016, 2.5), 0.3)
    for name, th, z in (('sketch', -119.5, 2.3), ('notes', -86, 2.24), ('stars', 67.5, 2.5), ('calendar', 133, 1.95)):
        part(ball(0.007, 6, 4), RED, 'in', at(rad(th), RI - 0.02, z + {'sketch': 0.1, 'notes': 0.055, 'stars': 0.135, 'calendar': 0.115}[name]), bevel=0, mat='enamel')


def net():
    """A net slung under the roof on the right, with the bedding in it."""
    A = lambda u, v: P(rad(84 + 56 * u), 2.25 - 1.05 * v, 3.36 + 0.42 * v - 0.2 * sin(pi * u) * (0.35 + sin(pi * v)))
    for i in range(8):
        u = i / 7
        part(tube([A(u, v / 6) for v in range(7)], 0.007, 5, 3), ROPE, 'in', bevel=0, jit=0.05)
    for j in range(6):
        v = j / 5
        part(tube([A(u / 8, v) for u in range(9)], 0.007, 5, 3), ROPE, 'in', bevel=0, jit=0.05)
    for u, v in ((0, 0), (1, 0), (0, 1), (1, 1), (0.5, 0), (0.5, 1)): part(ball(0.018, 8, 6), BRASS, 'in', T(*A(u, v)), bevel=0, gloss=0.6)
    # two rolls of bedding and a bag, lying in it
    for u, v, col, r in ((0.3, 0.45, '#8a9a6a', 0.11), (0.62, 0.5, '#b9823e', 0.1)):
        a, b = A(u - 0.2, v), A(u + 0.2, v)
        part(tube([a + Vector((0, 0, r + 0.02)), b + Vector((0, 0, r + 0.02))], r, 14, 1), col, 'in', bevel=0, mat='quilt', jit=0.04)
        for t_ in (0.25, 0.75):
            c = lerp(a, b, t_) + Vector((0, 0, r + 0.02)); d = (b - a).normalized(); e1 = d.orthogonal().normalized(); e2 = d.cross(e1)
            part(tube([c + (e1 * cos(i * pi / 7) + e2 * sin(i * pi / 7)) * (r + 0.004) for i in range(14)], 0.006, 5, 1, cyclic=True), LEATHER, 'in', bevel=0)


def tools():
    M = at(rad(136), RI - 0.02, 2.62)
    part(box(0.36, 0.022, 0.62), WOOD, 'in', M, bevel=0.006)
    label('TOOLS', M @ T(0, -0.0125, 0.27), 0.11)
    # a hammer, a spanner, a saw, pliers, each on two pegs
    part(tube([(-0.11, -0.03, -0.24), (-0.11, -0.03, 0.08)], 0.011, 8, 1), WOOD, 'in', M, bevel=0)
    part(box(0.09, 0.03, 0.035), IRON, 'in', M @ T(-0.11, -0.03, 0.1), bevel=0.006, gloss=0.4)
    part(box(0.022, 0.008, 0.26), STEEL, 'in', M @ T(-0.03, -0.022, -0.08), bevel=0.003, gloss=0.6)
    for z in (0.06, -0.22): part(lathe([(0.012, 0), (0.026, 0), (0.026, 0.008), (0.012, 0.008)], 10, rad(40), rad(320), close=True), STEEL, 'in', M @ T(-0.03, -0.018, z) @ YA @ R(pi if z < 0 else 0, 'Z'), bevel=0, gloss=0.6)
    part(box(0.09, 0.004, 0.3), STEEL, 'in', M @ T(0.07, -0.02, -0.12) @ R(rad(4), 'Y'), bevel=0.001, gloss=0.6)
    part(box(0.1, 0.022, 0.09), WOOD_D, 'in', M @ T(0.075, -0.024, 0.07), bevel=0.012, seg=3)
    for sx in (-1, 1): part(tube([(0.145, -0.022, -0.02), (0.145 + sx * 0.012, -0.022, -0.1), (0.145 + sx * 0.02, -0.022, -0.24)], 0.006, 6, 3), RED if sx > 0 else IRON, 'in', M, bevel=0, mat='rubber' if sx > 0 else None)
    for x, z in ((-0.125, 0.07), (-0.095, 0.07), (-0.03, 0.09), (0.03, 0.1), (0.12, 0.1), (0.145, 0.0)): part(tube([(x, 0, z), (x, -0.045, z + 0.004)], 0.005, 5, 1), WOOD_D, 'in', M, bevel=0)


def fuses():
    M = at(pi + rad(7), RI - 0.02, 3.245)
    part(box(0.34, 0.07, 0.24), ENAMEL, 'in', M @ T(0, -0.02, 0), bevel=0.014, seg=3, gloss=0.3)
    part(box(0.3, 0.006, 0.12), '#3a4a44', 'in', M @ T(0, -0.056, 0.03), bevel=0.002, mat='enamel')
    for k in range(6):
        x, z = -0.11 + 0.044 * k, 0.03
        part(cyl(0.012, 0.06, 8), '#cfe0d8', 'in', M @ T(x, -0.064, z), bevel=0.002, mat='glaze', gloss=0.5)
        for zz in (-0.032, 0.032): part(cyl(0.014, 0.012, 8), BRASS, 'in', M @ T(x, -0.064, z + zz), bevel=0.002, gloss=0.6)
    label('FUSES', M @ T(-0.04, -0.0565, -0.075), 0.09)
    bead(M @ T(0.1, -0.056, -0.075), None, '#8dffa0', 0.007, glow=1.0)


def water():
    """A copper tank of water on the wall over the stove's side, with a tap, a gauge and its name."""
    M = at(rad(-128.5), RI - 0.17, 2.32)
    part(lathe([(0, -0.3), (0.1, -0.29), (0.15, -0.24), (0.15, 0.24), (0.1, 0.29), (0, 0.3)], 20), COPPER, 'in', M, bevel=0, gloss=0.6, jit=0.04)
    for z in (-0.17, 0.17):
        part(slab(0.149, 0.158, z - 0.018, z + 0.018, 0, 2 * pi, 20), BRASS, 'in', M, bevel=0.003, gloss=0.6)
        part(box(0.1, 0.16, 0.03), IRON, 'in', M @ T(0, 0.1, z), bevel=0.004, gloss=0.4)
    part(tube([(0, -0.15, -0.2), (0, -0.2, -0.2), (0, -0.2, -0.25)], 0.012, 6, 2), BRASS, 'in', M, bevel=0, gloss=0.6)
    part(box(0.05, 0.012, 0.012), BRASS, 'in', M @ T(0, -0.2, -0.185), bevel=0.003, gloss=0.6)
    gauge(M @ T(0, -0.156, 0.06), 0.04, 'gauge_c', live=False)
    label('WATER', M @ T(0, -0.153, -0.07), 0.09)
    part(tube([M @ Vector((0, 0, 0.3)), M @ Vector((0, 0, 0.5)), P(rad(-128.5), RI - 0.035, 3.25)], 0.012, 6, 3), COPPER, 'in', bevel=0, gloss=0.6)


def floor_hatch():
    M = T(0.95, -0.55, ZF + 0.002)
    part(box(0.62, 0.62, 0.012), IRON, 'in', M, bevel=0.003, gloss=0.4)
    part(box(0.54, 0.54, 0.014), WOOD_D, 'in', M @ T(0, 0, 0.003), bevel=0.004)
    for k in range(3): part(box(0.54 / 3 - 0.008, 0.52, 0.006), FLOOR, 'in', M @ T(-0.18 + 0.18 * k, 0, 0.011), bevel=0.002, jit=0.08)
    part(tube([(0.04 * cos(i * pi / 8), 0.04 * sin(i * pi / 8), 0) for i in range(16)], 0.006, 6, 1, cyclic=True), BRASS, 'in', M @ T(0, -0.19, 0.018), bevel=0, gloss=0.6)
    for x in (-0.18, 0.18): part(box(0.09, 0.04, 0.008), BRASS, 'in', M @ T(x, 0.27, 0.014), bevel=0.002, gloss=0.6)
    for sx in (-1, 1):
        for sy in (-1, 1): part(cyl(0.008, 0.006, 6), STEEL, 'in', M @ T(sx * 0.29, sy * 0.29, 0.008), bevel=0, gloss=0.6)


def hung():
    # a plant in a pot hung by the right-hand porthole, trailing
    c = P(rad(76), 1.75, 3.0)
    for k in range(3):
        a = k * 2.1
        part(tube([P(rad(76), 1.75, 3.62), c + Vector((0.07 * cos(a), 0.07 * sin(a), 0.07))], 0.003, 4, 1), ROPE, 'in', bevel=0)
    part(lathe([(0, 0), (0.055, 0), (0.085, 0.09), (0.078, 0.09), (0.05, 0.012), (0, 0.012)], 14, close=True), '#b0623c', 'in', T(*c), bevel=0, mat='glaze', gloss=0.2)
    for k in range(9):
        a = k * 0.7; drop = random.uniform(0.15, 0.5)
        pts = [c + Vector((0.04 * cos(a), 0.04 * sin(a), 0.09)), c + Vector((0.11 * cos(a), 0.11 * sin(a), 0.1)), c + Vector((0.13 * cos(a), 0.13 * sin(a), 0.0)), c + Vector((0.12 * cos(a + 0.3), 0.12 * sin(a + 0.3), -drop))]
        part(tube(pts, 0.004, 4, 4), '#4f8a3c', 'in', bevel=0, mat='paint')
        for p in crom([Vector(q) for q in pts], 4)[2::2]:
            part(ball(0.022, 6, 4, s=(1, 0.35, 1.3)), random.choice(('#4f8a3c', '#5f9a46', '#3f7a3a')), 'in', T(*p) @ R(random.uniform(0, 6), 'Z') @ R(random.uniform(-0.6, 0.6), 'X'), bevel=0, mat='paint', jit=0.08)
    # pans and a ladle by the stove, on a rail
    part(tube([P(rad(a), RI - 0.06, 2.75) for a in range(-158, -141, 4)], 0.008, 6, 1), IRON, 'in', bevel=0, gloss=0.4)
    for a in (-157.6, -142.4):
        rod_ = [P(rad(a), RI - 0.06, 2.75), P(rad(a), RI, 2.78)]
        part(tube(rod_, 0.007, 6, 1), IRON, 'in', bevel=0, gloss=0.4)
        part(cyl(0.02, 0.008, 8), IRON, 'in', at(rad(a), RI - 0.004, 2.78) @ YA, bevel=0.002, gloss=0.4)
    for k, (a, r) in enumerate(((-154.2, 0.11), (-148.6, 0.085), (-144.3, 0.0))):
        Mp = at(rad(a), RI - 0.075, 2.74)
        part(tube([(0, 0, 0), (0, -0.01, -0.03)], 0.004, 4, 1), IRON, 'in', Mp, bevel=0)
        if r:
            part(box(0.022, 0.006, 0.2), IRON, 'in', Mp @ T(0, -0.012, -0.13), bevel=0.002, gloss=0.4)
            part(lathe([(0, 0), (r, 0), (r + 0.012, 0.035), (r + 0.006, 0.035), (r - 0.004, 0.006), (0, 0.006)], 18, close=True), COPPER if k else IRON, 'in', Mp @ T(0, -0.012, -0.23 - r) @ YA @ R(pi, 'X'), bevel=0, gloss=0.6)
        else:
            part(tube([(0, -0.012, -0.03), (0, -0.012, -0.26)], 0.005, 5, 1), STEEL, 'in', Mp, bevel=0, gloss=0.6)
            part(ball(0.035, 10, 6, s=(1, 0.5, 1)), STEEL, 'in', Mp @ T(0, -0.02, -0.28), bevel=0, gloss=0.6)
    # small lights on a string, looped along the rafters at the back
    pts = [P(rad(a), 1.55 + 0.25 * sin(a * 0.11), 3.6 - 0.1 * abs(sin(a * 0.0785))) for a in range(150, 276, 7)]
    part(tube(pts, 0.003, 4, 3), DARK, 'in', bevel=0)
    for i, p in enumerate(crom([Vector(q) for q in pts], 3)[1::4]):
        part(ball(0.016, 8, 6, s=(1, 1, 1.25)), ('#ffd08a', '#ffb070', '#ffe6b0')[i % 3], 'in', T(p.x, p.y, p.z - 0.022), bevel=0, glow=2.2)
    LIGHTS.append((Vector((-0.2, -1.5, 3.55)), WARM, 16))
    # a brass bracket where every rafter meets the wall
    for k in range(12):
        th = rad(15 + 30 * k)
        part(box(0.07, 0.11, 0.012), BRASS, 'in', at(th, RI - 0.1, 3.355) @ R(rad(-24), 'X'), bevel=0.003, gloss=0.6)
        part(box(0.07, 0.012, 0.1), BRASS, 'in', at(th, RI - 0.068, 3.31), bevel=0.003, gloss=0.6)


def shelf_right():
    """A shelf over the right-hand porthole: tins and jars with their names, a clock."""
    part(slab(2.14, 2.39, 3.02, 3.05, rad(72), rad(128), 14), WOOD, 'in', bevel=0.006)
    part(tube([P(rad(a), 2.15, 3.1) for a in range(73, 128, 5)], 0.006, 5, 1), BRASS, 'in', bevel=0, gloss=0.6)
    for a in (74, 100, 126): part(box(0.03, 0.24, 0.16), WOOD_D, 'in', at(rad(a), 2.27, 2.95), bevel=0.006)
    things = (('tin', '#3f6b8a', 'TEA'), ('tin', '#b3432a', 'BISCUITS'), ('jar', '#9ab8b0', None), ('tin', '#c9a23a', 'OIL'), ('jar', '#b98a6a', None), ('box', HONEY, 'CHARTS'), ('jar', '#c9b27a', None), ('tin', '#5d6b4a', 'SPARE'))
    for j, (kind, col, name) in enumerate(things):
        M = at(rad(77 + 6.6 * j), 2.27, 3.05)
        if kind == 'tin':
            # (a square caddy, so that its name sits flat on its face)
            part(box(0.104, 0.104, 0.15), col, 'in', M @ T(0, 0, 0.075), bevel=0.012, seg=3, mat='tin', gloss=0.35, jit=0.04)
            part(box(0.11, 0.11, 0.024), STEEL, 'in', M @ T(0, 0, 0.157), bevel=0.008, gloss=0.5, mat='tin')
            part(ball(0.009, 8, 6), BRASS, 'in', M @ T(0, 0, 0.172), bevel=0, gloss=0.6)
            label(name, M @ T(0, -0.0535, 0.08), 0.085)
        elif kind == 'jar':
            h = random.uniform(0.1, 0.16)
            part(cyl(0.048, h, 14), col, 'in', M @ T(0, 0, h / 2), bevel=0.01, mat='glassy', gloss=0.6)
            part(slab(0.0485, 0.0505, h * 0.35, h * 0.65, pi - 0.7, pi + 0.7, 5), '#e2d6b6', 'in', M, bevel=0, mat='paper')
            part(cyl(0.04, 0.02, 12), BRASS, 'in', M @ T(0, 0, h + 0.01), bevel=0.004, gloss=0.6)
        else:
            part(box(0.17, 0.15, 0.11), col, 'in', M @ T(0, 0, 0.055), bevel=0.006, jit=0.06)
            label(name, M @ T(0, -0.076, 0.055), 0.1)


def door_inside():
    label('MIND YOUR HEAD', at(pi, 2.317, DOOR_TOP + 0.04), 0.36)
    # a mat at the door
    label('doormat', T(0, -1.95, ZF + 0.006) @ FLAT, 0.7)
    part(box(0.72, 0.38, 0.008), '#5a4630', 'in', T(0, -1.95, ZF + 0.001), bevel=0.003, mat='cloth')
    # two hooks by the door with a scarf and a hat
    for k, a in enumerate((-166.5, 166.5)):
        Mh = at(rad(a), RI - 0.02, 2.75)
        part(tube([(0, 0, 0), (0, -0.05, -0.01), (0, -0.06, 0.03)], 0.006, 6, 3), BRASS, 'in', Mh, bevel=0, gloss=0.6)
        if k == 0:
            part(sheet(3, 10, lambda u, v: (-0.05 + 0.1 * u + 0.012 * sin(v * 9), -0.035 - 0.012 * sin(u * 3.1) - 0.01 * v, 0.02 - 0.72 * v), 0.01), '#a9604a', 'in', Mh, bevel=0, mat='cloth', jit=0.03, sharp=80)
            part(sheet(3, 8, lambda u, v: (-0.08 + 0.09 * u - 0.01 * sin(v * 7), -0.05 - 0.012 * sin(u * 3.1), 0.02 - 0.5 * v), 0.01), '#a9604a', 'in', Mh, bevel=0, mat='cloth', jit=0.03, sharp=80)
        else:
            part(lathe([(0, 0.1), (0.07, 0.09), (0.09, 0.03), (0.09, 0.0), (0.17, -0.015), (0.17, -0.025), (0, -0.02)], 18, close=True), '#6b5a48', 'in', Mh @ T(0, -0.07, -0.05) @ R(rad(70), 'X'), bevel=0, mat='cloth', rough=0.004, grit=12)
            part(slab(0.089, 0.095, 0.002, 0.028, 0, 2 * pi, 18), '#3a2a20', 'in', Mh @ T(0, -0.07, -0.05) @ R(rad(70), 'X'), bevel=0.001, mat='leather')
            part(sheet(2, 5, lambda u, v: (0.094 + 0.004 * u, -0.02 + 0.03 * u, 0.02 + 0.1 * v + 0.02 * v * v * (1 - u)), 0.002), '#b9a36a', 'in', Mh @ T(0, -0.07, -0.05) @ R(rad(70), 'X'), bevel=0, mat='paper', sharp=80)
