# More of the pilot's place: everything that makes it look worked in.
#
# The wiring (junction boxes at the back of the desk, armoured leads to each instrument, bundles of cable down
# through brass eyes in the desk top), the small instruments between the big ones (a selector, a horn push, a key
# with its tag), what is bolted to the front edge (a priming pump, a trim wheel, a row of fuses, a row of telltale
# lamps), what is on the window's posts (a thermometer, a torch in straps, a gauge lashed on as an afterthought),
# what a pilot leaves about (a morse key, headphones, a log, a slide rule, an oil can, a rag), and everything under
# the desk: pipes with their valves, pedals, a roll of tools, a fire bottle, the furniture of its doors.
#
# And, since the landing glass was made to fold away: three enamelled boards of pushes and switches on the lip where
# its case hung, the wireless's hand piece on its coiled cord, a blanket and a bottle of air on the back of the seat,
# tins by the pilot's hand, a flask and a pouch on the doors, small things along the sill, a string of pennants at
# the window's head (pennants(): one line in build() takes them away), the ship's badge at either end of the desk.
from dims import *
import os
import cockpit
from cockpit import zd, desk, strap

rf = lambda z: 1.84 + (1.56 - z) * 0.5098                     # how far out the desk's sloping front is, by height
INS = '#55635a'                                                # the grey-green some of the boxes are enamelled
lib.BYCOL.update({INS: 'enamel'})


def front(th, z): return at(th, rf(z), z) @ R(rad(27), 'X')     # on the desk's front: -Y out of it, +Z up it
def door(a): return at(rad(a), 1.97, 1.305) @ R(rad(27), 'X')   # one of its five doors
def lipf(th, z): return at(th, 1.84, z)                         # on the upright lip under its front edge
def pol(p): return atan2(p.x, p.y), hypot(p.x, p.y)
def down(p, lift=0.0): return Vector((p.x, p.y, zd(hypot(p.x, p.y)) + lift))
def ondesk(p, lift=0.0): th, r = pol(p); return desk(th, r, lift)
def B(sx, sy, sz, col, M, bevel=0.003, seg=1, **kw): return part(box(sx, sy, sz), col, 'in', M, bevel=bevel, seg=seg, **kw)
def Tu(pts, r, col, n=6, sub=1, M=I4, **kw): return part(tube(pts, r, n, sub), col, 'in', M, bevel=0, **kw)
def V3(*a): return Vector(a)


def Mchart(): c = P(rad(-22.5), 1.93, 1.925); return facing(c.x, c.y, c.z, 27)
def Mdials(): c = P(rad(cockpit.DIALS_AT), 1.93, 1.905); return facing(c.x, c.y, c.z, 27)
def Msmall(): c = P(rad(40.5), 2.02, 1.905); return facing(c.x, c.y, c.z, 30)
def Mswitch(): c = P(rad(-39.5), 2.0, 1.9); return facing(c.x, c.y, c.z, 34)
def Mradio(): c = P(rad(-52), 2.1, 1.99); return facing(c.x, c.y, c.z, 8)


def build():
    count = lambda: sum(len(o.data.polygons) for o in COL['in'].objects)
    n0 = count(); each = {}
    for make in (desk_wiring, near_units, unit_extras, window_things, wings, under_desk, more, lip_panels, seat_back, tins, hung_on_doors, sill_things, hand_mic, small_things, badges):
        n1 = count(); make(); each[make.__name__] = count() - n1
    print('cockpit2 faces', count() - n0, each)
    if os.environ.get('C3_CHECK'): check_swing()


# ----------------------------------------------------------------------------------------------- ways of making
def wires(pts, cols, r=0.004, sub=4, ties=(0.3, 0.7), tiecol='#d9cfb4'):
    """A bundle: several thin cables through the same places, bound here and there with tape."""
    Pp = crom([Vector(p) for p in pts], sub) if len(pts) > 2 else [Vector(p) for p in pts]
    k = len(cols)
    d0 = (Pp[1] - Pp[0]).normalized(); u = d0.orthogonal().normalized(); v = d0.cross(u)
    Rb = 0.0 if k == 1 else r * (1.05 if k == 2 else 1.25 if k < 5 else 1.8)
    for i, col in enumerate(cols):
        a = 2 * pi * i / k + 0.4
        o = (u * cos(a) + v * sin(a)) * Rb
        metal = col in (COPPER, STEEL, BRASS)
        part(tube([p + o * (1 + 0.22 * sin(j * 1.7 + i * 2.1)) for j, p in enumerate(Pp)], r, 5, 1), col, 'in', bevel=0, mat=None if metal else 'rubber', gloss=0.6 if metal else 0.0)
    L = [0.0]
    for a_, b_ in zip(Pp, Pp[1:]): L.append(L[-1] + (b_ - a_).length)
    for t in ties:
        s = t * L[-1]; j = min(max(i for i in range(len(L)) if L[i] <= s), len(Pp) - 2)
        f = (s - L[j]) / max(L[j + 1] - L[j], 1e-6); p = Pp[j].lerp(Pp[j + 1], f); d = (Pp[j + 1] - Pp[j]).normalized()
        part(tube([p - d * 0.006, p + d * 0.006], Rb + r + 0.0014, 8, 1), tiecol, 'in', bevel=0, mat='cloth')


def saddle(p, d, n, Rr=0.008, foot=1.15):
    """A strap of steel over a cable or pipe at p (running along d), holding it to a face whose normal is n."""
    p, d, n = Vector(p), Vector(d).normalized(), Vector(n).normalized(); s = d.cross(n).normalized()
    pts = [p + s * Rr * 2.4 - n * Rr * foot, p + s * Rr * 1.35 - n * Rr * foot * 0.8, p + s * Rr * 1.05 + n * Rr * 0.55, p + n * Rr * 1.28, p - s * Rr * 1.05 + n * Rr * 0.55, p - s * Rr * 1.35 - n * Rr * foot * 0.8, p - s * Rr * 2.4 - n * Rr * foot]
    part(tube(pts, max(0.0022, Rr * 0.22), 5, 1), STEEL, 'in', bevel=0, gloss=0.6)


def grommet(p, r=0.014, lift=0.004):
    """A brass eye in the desk's top, where cables go down through it."""
    M = ondesk(Vector(p), lift)
    part(lathe([(r, 0), (r + 0.008, 0), (r + 0.009, 0.004), (r + 0.004, 0.007), (r, 0.005)], 12, close=True), BRASS, 'in', M, bevel=0, gloss=0.6)
    part(cyl(r, 0.002, 12), '#141418', 'in', M @ T(0, 0, 0.0016), bevel=0, mat='rubber')
    return down(Vector(p), lift + 0.002)


def flex(pts, r=0.007):
    """An armoured lead, with a brass ferrule at each end."""
    Pp = [Vector(p) for p in pts]
    part(tube(Pp, r, 8, 5), STEEL, 'in', bevel=0, gloss=0.5)
    for a, b in ((Pp[0], Pp[1]), (Pp[-1], Pp[-2])):
        d = (b - a).normalized()
        part(tube([a - d * 0.004, a + d * 0.016], r + 0.003, 8, 1), BRASS, 'in', bevel=0, gloss=0.6)


def board(M, w, h, d=0.05, col=None, face=BRASS, screws=0.005):
    """An instrument's box with a plate on its face (toward its own -Y) and a screw in each corner of the plate."""
    part(box(w, d, h), col or ENAMEL, 'in', M @ T(0, d / 2 + 0.002, 0), bevel=0.01, seg=3, gloss=0.28, jit=0.02)
    part(box(w - 0.024, 0.005, h - 0.024), face, 'in', M, bevel=0.002, seg=1, gloss=0.5)
    if screws:
        for sx in (-1, 1):
            for sz in (-1, 1): screw(M @ T(sx * (w / 2 - 0.021), -0.0025, sz * (h / 2 - 0.021)), screws)


def plate(name, M, w=0.06, back=BRASS):
    """A name on a plate of its own, for where the face behind it is not flat enough to print on."""
    c = cell(name); h = w * (c[3] - c[1]) / (c[2] - c[0])
    part(box(w + 0.006, 0.005, h + 0.006), back, 'in', M @ T(0, -0.0005, 0), bevel=0.0015, seg=1, gloss=0.5)
    label(name, M @ T(0, -0.0043, 0), w)


def pushbtn(M, col, r=0.008):
    part(cyl(r * 1.4, 0.004, 12), STEEL, 'in', M @ T(0, -0.002, 0) @ YA, bevel=0, gloss=0.6)
    part(cyl(r, 0.011, 12, r2=r * 0.9), col, 'in', M @ T(0, -0.0095, 0) @ YA, bevel=0.002, seg=1, mat='enamel', gloss=0.4, jit=0.02)


def guard(M):
    """Two bows of wire either side of a switch, so that it is not knocked."""
    for sx in (-1, 1):
        Tu([(sx * 0.015, 0, -0.022), (sx * 0.015, -0.03, -0.014), (sx * 0.015, -0.03, 0.014), (sx * 0.015, 0, 0.022)], 0.002, STEEL, 5, 3, M, gloss=0.6)


def handwheel(M, r=0.03, col='#9a3524'):
    """A valve's wheel: in M's own XY, its spindle along Z."""
    part(tube([(r * cos(i * pi / 8), r * sin(i * pi / 8), 0) for i in range(16)], r * 0.16, 6, 1, cyclic=True), col, 'in', M, bevel=0, mat='enamel', gloss=0.3)
    for k in range(4): Tu([(0, 0, -0.002), (r * cos(k * pi / 2 + 0.3), r * sin(k * pi / 2 + 0.3), 0)], r * 0.1, col, 5, 1, M, mat='enamel', gloss=0.3)
    part(cyl(r * 0.26, 0.012, 8), BRASS, 'in', M @ T(0, 0, 0.002), bevel=0.002, seg=1, gloss=0.6)


def fuse(M, L=0.045):
    """A glass fuse in its two clips, along M's X, standing out of its face."""
    Tu([(-L / 2 + 0.006, 0, 0), (L / 2 - 0.006, 0, 0)], 0.0052, '#b9c7b0', 8, 1, M @ T(0, -0.009, 0), mat='glassy', gloss=0.6)
    for sx in (-1, 1):
        Tu([(sx * (L / 2 - 0.009), 0, 0), (sx * L / 2, 0, 0)], 0.0061, BRASS, 8, 1, M @ T(0, -0.009, 0), gloss=0.6)
        B(0.0035, 0.012, 0.015, STEEL, M @ T(sx * (L / 2 - 0.0045), -0.006, 0), bevel=0, gloss=0.6)


def star(r1, r2, t, n=5):
    bm = bmesh.new()
    vs = [bm.verts.new(((r1 if i % 2 == 0 else r2) * sin(i * pi / n), 0, (r1 if i % 2 == 0 else r2) * cos(i * pi / n))) for i in range(2 * n)]
    bm.faces.new(vs)
    bmesh.ops.solidify(bm, geom=bm.faces[:], thickness=t)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    return bm


# ------------------------------------------------------------------------------------------------- the wiring
def desk_wiring():
    Mc, Md, Mb, Ms = Mchart(), Mdials(), Msmall(), Mswitch()
    # four junction boxes at the back of the desk; the two long cables go through them
    jb = {}
    for a in (-44, -24, 24, 44):
        r = 2.296; M = at(rad(a), r, zd(r) + 0.024); jb[a] = M
        B(0.085, 0.04, 0.05, INS, M, bevel=0.005, seg=2, gloss=0.28)
        B(0.07, 0.004, 0.036, BRASS, M @ T(0, -0.021, 0), bevel=0.0015, gloss=0.5)
        for sx in (-1, 1):
            for sz in (-1, 1): screw(M @ T(sx * 0.027, -0.023, sz * 0.011), 0.0035)
            Tu([(sx * 0.0425, 0.004, -0.017), (sx * 0.053, 0.004, -0.017)], 0.0098, BRASS, 8, 1, M, gloss=0.6)
        part(cyl(0.011, 0.008, 8), BRASS, 'in', M @ T(0, 0, 0.029), bevel=0.002, seg=1, gloss=0.6)
    top = lambda a: jb[a] @ Vector((0, 0, 0.03))
    flex([top(-24), jb[-24] @ Vector((0, -0.03, 0.09)), Mc @ Vector((0.05, 0.2, 0.05)), Mc @ Vector((0.04, 0.136, 0.02))])
    flex([top(24), jb[24] @ Vector((0, -0.03, 0.09)), Md @ Vector((0.03, 0.21, 0.07)), Md @ Vector((0.02, 0.124, 0.05))])
    flex([top(-44), jb[-44] @ Vector((0, -0.04, 0.07)), Ms @ Vector((0.08, 0.17, 0.03)), Ms @ Vector((0.07, 0.104, 0.01))])
    flex([top(44), jb[44] @ Vector((0, -0.04, 0.08)), Mb @ Vector((0.12, 0.12, 0.05)), Mb @ Vector((0.1, 0.035, 0.03))])
    # down through the desk: a bundle from the back of each instrument
    C4 = (RUBBER, '#7a2f22', '#c9b98f', '#2f4a5a')
    g = grommet(down(Mc @ Vector((0.14, 0.24, 0))))
    wires([Mc @ Vector((0.07, 0.137, -0.05)), Mc @ Vector((0.11, 0.2, -0.07)), g + V3(0, 0, 0.07), g], C4)
    g = grommet(down(Md @ Vector((-0.13, 0.25, 0))))
    wires([Md @ Vector((-0.09, 0.124, -0.07)), Md @ Vector((-0.12, 0.2, -0.06)), g + V3(0, 0, 0.06), g], C4)
    g = grommet(down(Ms @ Vector((0.2, 0.22, 0))))
    wires([Ms @ Vector((0.13, 0.104, -0.03)), Ms @ Vector((0.18, 0.17, -0.04)), g + V3(0, 0, 0.05), g], C4[:3])
    # the four small dials are fed by fine copper pipes from a manifold lying behind them
    p1, p2 = down(Mb @ Vector((-0.19, 0.13, 0)), 0.016), down(Mb @ Vector((0.19, 0.13, 0)), 0.016)
    Tu([p1, p2], 0.0105, BRASS, 10, 1, gloss=0.6)
    for p, q in ((p1, p2), (p2, p1)):
        d = (p - q).normalized(); part(tube([p - d * 0.002, p + d * 0.012], 0.013, 6, 1), BRASS, 'in', bevel=0, gloss=0.6)
    for k in range(4):
        x = -0.156 + 0.104 * k; pm = p1.lerp(p2, 0.09 + 0.273 * k)
        part(tube([pm + V3(0, 0, 0.006), pm + V3(0, 0, 0.02)], 0.0065, 6, 1), BRASS, 'in', bevel=0, gloss=0.6)
        Tu([Mb @ Vector((x, 0.036, 0)), Mb @ Vector((x, 0.075, 0.012)), pm + V3(0, 0, 0.06), pm + V3(0, 0, 0.018)], 0.0026, COPPER, 5, 4, gloss=0.6)
    for p in (p1, p2):
        saddle(p, p2 - p1, ondesk(p).to_3x3() @ V3(0, 0, 1), 0.0105, 1.4)
    e = p2 + (p2 - p1).normalized() * 0.012
    g = grommet(down(e + (p2 - p1).normalized() * 0.05), 0.008)
    Tu([e, e + (p2 - p1).normalized() * 0.03 + V3(0, 0, 0.004), g + V3(0, 0, 0.012), g], 0.005, COPPER, 6, 3, gloss=0.6)


# --------------------------------------------------------------- small instruments, between and before the big ones
def near_units():
    # ---- the priming pump, bolted to the lip at the pilot's left
    A = lipf(rad(-29), 1.635)
    B(0.075, 0.008, 0.125, IRON, A @ T(0, -0.002, 0), bevel=0.004, gloss=0.4)
    for sx in (-1, 1):
        for sz in (-1, 1): screw(A @ T(sx * 0.027, -0.006, sz * 0.052), 0.0045)
    a0, a1 = V3(0, -0.045, -0.07), V3(0, -0.085, 0.085); ax = (a1 - a0).normalized()
    Tu([a0, a1], 0.021, BRASS, 14, 1, A, gloss=0.6)
    for t in (0.0, 1.0):
        p = a0.lerp(a1, t); Tu([p - ax * 0.007, p + ax * 0.007], 0.0245, BRASS, 14, 1, A, gloss=0.6)
    for t in (0.27, 0.73):
        p = a0.lerp(a1, t)
        Tu([p - ax * 0.005, p + ax * 0.005], 0.0228, STEEL, 14, 1, A, gloss=0.6)
        B(0.03, abs(p.y) + 0.004, 0.012, IRON, A @ T(0, (p.y + 0.01 - 0.006) / 2, p.z), bevel=0.002, gloss=0.4)
        B(0.012, 0.01, 0.014, STEEL, A @ T(0.024, p.y, p.z), bevel=0.002, gloss=0.6)
    Tu([a1, a1 + ax * 0.062], 0.0048, STEEL, 6, 1, A, gloss=0.6)
    h = a1 + ax * 0.066
    Tu([h + V3(-0.047, 0, 0), h + V3(0.047, 0, 0)], 0.0115, WOOD, 10, 1, A, jit=0.04)
    for sx in (-1, 1): Tu([h + V3(sx * 0.047, 0, 0), h + V3(sx * 0.053, 0, 0)], 0.0125, BRASS, 10, 1, A, gloss=0.6)
    part(ball(0.0095, 8, 6), BRASS, 'in', A @ T(*h), bevel=0, gloss=0.6)
    Tu([a0 - ax * 0.006, V3(0.02, -0.036, -0.092), V3(0.04, -0.012, -0.098), V3(0.046, 0.022, -0.098)], 0.006, COPPER, 6, 3, A, gloss=0.6)
    plate('PRIME', lipf(rad(-29) + 0.062, 1.66), 0.055)

    # ---- the trim wheel, let into the edge at the pilot's right
    A = at(rad(30), 1.84, 1.70)
    Mw = A @ T(0, -0.035, 0.012) @ R(pi / 2, 'Y')
    part(lathe([(0.062, -0.011), (0.078, -0.012), (0.085, -0.006), (0.085, 0.006), (0.078, 0.012), (0.062, 0.011)], 28, close=True), WOOD, 'in', Mw, bevel=0, jit=0.03)
    part(cyl(0.02, 0.036, 12), BRASS, 'in', Mw, bevel=0.003, seg=1, gloss=0.6)
    for k in range(4): B(0.05, 0.012, 0.01, BRASS, Mw @ R(k * pi / 2 + 0.4, 'Z') @ T(0.041, 0, 0), bevel=0.002, gloss=0.6)
    for k in range(14):
        part(cyl(0.0045, 0.008, 6), BRASS if k else '#9a3524', 'in', Mw @ R(k * 2 * pi / 14 + 0.9, 'Z') @ T(0.087, 0, 0) @ R(pi / 2, 'Y'), bevel=0, gloss=0.6, mat=None if k else 'enamel')
    Tu([(-0.034, -0.035, 0.012), (0.034, -0.035, 0.012)], 0.006, STEEL, 8, 1, A, gloss=0.6)
    for sx in (-1, 1):
        B(0.005, 0.085, 0.085, BRASS, A @ T(sx * 0.0225, -0.03, -0.022), bevel=0.002, gloss=0.5)
        part(cyl(0.011, 0.006, 6), STEEL, 'in', A @ T(sx * 0.028, -0.035, 0.012) @ R(pi / 2, 'Y'), bevel=0.001, seg=1, gloss=0.6)
        for z in (-0.05, -0.005): part(cyl(0.004, 0.003, 6), STEEL, 'in', A @ T(sx * 0.0265, -0.005, z) @ R(pi / 2, 'Y'), bevel=0, gloss=0.6)
    # (a pointer over it, and the name beside)
    Tu([(0.0225, -0.02, 0.02), (0.012, -0.03, 0.103), (0.0, -0.035, 0.1)], 0.002, STEEL, 5, 3, A, gloss=0.6)
    plate('TRIM', lipf(rad(30) + 0.05, 1.655), 0.055)

    # ---- a selector on the desk between the chart and the screen
    c = Vector((-0.46, 2.02, 0)); c.z = zd(hypot(c.x, c.y)) + 0.078
    Msel = facing(c.x, c.y, c.z, 32)
    board(Msel, 0.13, 0.115, 0.055, INS)
    Mk = Msel @ T(0, -0.0025, 0.012)
    for k in range(5):
        B(0.003, 0.002, 0.008, DARK, Mk @ R(rad(-60 + 30 * k), 'Y') @ T(0, -0.001, 0.028), bevel=0, mat='paint')
    knob(Mk, 0.016, 0.02, RUBBER, turn=rad(30))
    bead(Msel @ T(-0.042, -0.0025, -0.033), None, '#8dffa0', 0.0055, glow=1.0)
    bead(Msel @ T(0.042, -0.0025, -0.033), None, '#ffb050', 0.0055)
    label('SCOPE', Msel @ T(0, -0.0037, -0.033), 0.05)
    for sx in (-1, 1):
        f = Msel @ Vector((sx * 0.045, 0.045, -0.05)); Tu([f, down(f, 0.004)], 0.007, BRASS, 6, 1, gloss=0.6)
        part(cyl(0.013, 0.004, 8), BRASS, 'in', ondesk(f, 0.006), bevel=0, gloss=0.6)
    g = grommet(down(Msel @ Vector((0.0, 0.16, 0))), 0.009)
    wires([Msel @ Vector((0, 0.057, 0.0)), Msel @ Vector((0, 0.1, -0.01)), g + V3(0, 0, 0.04), g], (RUBBER, '#7a2f22'), ties=(0.5,))

    # ---- the horn's push, on the edge of the desk by the stick
    M = desk(rad(-17.5), 1.868, 0)
    part(lathe([(0, 0), (0.02, 0), (0.02, 0.004), (0.014, 0.009), (0, 0.009)], 14), BRASS, 'in', M, bevel=0, gloss=0.6)
    part(ball(0.0095, 10, 8, s=(1, 1, 0.7)), '#9a3524', 'in', M @ T(0, 0, 0.0095), bevel=0, mat='enamel', gloss=0.4)
    label('HORN', desk(rad(-17.5), 1.928, 0.0055) @ FLAT, 0.05)

    # ---- the key, in its lock on the edge of the desk, with its tag hung over the rail
    th = rad(18.6); M = desk(th, 1.868, 0)
    part(lathe([(0, 0), (0.019, 0), (0.019, 0.003), (0.012, 0.007), (0, 0.007)], 14), BRASS, 'in', M, bevel=0, gloss=0.6)
    part(cyl(0.003, 0.02, 6), STEEL, 'in', M @ T(0, 0, 0.016), bevel=0, gloss=0.6)
    part(tube([(0.011 * cos(i * pi / 6), 0, 0.037 + 0.011 * sin(i * pi / 6)) for i in range(12)], 0.003, 5, 1, cyclic=True), BRASS, 'in', M @ R(0.5, 'Z'), bevel=0, gloss=0.6)
    k0 = M @ Vector((0, 0, 0.042))
    Tu([k0, P(th, 1.838, 1.74), P(th, 1.812, 1.722), P(th, 1.822, 1.675)], 0.0012, ROPE, 4, 3)
    Mt = lipf(th, 1.652) @ T(0, -0.02, 0) @ R(0.18, 'Y')
    B(0.05, 0.0014, 0.025, '#d8c9a0', Mt @ T(0, 0.0019, 0), bevel=0, mat='paper')
    label('tag_b', Mt, 0.05)
    label('KEY', desk(th, 1.928, 0.0055) @ FLAT, 0.05)


# -------------------------------------------------------------------------------- more on the big instruments
def unit_extras():
    # the chart glass: a rim on its glass, a block under its three knobs, nuts on its pivots, a small lamp over it
    Mc = Mchart()
    part(lathe([(0.112, 0), (0.1205, 0), (0.1205, 0.0045), (0.112, 0.0025)], 40, close=True), BRASS, 'in', Mc @ T(0, -0.001, 0) @ YA, bevel=0, gloss=0.7)
    Mk = Mc @ T(0, 0.012, -0.212) @ R(rad(20), 'X')
    B(0.2, 0.034, 0.046, WOOD_D, Mk @ T(0, 0.0185, -0.004), bevel=0.006, seg=2)
    B(0.185, 0.004, 0.034, BRASS, Mk @ T(0, 0.0, 0), bevel=0.0015, gloss=0.5)
    for sx in (-1, 1):
        screw(Mk @ T(sx * 0.086, -0.002, 0), 0.0035)
        part(cyl(0.012, 0.012, 8), BRASS, 'in', Mc @ T(sx * 0.226, 0.07, 0) @ R(pi / 2, 'Y'), bevel=0.002, seg=1, gloss=0.6)
        B(0.005, 0.032, 0.008, BRASS, Mc @ T(sx * 0.229, 0.07, 0) @ R(0.5, 'X'), bevel=0.002, gloss=0.6)
    neck = [Mc @ Vector(p) for p in ((0.07, 0.11, 0.163), (0.105, 0.1, 0.24), (0.085, 0.0, 0.275), (0.055, -0.05, 0.245))]
    Tu(neck, 0.0048, BRASS, 6, 5, gloss=0.6)
    part(cyl(0.012, 0.01, 8), BRASS, 'in', aim(neck[0] - (neck[1] - neck[0]).normalized() * 0.004, neck[1]) @ T(0, 0, 0.005), bevel=0.002, seg=1, gloss=0.6)
    Mh = aim(neck[-1], Mc @ Vector((0.0, 0.0, 0.07)))
    part(lathe([(0.006, -0.02), (0.012, -0.012), (0.03, 0.025), (0.027, 0.025), (0.01, -0.008), (0.004, -0.016)], 14, close=True), TEAL, 'in', Mh, bevel=0, gloss=0.3)
    part(ball(0.008, 8, 6), WARM, 'in', Mh @ T(0, 0, 0.004), bevel=0, glow=4)
    LIGHTS.append((Mh @ Vector((0, 0, 0.04)), WARM, 2.5))
    # (a pair of dividers hung on its fork)
    hd = Mc @ Vector((-0.212, 0.062, -0.045))
    part(ball(0.006, 8, 6), BRASS, 'in', T(*hd), bevel=0, gloss=0.6)
    for sx in (-1, 1): Tu([hd, hd + V3(sx * 0.012, -0.004, -0.1)], lambda u: 0.0032 - 0.0026 * u, STEEL, 5, 1, gloss=0.6)

    # the dials: a rosette in the middle, screws at the edges, a red marker on each rim, a handle on the case
    Md = Mdials()
    part(cyl(0.013, 0.004, 10), BRASS, 'in', Md @ T(0, -0.006, 0) @ YA, bevel=0.001, seg=1, gloss=0.6)
    screw(Md @ T(0, -0.008, 0), 0.005)
    for x, z in ((-0.152, 0), (0.152, 0), (0, 0.142), (0, -0.142)): screw(Md @ T(x, -0.004, z), 0.0042)
    for k, a in enumerate((-40, 55, 20, -110)):
        x, z = (-0.084 if k % 2 == 0 else 0.084), (0.08 if k < 2 else -0.08)
        B(0.005, 0.004, 0.011, '#9a3524', Md @ T(x, -0.0205, z) @ R(rad(a), 'Y') @ T(0, 0, 0.0655), bevel=0.001, mat='enamel', gloss=0.4)
    Tu([(-0.06, 0.062, 0.166), (-0.06, 0.062, 0.2), (0.06, 0.062, 0.2), (0.06, 0.062, 0.166)], 0.0055, BRASS, 6, 3, Md, gloss=0.6)
    for sx in (-1, 1): part(cyl(0.011, 0.005, 8), BRASS, 'in', Md @ T(sx * 0.06, 0.062, 0.1735), bevel=0, gloss=0.6)
    # (two catches down one side of the case, two hinges down the other)
    for z in (-0.09, 0.09):
        B(0.006, 0.03, 0.022, BRASS, Md @ T(0.1815, 0.05, z), bevel=0.0015, gloss=0.6)
        B(0.008, 0.012, 0.03, BRASS, Md @ T(0.185, 0.03, z), bevel=0.0015, gloss=0.6)
        part(cyl(0.005, 0.034, 6), BRASS, 'in', Md @ T(-0.1825, 0.03, z), bevel=0, gloss=0.6)
        B(0.004, 0.03, 0.03, BRASS, Md @ T(-0.1812, 0.048, z), bevel=0.001, gloss=0.6)
    # the four small ones: a screw in each corner of their plate
    Mb = Msmall()
    for sx in (-1, 1):
        for sz in (-1, 1): screw(Mb @ T(sx * 0.203, -0.001, sz * 0.048), 0.0038)

    # the switches at the left: wire guards on two, and names over the six on the board over the window
    Ms = Mswitch()
    for k in (1, 4): guard(Ms @ T(-0.144 + 0.072 * k, -0.0025, 0.012))
    Mo = at(0, RO - 0.3, HEAD + 0.17) @ R(rad(38), 'X')
    for k, name in enumerate(('LAMPS', 'MAIN', 'AUX', 'VENT', 'FANS', 'SPARE')):
        label(name, Mo @ T(-0.16 + 0.064 * k, -0.0032, 0.031), 0.054)
    guard(Mo @ T(-0.16 + 0.064 * 4, -0.002, 0.008))
    for sx in (-1, 1): screw(Mo @ T(sx * 0.197, -0.002, 0), 0.0038)


# ------------------------------------------------------------------------------------------ round the window
def window_things():
    # a catch at the foot of each pane
    for k in range(5):
        M = at(rad(-48 + 24 * k), 2.357, 1.94)
        B(0.075, 0.032, 0.005, BRASS, M @ T(0, 0, 0.0025), bevel=0.0015, gloss=0.6)
        part(cyl(0.008, 0.012, 8), BRASS, 'in', M @ T(-0.012, 0, 0.011), bevel=0.001, seg=1, gloss=0.6)
        Ml = M @ T(-0.012, 0, 0.014) @ R(0.45, 'Z')
        B(0.062, 0.011, 0.005, BRASS, Ml @ T(0.026, 0, 0), bevel=0.0015, gloss=0.6)
        part(ball(0.0075, 8, 6), BRASS, 'in', Ml @ T(0.056, 0, 0.004), bevel=0, gloss=0.6)
        for sx in (-1, 1): part(cyl(0.0035, 0.003, 6), STEEL, 'in', M @ T(sx * 0.03, 0.008 * sx, 0.006), bevel=0, gloss=0.6)
    # a thermometer on the post at the left of the wide glass
    M = at(rad(-36), 2.38, 2.96)
    B(0.032, 0.006, 0.17, CEIL, M @ T(0, -0.003, 0), bevel=0.002, jit=0.03)
    Tu([(0, -0.0095, -0.058), (0, -0.0095, 0.004)], 0.0033, '#a8301f', 6, 1, M, mat='glassy', gloss=0.6)
    Tu([(0, -0.0095, 0.004), (0, -0.0095, 0.066)], 0.0031, '#cfd8cf', 6, 1, M, mat='glassy', gloss=0.6)
    part(ball(0.0062, 8, 6), '#a8301f', 'in', M @ T(0, -0.0095, -0.063), bevel=0, mat='glassy', gloss=0.6)
    for z in (-0.045, 0.07): B(0.014, 0.0075, 0.006, BRASS, M @ T(0, -0.0085, z), bevel=0.001, gloss=0.6)
    for k in range(11): B(0.008 if k % 5 else 0.012, 0.0012, 0.0014, DARK, M @ T(0.0095, -0.0064, -0.04 + 0.01 * k), bevel=0, mat='paint')
    for z in (-0.078, 0.078): screw(M @ T(0, -0.006, z), 0.003)
    # (and under it a small gauge on a block, lashed on as an afterthought, its pipe run down the post)
    Mg = at(rad(-36), 2.38, 2.36)
    B(0.07, 0.022, 0.1, WOOD, Mg @ T(0, -0.011, 0), bevel=0.004, jit=0.05)
    gauge(Mg @ T(0, -0.0225, 0), 0.024, 'gauge_a', live=False)
    for z in (-0.043, 0.043):
        part(tube([(0.0275, 0.06, z), (0.0275, 0.004, z), (0.0375, -0.004, z), (0.0375, -0.0245, z), (-0.0375, -0.0245, z), (-0.0375, -0.004, z), (-0.0275, 0.004, z), (-0.0275, 0.06, z)], 0.0028, 5, 1), ROPE, 'in', Mg, bevel=0)
    part(ball(0.005, 6, 5), ROPE, 'in', Mg @ T(0.02, -0.026, 0.043), bevel=0)
    Tu([Mg @ Vector((0.012, -0.008, -0.05)), Mg @ Vector((0.024, -0.002, -0.075))] + [P(rad(-36) + 0.0132, 2.393, z) for z in (2.26, 2.15, 2.05, 1.945)], 0.0026, COPPER, 5, 3, gloss=0.6)
    # a torch in two leather straps on the post at the right of the wide glass, under the bell
    M = at(rad(36), 2.38, 2.2)
    Tu([(0, -0.03, -0.09), (0, -0.03, 0.04)], 0.019, BRASS, 12, 1, M, gloss=0.6)
    part(lathe([(0.019, 0), (0.03, 0.03), (0.03, 0.042), (0.0265, 0.042), (0.0265, 0.034), (0.017, 0.006)], 14, close=True), BRASS, 'in', M @ T(0, -0.03, 0.04), bevel=0, gloss=0.6)
    part(cyl(0.0265, 0.003, 14), '#cfd8cf', 'in', M @ T(0, -0.03, 0.076), bevel=0, mat='glassy', gloss=0.6)
    part(ball(0.019, 12, 6, s=(1, 1, 0.5)), BRASS, 'in', M @ T(0, -0.03, -0.09), bevel=0, gloss=0.6)
    B(0.008, 0.005, 0.02, STEEL, M @ T(0, -0.0505, -0.01), bevel=0.001, gloss=0.6)
    for z in (-0.06, 0.015):
        part(lathe([(0.0195, -0.008), (0.0225, -0.008), (0.0225, 0.008), (0.0195, 0.008)], 12, close=True), LEATHER, 'in', M @ T(0, -0.03, z), bevel=0)
        B(0.05, 0.012, 0.016, LEATHER, M @ T(0, -0.006, z), bevel=0.002)
        for sx in (-1, 1): part(cyl(0.0035, 0.003, 6), BRASS, 'in', M @ T(sx * 0.019, -0.0125, z) @ YA, bevel=0, gloss=0.6)
    # (and a slip of paper pinned to the post under it)
    Mn = at(rad(36), 2.38, 2.02) @ R(0.06, 'Y')
    B(0.046, 0.0012, 0.023, '#e3d8ba', Mn @ T(0, -0.0008, 0), bevel=0, mat='paper')
    label('note_d', Mn @ T(0, -0.0026, 0), 0.046)
    part(ball(0.0035, 6, 5), BRASS, 'in', Mn @ T(0, -0.004, 0.0085), bevel=0, gloss=0.6)
    # a wire up each of the next posts out, in clips, and along over the window to the board of switches
    Mo = at(0, RO - 0.3, HEAD + 0.17) @ R(rad(38), 'X')
    for sgn in (-1, 1):
        th = sgn * rad(36)
        pts = [P(th, 2.3755, SILL + 0.03 + 0.1 * i) for i in range(13)] + [P(th, 2.35, 3.25), P(th * 0.985, 2.3255, 3.32)] + [P(th * (1 - 0.03 * i), 2.3255, 3.33) for i in range(1, 29)] + [Mo @ Vector((sgn * 0.215, 0.02, 0.0))]
        Tu(pts, 0.004, RUBBER, 5, 1, mat='rubber')
        for z in (2.1, 2.45, 2.8, 3.1): saddle(P(th, 2.3755, z), V3(0, 0, 1), V3(-sin(th), -cos(th), 0), 0.004)
        for i in (4, 12, 20, 27): saddle(P(th * (1 - 0.03 * i), 2.3255, 3.33), V3(cos(th), -sin(th), 0), V3(-sin(th * (1 - 0.03 * i)), -cos(th * (1 - 0.03 * i)), 0), 0.004)
    # the cord of each blind, with an acorn of wood on its end
    for k in range(5):
        M = at(rad(-48 + 24 * k), RO - 0.24, HEAD + 0.035)
        x = 0.07 if k % 2 else -0.05
        Tu([(x, -0.03, -0.02), (x + 0.003, -0.034, -0.07), (x, -0.033, -0.115)], 0.0014, ROPE, 4, 3, M)
        part(lathe([(0, -0.014), (0.006, -0.01), (0.007, 0.0), (0.004, 0.008), (0, 0.01)], 8), WOOD, 'in', M @ T(x, -0.033, -0.122), bevel=0, jit=0.05)
    # a charm on a string at the head of the window: a bead, a brass star, a bead, a small bell
    c = P(rad(19.5), 2.3, HEAD - 0.012)
    part(tube([c + V3(0, 0.03, 0.03), c + V3(0, 0.0, 0.0)], 0.0025, 5, 1), BRASS, 'in', bevel=0, gloss=0.6)
    Tu([c, c + V3(0, 0, -0.235)], 0.001, ROPE, 4, 1)
    part(ball(0.0085, 8, 6), WOOD, 'in', T(*(c + V3(0, 0, -0.06))), bevel=0, jit=0.05)
    part(star(0.03, 0.013, 0.004), BRASS, 'in', T(*(c + V3(0, 0.002, -0.115))) @ R(0.5, 'Z'), bevel=0, gloss=0.7, sharp=20)
    part(ball(0.007, 8, 6), '#9a3524', 'in', T(*(c + V3(0, 0, -0.165))), bevel=0, mat='glaze', gloss=0.5)
    part(lathe([(0.002, 0.0), (0.006, -0.004), (0.011, -0.016), (0.015, -0.026), (0.013, -0.026), (0.009, -0.016), (0.004, -0.006), (0.0, -0.002)], 12, close=True), BRASS, 'in', T(*(c + V3(0, 0, -0.21))), bevel=0, gloss=0.7)
    part(ball(0.004, 6, 5), STEEL, 'in', T(*(c + V3(0, 0, -0.238))), bevel=0, gloss=0.6)


# ------------------------------------------------------------------------- what is at the two ends of the desk
def wings():
    Mw, Ms = Mradio(), Mswitch()
    # ---- a morse key before the wireless
    M = desk(rad(-50.5), 1.975, 0.004)
    B(0.065, 0.12, 0.012, WOOD_D, M @ T(0, 0, 0.006), bevel=0.003, seg=2)
    Ml = M @ T(0, 0.012, 0.0325) @ R(rad(-4), 'X')
    B(0.011, 0.1, 0.006, BRASS, Ml, bevel=0.0015, gloss=0.6)
    for sx in (-1, 1): part(cyl(0.004, 0.024, 6), BRASS, 'in', M @ T(sx * 0.013, 0.02, 0.024), bevel=0, gloss=0.6)
    Tu([(-0.016, 0.02, 0.032), (0.016, 0.02, 0.032)], 0.0028, STEEL, 6, 1, M, gloss=0.6)
    part(lathe([(0, 0), (0.016, 0), (0.019, 0.004), (0.012, 0.012), (0, 0.013)], 14), RUBBER, 'in', Ml @ T(0, -0.05, 0.003), bevel=0)
    part(cyl(0.0048, 0.014, 6), BRASS, 'in', M @ T(0, -0.034, 0.019), bevel=0, gloss=0.6)
    part(cyl(0.0035, 0.024, 6), STEEL, 'in', M @ T(0, 0.052, 0.03), bevel=0, gloss=0.6)
    part(cyl(0.007, 0.004, 8), BRASS, 'in', M @ T(0, 0.052, 0.043), bevel=0, gloss=0.6)
    for sx in (-1, 1):
        part(cyl(0.0055, 0.012, 6), BRASS, 'in', M @ T(sx * 0.022, 0.05, 0.018), bevel=0, gloss=0.6)
        Tu([M @ Vector((sx * 0.022, 0.05, 0.022)), M @ Vector((sx * 0.03, 0.09, 0.012)), Mw @ Vector((-0.05 + sx * 0.02, -0.004, -0.11)), Mw @ Vector((-0.05 + sx * 0.02, 0.004, -0.1))], 0.0018, '#7a2f22' if sx > 0 else RUBBER, 4, 3, mat='rubber')
    # ---- headphones on a peg at the wireless's side
    Tu([(0.17, 0.08, 0.078), (0.226, 0.08, 0.086)], 0.004, BRASS, 6, 1, Mw, gloss=0.6)
    part(ball(0.006, 6, 5), BRASS, 'in', Mw @ T(0.226, 0.08, 0.086), bevel=0, gloss=0.6)
    arc = [(0.212, 0.08 + 0.066 * cos(a), 0.014 + 0.066 * sin(a)) for a in [rad(205 - 23 * i) for i in range(11)]]
    part(strap([Mw @ Vector(p) for p in arc], 0.016, 0.003), LEATHER, 'in', bevel=0, jit=0.03)
    for sy in (-1, 1):
        cc = Mw @ Vector((0.212, 0.08 + sy * 0.057, -0.022))
        Mcup = Mw @ T(0.212, 0.08 + sy * 0.057, -0.022) @ R(sy * pi / 2, 'X')
        part(lathe([(0, 0), (0.03, 0), (0.033, 0.006), (0.033, 0.018), (0.024, 0.026), (0, 0.027)], 14), '#2b2c33', 'in', Mcup, bevel=0, mat='enamel', gloss=0.3)
        part(lathe([(0.02, -0.008), (0.031, -0.008), (0.034, 0.0), (0.02, 0.001)], 14, close=True), '#4a3226', 'in', Mcup, bevel=0, mat='leather')
    Tu([Mw @ Vector(p) for p in ((0.212, 0.142, -0.05), (0.215, 0.15, -0.09), (0.2, 0.17, -0.11), (0.172, 0.165, -0.085))], 0.0022, RUBBER, 4, 4, mat='rubber')
    # ---- a speaking tube at the far end, its mouth turned to the seat, a cork in it on a chain
    b = P(rad(-57.2), 1.935, zd(1.935))
    pts = [b, b + V3(0, 0, 0.2), b + V3(0.035, -0.01, 0.33), b + V3(0.125, -0.035, 0.38)]
    Tu(pts, 0.013, COPPER, 8, 5, gloss=0.6)
    part(lathe([(0.013, 0), (0.03, 0), (0.03, 0.004), (0.018, 0.012), (0.0135, 0.03)], 12), BRASS, 'in', T(*b), bevel=0, gloss=0.6)
    for k in range(3): part(cyl(0.0035, 0.003, 6), STEEL, 'in', T(*b) @ T(0.024 * cos(k * 2.09), 0.024 * sin(k * 2.09), 0.0045), bevel=0, gloss=0.6)
    part(tube([b + V3(0, 0, 0.1), b + V3(0, 0, 0.112)], 0.0155, 8, 1), BRASS, 'in', bevel=0, gloss=0.6)
    e = pts[-1]; dm = V3(0.93, -0.3, 0.2).normalized()
    Mm = aim(e - dm * 0.004, e + dm)
    part(lathe([(0.0135, 0), (0.017, 0.02), (0.03, 0.05), (0.043, 0.066), (0.041, 0.0675), (0.027, 0.05), (0.013, 0.02), (0.011, 0)], 16, close=True), BRASS, 'in', Mm, bevel=0, gloss=0.6)
    part(cyl(0.015, 0.02, 10, r2=0.011), '#a98b62', 'in', Mm @ T(0, 0, 0.03), bevel=0.002, seg=1, mat='wood')
    part(ball(0.004, 6, 5), BRASS, 'in', Mm @ T(0, 0, 0.042), bevel=0, gloss=0.6)
    Tu([Mm @ Vector((0, 0, 0.044)), e + dm * 0.07 + V3(0, 0, -0.06), e + V3(-0.01, 0, -0.07), e + V3(-0.03, 0.01, -0.016)], 0.0012, STEEL, 4, 4, gloss=0.6)
    label('SPEAK', desk(rad(-57.2), 1.935, 0.0055) @ T(0.062, 0, 0) @ FLAT, 0.05)
    # ---- an oil can and a pair of dividers by the mug, a spoon in the mug
    Mo = desk(rad(-33.2), 2.05) @ R(-rad(19.6), 'X') @ T(0, 0, 0.004)
    part(lathe([(0, 0), (0.036, 0), (0.038, 0.004), (0.038, 0.04), (0.03, 0.05), (0.008, 0.068), (0.0045, 0.075), (0, 0.075)], 16), '#8d8f8a', 'in', Mo, bevel=0, mat='tin', gloss=0.5, jit=0.03)
    part(lathe([(0.0385, 0.036), (0.0395, 0.036), (0.0395, 0.042), (0.0385, 0.042)], 16, close=True), '#8d8f8a', 'in', Mo, bevel=0, mat='tin', gloss=0.5)
    Tu([(0, 0, 0.072), (0.02, 0, 0.11), (0.07, 0, 0.14), (0.105, 0, 0.143)], lambda u: 0.0042 - 0.0026 * u, '#8d8f8a', 6, 4, Mo, mat='tin', gloss=0.5)
    Tu([(-0.03, 0, 0.045), (-0.055, 0, 0.05), (-0.06, 0, 0.025), (-0.04, 0, 0.012)], 0.003, '#8d8f8a', 5, 3, Mo, mat='tin', gloss=0.5)
    label('OIL', Mo @ T(0, -0.0392, 0.02), 0.035)
    Mm = desk(rad(-31), 2.2) @ R(-rad(19.6), 'X')
    Tu([(0.01, 0.01, 0.012), (0.03, 0.022, 0.135)], 0.0022, STEEL, 5, 1, Mm, gloss=0.6)
    part(ball(0.009, 8, 5, s=(1, 0.6, 1.4)), STEEL, 'in', Mm @ T(0.032, 0.023, 0.145), bevel=0, gloss=0.6)
    Md = desk(rad(-28.2), 2.12, 0.0065) @ R(0.9, 'Z')
    part(ball(0.006, 8, 6), BRASS, 'in', Md, bevel=0, gloss=0.6)
    for sx in (-1, 1): Tu([(0, 0, 0), (sx * 0.02, -0.12, -0.003)], lambda u: 0.0034 - 0.0028 * u, STEEL, 5, 1, Md, gloss=0.6)
    # ---- a block of coloured pushes, right of the trim wheel
    c = P(rad(33.6), 1.935, zd(1.935) + 0.066)
    Mp = facing(c.x, c.y, c.z, 38)
    board(Mp, 0.2, 0.085, 0.05, ENAMEL, screws=0.0038)
    for k, (col, name) in enumerate((('#9a3524', 'FEED'), ('#c9a23a', 'HEATER'), ('#3f6b5a', 'DYNAMO'), ('#d9cfb8', 'DIM'), ('#2b2c33', 'BRIGHT'))):
        x = -0.07 + 0.035 * k
        pushbtn(Mp @ T(x, -0.0025, 0.012), col, 0.0085)
        label(name, Mp @ T(x, -0.0037, -0.018), 0.033)
    for sx in (-1, 1):
        f = Mp @ Vector((sx * 0.07, 0.012, -0.036)); Tu([f, down(f)], 0.006, BRASS, 6, 1, gloss=0.6)
    # ---- the log, with the slide rule on it; a page of notes beside; the pencil on its string by the card
    Ml = desk(rad(30.6), 2.14, 0.004) @ R(0.3, 'Z')
    B(0.15, 0.2, 0.004, '#5a3324', Ml @ T(0, 0, 0.002), bevel=0.0015, mat='leather', jit=0.03)
    B(0.141, 0.191, 0.022, '#e3d8ba', Ml @ T(0.003, 0, 0.015), bevel=0.001, mat='paper')
    B(0.15, 0.2, 0.004, '#5a3324', Ml @ T(0, 0, 0.028), bevel=0.0015, mat='leather', jit=0.03)
    B(0.006, 0.2, 0.03, '#4a2a1e', Ml @ T(-0.075, 0, 0.015), bevel=0.002, mat='leather')
    label('LOG', Ml @ T(0.005, 0.045, 0.0312) @ FLAT, 0.06)
    part(sheet(2, 6, lambda u, v: (0.03 + 0.012 * u, -0.1 - 0.05 * v, 0.016 - 0.014 * v * v), 0.0012), '#9a3524', 'in', Ml, bevel=0, mat='cloth', sharp=80)
    Mr = Ml @ T(0.01, -0.02, 0.0335) @ R(0.75, 'Z')
    B(0.21, 0.03, 0.005, '#d7c79c', Mr, bevel=0.001, mat='wood', jit=0.03)
    B(0.21, 0.011, 0.007, '#e6dcc0', Mr @ T(0.028, 0, 0.0005), bevel=0.001, mat='wood')
    B(0.012, 0.036, 0.008, BRASS, Mr @ T(-0.03, 0, 0.001), bevel=0.001, gloss=0.6)
    for k in range(22): B(0.0008, 0.005 if k % 5 else 0.008, 0.0012, DARK, Mr @ T(-0.098 + 0.009 * k, 0.012 - (0.0025 if k % 5 else 0.004), 0.003), bevel=0, mat='paint')
    label('notes', desk(rad(27.6), 2.215, 0.0055) @ R(-0.25, 'Z') @ FLAT, 0.13)
    Mc = desk(rad(47.5), 2.08, 0.006) @ R(rad(-14), 'Z')
    B(0.176, 0.246, 0.0016, '#e3d8ba', Mc @ R(0.07, 'Z') @ T(0.004, -0.006, 0.0046), bevel=0, mat='paper')
    Mpen = Mc @ T(0.135, -0.03, 0.0018) @ R(1.25, 'Z')
    Tu([(-0.075, 0, 0), (0.06, 0, 0)], 0.0036, '#c9a23a', 6, 1, Mpen, mat='paint')
    Tu([(0.06, 0, 0), (0.075, 0, 0)], lambda u: 0.0036 - 0.003 * u, '#d7c79c', 6, 1, Mpen, mat='wood')
    Tu([(-0.083, 0, 0), (-0.075, 0, 0)], 0.0038, BRASS, 6, 1, Mpen, gloss=0.6)
    Tu([Mc @ Vector((0.03, 0.125, 0.016)), Mc @ Vector((0.1, 0.11, 0.002)), Mc @ Vector((0.135, 0.03, 0.001)), Mpen @ Vector((-0.083, 0, 0.002))], 0.001, ROPE, 4, 4)
    # ---- a rag left over the edge at the right
    th0 = rad(53); prof = [(1.975, zd(1.975) + 0.0098), (1.9, zd(1.9) + 0.0098), (1.856, 1.7145), (1.832, 1.7325), (1.812, 1.716), (1.8135, 1.67), (1.818, 1.615)]
    def rag(u, v):
        t = v * (len(prof) - 1); i = min(int(t), len(prof) - 2); f = t - i
        r = prof[i][0] + (prof[i + 1][0] - prof[i][0]) * f; z = prof[i][1] + (prof[i + 1][1] - prof[i][1]) * f
        hang = max(0.0, v - 0.6)
        return P(th0 + (u - 0.5) * (0.085 - 0.03 * hang) + 0.012 * sin(v * 5), r - 0.006 * hang * sin(u * 9.0), z + 0.02 * hang * (u - 0.5) + 0.003 * sin(u * 11 + v * 4) * (v > 0.15))
    part(sheet(8, 18, rag, 0.0028), '#8f4a36', 'in', bevel=0, mat='cloth', jit=0.04, sharp=80, rough=0.0022, grit=18)
    # ---- on the lip either side: a row of telltale lamps, a row of fuses
    M = lipf(rad(-40), 1.63)
    B(0.3, 0.012, 0.1, ENAMEL, M @ T(0, -0.004, 0), bevel=0.004, seg=2, gloss=0.28, jit=0.02)
    B(0.284, 0.004, 0.084, BRASS, M @ T(0, -0.011, 0), bevel=0.0015, gloss=0.5)
    for k, (name, col, on) in enumerate((('OIL', '#8dffa0', 1), ('WATER', '#8dffa0', 1), ('FEED', '#ffb050', 0), ('DYNAMO', '#8dffa0', 1), ('SPARKS', '#ff6a4a', 0))):
        x = -0.112 + 0.056 * k
        bead(M @ T(x, -0.013, 0.016), None, col, 0.0085, glow=1.1 * on)
        label(name, M @ T(x, -0.0142, -0.022), 0.05)
    for sx in (-1, 1):
        for sz in (-1, 1): screw(M @ T(sx * 0.133, -0.013, sz * 0.033), 0.0035)
    M = lipf(rad(40), 1.63)
    B(0.27, 0.012, 0.1, INS, M @ T(0, -0.004, 0), bevel=0.004, seg=2, gloss=0.28)
    for k in range(6): fuse(M @ T(-0.09 + 0.036 * k, -0.010, 0.012) @ R(pi / 2, 'Y'))
    label('FUSES', M @ T(0, -0.0113, -0.034), 0.06)
    for sx in (-1, 1):
        for sz in (-1, 1): screw(M @ T(sx * 0.122, -0.010, sz * 0.038), 0.0035)


# ------------------------------------------------------------------------------------------- under the desk
def under_desk():
    # ---- the furniture of its five doors
    for a, name in ((-44, 'SPARES'), (-22, 'CHARTS'), (0, 'ODDS'), (22, 'RATIONS'), (44, 'TOOLS')):
        M = door(a)
        for sx in (-1, 1):
            for sz in (-1, 1):
                B(0.046, 0.004, 0.046, BRASS, M @ T(sx * 0.286, -0.013, sz * 0.206), bevel=0.0015, gloss=0.5)
                part(cyl(0.004, 0.003, 6), STEEL, 'in', M @ T(sx * 0.286, -0.0165, sz * 0.206) @ YA, bevel=0, gloss=0.6)
        if a == 44: plate(name, M @ T(0, -0.014, 0.2), 0.085)
        else: plate(name, M @ T(0, -0.021, 0.035 if a else 0.06), 0.085)
        part(cyl(0.012, 0.003, 10), BRASS, 'in', M @ T(0.2, -0.0205, 0.0) @ YA, bevel=0, gloss=0.6)
        B(0.003, 0.001, 0.011, DARK, M @ T(0.2, -0.0225, -0.001), bevel=0, mat='paint')
        if a == 0:
            for k in range(6): B(0.3, 0.012, 0.004, WOOD_D, M @ T(0, -0.024, -0.14 + 0.024 * k) @ R(rad(-35), 'X'), bevel=0.001)
    # ---- a strip of brass along its foot, against boots
    z0, z1 = ZF + 0.003, ZF + 0.075
    part(lathe([(rf(z0) - 0.0055, z0), (rf(z1) - 0.0055, z1), (rf(z1) + 0.002, z1), (rf(z0) + 0.002, z0)], 30, rad(-58), rad(58), close=True), BRASS, 'in', bevel=0.0015, seg=1, gloss=0.5)
    for a in range(-54, 55, 12): part(cyl(0.005, 0.003, 6), STEEL, 'in', front(rad(a), ZF + 0.04) @ T(0, -0.007, 0) @ YA, bevel=0, gloss=0.6)
    label('DO NOT KICK', front(rad(6), ZF + 0.04) @ T(0, -0.0075, 0), 0.11)
    # ---- two pipes under the lip, with a valve and a gauge on the fat one
    z = 1.535; n27 = lambda th: V3(-sin(th) * 0.891, -cos(th) * 0.891, -0.454)
    pp = lambda th: P(th, rf(z), z) + n27(th) * 0.0135
    Tu([pp(rad(a)) for a in range(-52, 53, 4)], 0.011, COPPER, 8, 1, gloss=0.6)
    for a in (-52, 52):
        th = rad(a); p = pp(th)
        part(ball(0.0155, 10, 8), BRASS, 'in', T(*p), bevel=0, gloss=0.6)
        Tu([p, p - n27(th) * 0.03], 0.0125, BRASS, 8, 1, gloss=0.6)
    for a in (-46, -33, -20, -6, 6, 20, 33, 46):
        th = rad(a); saddle(pp(th), V3(cos(th), -sin(th), 0), n27(th), 0.011)
    for a in (-40, -10, 10, 40):
        th = rad(a); d = V3(cos(th), -sin(th), 0); part(tube([pp(th) - d * 0.012, pp(th) + d * 0.012], 0.0145, 6, 1), BRASS, 'in', bevel=0, gloss=0.6)
    th = rad(-27); p = pp(th); nn = n27(th)
    part(ball(0.02, 12, 8), BRASS, 'in', T(*p), bevel=0, gloss=0.6)
    Tu([p, p + nn * 0.05], 0.006, BRASS, 6, 1, gloss=0.6)
    handwheel(aim(p + nn * 0.048, p + nn), 0.034)
    th = rad(27); p = pp(th); nn = n27(th)
    part(ball(0.018, 12, 8), BRASS, 'in', T(*p), bevel=0, gloss=0.6)
    gauge(front(th, z) @ T(0, -0.062, 0), 0.028, 'gauge_b', live=False)
    z2 = 1.553; p2 = lambda th: P(th, rf(z2), z2) + n27(th) * 0.0068
    Tu([p2(rad(a)) for a in range(-40, 41, 4)], 0.0055, STEEL, 6, 1, gloss=0.6)
    for a in (-40, 40):
        th = rad(a); p = p2(th)
        part(ball(0.009, 8, 6), BRASS, 'in', T(*p), bevel=0, gloss=0.6)
        Tu([p, p - n27(th) * 0.02], 0.0068, BRASS, 6, 1, gloss=0.6)
    for a in (-30, -14, 14, 30):
        th = rad(a); saddle(p2(th), V3(cos(th), -sin(th), 0), n27(th), 0.0055)
    # ---- two pedals, their rods back into the desk, a plate of brass for each heel
    for sx in (-1, 1):
        x = sx * 0.17
        B(0.1, 0.06, 0.02, IRON, T(x, 1.60, ZF + 0.01), bevel=0.004, gloss=0.4)
        Tu([(x - 0.058, 1.60, ZF + 0.03), (x + 0.058, 1.60, ZF + 0.03)], 0.008, STEEL, 8, 1, gloss=0.6)
        Mp = T(x, 1.60, ZF + 0.03) @ R(-rad(22), 'X')
        B(0.1, 0.012, 0.175, IRON, Mp @ T(0, 0, 0.09), bevel=0.004, seg=2, gloss=0.4)
        B(0.086, 0.007, 0.15, RUBBER, Mp @ T(0, -0.0095, 0.095), bevel=0.002)
        for k in range(6): B(0.086, 0.005, 0.007, RUBBER, Mp @ T(0, -0.0145, 0.035 + 0.024 * k), bevel=0.001)
        a0 = Mp @ Vector((0, 0.008, 0.165)); th = atan2(x, 1.97)
        Tu([a0, P(th, rf(1.31) + 0.01, 1.31)], 0.006, STEEL, 6, 1, gloss=0.6)
        part(cyl(0.016, 0.006, 8), BRASS, 'in', front(th, 1.31) @ T(0, -0.003, 0) @ YA, bevel=0.001, seg=1, gloss=0.6)
        B(0.012, 0.02, 0.016, STEEL, T(*a0), bevel=0.002, gloss=0.6)
        B(0.125, 0.19, 0.004, BRASS, T(x, 1.47, ZF + 0.002), bevel=0.001, gloss=0.5)
        for k in range(5): B(0.11, 0.006, 0.003, BRASS, T(x, 1.395 + 0.036 * k, ZF + 0.0052), bevel=0.001, gloss=0.5)
    # ---- a roll of tools hung open before the right-hand door
    Dh = door(44); w0 = Dh @ Vector((0, -0.05, 0.085)); Hh = T(*w0) @ R(-rad(44), 'Z')
    for sx in (-1, 1):
        Tu([Dh @ Vector((sx * 0.2, -0.019, 0.1)), Dh @ Vector((sx * 0.2, -0.045, 0.1)), Dh @ Vector((sx * 0.2, -0.05, 0.118))], 0.004, BRASS, 6, 3, gloss=0.6)
        Tu([Dh @ Vector((sx * 0.2, -0.047, 0.106)), Hh @ Vector((sx * 0.205, 0.0, -0.006))], 0.002, ROPE, 4, 1)
    cloth = lambda u, v: (-0.23 + 0.46 * u, 0.006 * sin(u * 13 + v * 2) + 0.012 * v * v, -0.3 * v + 0.004 * sin(u * 8))
    part(sheet(16, 8, cloth, 0.004), '#9a8a62', 'in', Hh, bevel=0, mat='canvas', jit=0.04, sharp=80, rough=0.003, grit=14)
    pocket = lambda u, v: (-0.225 + 0.45 * u, -0.007 - 0.016 * abs(sin(u * pi * 6)) + 0.012 * (0.45 + 0.55 * v) ** 2, -0.135 - 0.16 * v)
    part(sheet(36, 4, pocket, 0.003), '#8a7a55', 'in', Hh, bevel=0, mat='canvas', jit=0.04, sharp=80)
    B(0.47, 0.012, 0.014, LEATHER, Hh @ T(0, 0.0, -0.004), bevel=0.003)
    for k in range(6):
        x = -0.225 + 0.45 * (k + 0.5) / 6; Mt = Hh @ T(x, -0.009, 0)
        if k in (0, 3):      # a screwdriver, a chisel
            Tu([(0, 0, -0.125), (0, 0, -0.045)], 0.0115 if k == 0 else 0.014, WOOD, 8, 1, Mt, jit=0.06)
            Tu([(0, 0, -0.135), (0, 0, -0.123)], 0.0125 if k == 0 else 0.015, BRASS, 8, 1, Mt, gloss=0.6)
            Tu([(0, 0, -0.2), (0, 0, -0.135)], 0.004, STEEL, 6, 1, Mt, gloss=0.6)
        elif k == 1:         # a spanner
            B(0.014, 0.004, 0.13, STEEL, Mt @ T(0, 0, -0.12), bevel=0.001, gloss=0.6)
            part(tube([(0.014 * cos(i * pi / 5), 0, -0.045 + 0.014 * sin(i * pi / 5)) for i in range(10)], 0.004, 5, 1, cyclic=True), STEEL, 'in', Mt, bevel=0, gloss=0.6)
        elif k == 2:         # pliers
            for s2 in (-1, 1): Tu([(s2 * 0.004, 0, -0.14), (s2 * 0.012, 0, -0.05)], 0.0055, '#9a3524', 6, 1, Mt, mat='rubber')
            Tu([(0, 0, -0.2), (0, 0, -0.14)], 0.006, STEEL, 6, 1, Mt, gloss=0.6)
        elif k == 4:         # a file
            Tu([(0, 0, -0.12), (0, 0, -0.06)], 0.0105, WOOD_D, 8, 1, Mt, jit=0.06)
            B(0.016, 0.004, 0.1, STEEL, Mt @ T(0, 0, -0.17), bevel=0.001, gloss=0.5)
        else:                # a hammer, head up
            Tu([(0, 0, -0.2), (0, 0, -0.06)], 0.009, WOOD, 8, 1, Mt, jit=0.06)
            B(0.07, 0.022, 0.022, IRON, Mt @ T(0.006, 0, -0.05), bevel=0.004, gloss=0.5)
    Tu([Hh @ Vector(p) for p in ((0.232, 0.0, -0.15), (0.26, -0.01, -0.19), (0.25, 0.0, -0.26), (0.262, 0.004, -0.33))], 0.0022, ROPE, 4, 4)
    Tu([Hh @ Vector(p) for p in ((0.232, 0.0, -0.15), (0.245, -0.012, -0.21), (0.236, -0.004, -0.29))], 0.0022, ROPE, 4, 4)
    # ---- a fire bottle on the left, strapped to a board
    F = front(rad(-33), 1.335)
    B(0.13, 0.012, 0.3, WOOD_D, F @ T(0, -0.006, 0), bevel=0.004)
    for sz in (-1, 1): screw(F @ T(0.05, -0.012, sz * 0.12), 0.004); screw(F @ T(-0.05, -0.012, sz * 0.12), 0.004)
    Fb = F @ T(0, -0.07, 0)
    part(lathe([(0, -0.13), (0.045, -0.13), (0.055, -0.115), (0.055, 0.07), (0.045, 0.105), (0.022, 0.125), (0.018, 0.14), (0, 0.14)], 18), '#a33a26', 'in', Fb, bevel=0, mat='enamel', gloss=0.35, jit=0.03)
    part(cyl(0.02, 0.03, 10), BRASS, 'in', Fb @ T(0, 0, 0.152), bevel=0.003, seg=1, gloss=0.6)
    B(0.012, 0.075, 0.007, STEEL, Fb @ T(0, -0.03, 0.176) @ R(-0.3, 'X'), bevel=0.002, gloss=0.6)
    part(lathe([(0.004, 0), (0.006, 0.01), (0.014, 0.035), (0.012, 0.035), (0.004, 0.012)], 10, close=True), DARK, 'in', Fb @ T(0, -0.02, 0.152) @ YA, bevel=0)
    for z in (-0.07, 0.04):
        part(lathe([(0.0555, -0.009), (0.0585, -0.009), (0.0585, 0.009), (0.0555, 0.009)], 18, close=True), STEEL, 'in', Fb @ T(0, 0, z), bevel=0, gloss=0.6)
        B(0.02, 0.012, 0.022, STEEL, Fb @ T(0, -0.062, z), bevel=0.002, gloss=0.6)
        for sx in (-1, 1): B(0.012, 0.06, 0.018, STEEL, Fb @ T(sx * 0.056, 0.03, z), bevel=0.002, gloss=0.6)
    B(0.1, 0.08, 0.012, IRON, F @ T(0, -0.05, -0.139), bevel=0.003, gloss=0.4)
    plate('FIRE', Fb @ T(0, -0.0565, -0.015), 0.04)


# ------------------------------------------------------------------------------------------------ and more
def more():
    Mw = Mradio()
    # ---- the wireless: brass at its corners, a strap to carry it by, its tape run out over the desk, a pad for what it says
    for sx in (-1, 1):
        for sz in (-1, 1):
            B(0.034, 0.006, 0.034, BRASS, Mw @ T(sx * 0.142, -0.0015, sz * 0.092), bevel=0.0015, gloss=0.5)
            screw(Mw @ T(sx * 0.142, -0.0045, sz * 0.092), 0.0035)
        B(0.032, 0.032, 0.004, BRASS, Mw @ T(sx * 0.09, 0.1, 0.1215), bevel=0.001, gloss=0.5)
    part(strap([Mw @ Vector(p) for p in ((-0.09, 0.1, 0.122), (-0.055, 0.1, 0.152), (0.055, 0.1, 0.152), (0.09, 0.1, 0.122))], 0.022, 0.004, Mw.to_3x3() @ V3(0, 1, 0)), LEATHER, 'in', bevel=0, jit=0.03)
    tang = lambda a: V3(cos(rad(a)), -sin(rad(a)), 0)
    for sx in (-1, 1):
        f = Mw @ Vector((sx * 0.13, 0.02, -0.117)); Tu([f, down(f, 0.004)], 0.0075, BRASS, 6, 1, gloss=0.6)
        part(cyl(0.014, 0.004, 8), BRASS, 'in', ondesk(f, 0.006), bevel=0, gloss=0.6)
    B(0.02, 0.003, 0.005, DARK, Mw @ T(-0.065, -0.0008, -0.1), bevel=0, mat='paint')
    tape = [Mw @ Vector((-0.065, -0.002, -0.1)), Mw @ Vector((-0.065, -0.035, -0.115))] + [P(rad(a), r, zd(r) + h) for a, r, h in ((-53.8, 2.03, 0.03), (-53.6, 1.99, 0.0072), (-53.5, 1.955, 0.0076), (-53.7, 1.932, 0.014), (-53.6, 1.92, 0.026))]
    part(strap(tape, 0.012, 0.0007, tang(-53.7)), '#e8dfc6', 'in', bevel=0, mat='paper', sharp=80)
    Mp = desk(rad(-47.3), 1.965, 0.004) @ R(-0.2, 'Z')
    B(0.07, 0.1, 0.009, '#e3d8ba', Mp @ T(0, 0, 0.0045), bevel=0.001, mat='paper')
    B(0.072, 0.012, 0.0095, '#5a3324', Mp @ T(0, 0.045, 0.0048), bevel=0.001, mat='leather')
    Tu([(-0.01, -0.03, 0.0125), (0.035, 0.01, 0.0125)], 0.0034, '#9a3524', 6, 1, Mp, mat='paint')
    Tu([(0.035, 0.01, 0.0125), (0.044, 0.018, 0.0125)], lambda u: 0.0034 - 0.0028 * u, '#d7c79c', 6, 1, Mp, mat='wood')
    # ---- brass tacks along the two long edges of the desk's mat
    for a in range(-54, 55, 4):
        if abs(a - 13.4) > 3.5 and abs(a) > 9: part(ball(0.0042, 6, 4, s=(1, 1, 0.55)), BRASS, 'in', desk(rad(a), 1.906, 0.004), bevel=0, gloss=0.6)
        if min(abs(abs(a) - 44), abs(abs(a) - 24)) > 1.5 and abs(a + 2) > 9.5: part(ball(0.0042, 6, 4, s=(1, 1, 0.55)), BRASS, 'in', desk(rad(a + 2), 2.2745, 0.004), bevel=0, gloss=0.6)
    # ---- the lamp at the right: its switch, and its lead to the back of the desk
    b = P(rad(53), 2.16, zd(2.16))
    Tu([b + V3(0.03, 0.03, 0.012), P(rad(54.3), 2.22, zd(2.22) + 0.0075), P(rad(54.6), 2.286, zd(2.286) + 0.008)], 0.003, RUBBER, 5, 3, mat='rubber')
    part(cyl(0.006, 0.012, 6), DARK, 'in', T(*b) @ R(rad(19.6), 'X') @ T(-0.03, -0.02, 0.02), bevel=0, mat='rubber')
    # ---- over the window: rolled charts in two leather loops at the left, a pair of goggles on a hook at the right
    q = lambda a, r, z: P(rad(a), r, z)
    for (r, z, col, rr) in ((2.286, 3.298, '#dccfa8', 0.02), (2.25, 3.3, '#cfc09a', 0.017), (2.27, 3.33, '#d6c6a0', 0.015)):
        Tu([q(-26.5 + (0.7 if rr < 0.02 else 0), r, z), q(-14.8 - (1.0 if rr < 0.017 else 0), r, z)], rr, col, 10, 1, mat='paper', jit=0.03)
    for a in (-23.6, -17.6):
        c = q(a, 2.269, 3.306); tg = tang(a); rd = V3(sin(rad(a)), cos(rad(a)), 0)
        loop = [c + rd * (0.047 * cos(i * pi / 8)) + V3(0, 0, 0.043 * sin(i * pi / 8)) for i in range(16)]
        part(strap(loop + loop[:1], 0.02, 0.003, tg), LEATHER, 'in', bevel=0, jit=0.03)
        Tu([c + rd * 0.03 + V3(0, 0, 0.04), q(a, 2.33, 3.345)], 0.0035, BRASS, 5, 1, gloss=0.6)
    c = q(24.5, 2.262, 3.215); tg = tang(24.5); rd = V3(sin(rad(24.5)), cos(rad(24.5)), 0)
    Tu([q(24.5, 2.33, 3.33), q(24.5, 2.3, 3.335), q(24.5, 2.29, 3.315)], 0.003, BRASS, 5, 3, gloss=0.6)
    part(strap([c - tg * 0.06, c - tg * 0.062 + V3(0, 0, 0.05) + rd * 0.02, q(24.5, 2.291, 3.318), c + tg * 0.062 + V3(0, 0, 0.05) + rd * 0.02, c + tg * 0.06], 0.014, 0.002, rd), '#4a3226', 'in', bevel=0, mat='leather')
    for sx in (-1, 1):
        Mg = aim(c + tg * sx * 0.032, c + tg * sx * 0.032 - rd)
        part(lathe([(0.0, -0.012), (0.02, -0.012), (0.026, -0.006), (0.026, 0.012), (0.022, 0.012), (0.022, 0.0), (0.0, 0.0)], 12), BRASS, 'in', Mg, bevel=0, gloss=0.6)
        part(cyl(0.022, 0.002, 12), '#7f9a8a', 'in', Mg @ T(0, 0, 0.006), bevel=0, mat='glassy', gloss=0.6)
        part(lathe([(0.0265, -0.004), (0.031, -0.008), (0.031, 0.004), (0.0265, 0.006)], 12, close=True), '#4a3226', 'in', Mg, bevel=0, mat='leather')
    B(0.012, 0.006, 0.006, '#4a3226', T(*c) @ R(-rad(24.5), 'Z'), bevel=0.001, mat='leather')
    # ---- at the two ends of the desk: a coil of rope on a peg, a satchel on a hook
    E = at(rad(-59), 2.16, 1.56) @ R(-pi / 2, 'Z')
    Tu([(0, 0.01, 0), (0, -0.04, 0.006), (0, -0.045, 0.02)], 0.006, BRASS, 6, 3, E, gloss=0.6)
    part(cyl(0.016, 0.004, 8), BRASS, 'in', E @ T(0, -0.002, 0) @ YA, bevel=0, gloss=0.6)
    for k in range(4):
        rr = 0.105 + 0.006 * (k % 2); dy = -0.012 - 0.009 * k
        part(tube([(rr * sin(i * pi / 12) * (1 - 0.06 * k), dy + 0.004 * sin(i * 0.9 + k), -0.105 + (rr + 0.01) * cos(i * pi / 12) * 0.98 + 0.012) for i in range(24)], 0.0075, 6, 1, cyclic=True), ROPE, 'in', E, bevel=0, jit=0.05)
    part(tube([(0, -0.0255 + 0.027 * cos(i * pi / 5), -0.209 + 0.017 * sin(i * pi / 5)) for i in range(10)], 0.004, 5, 1, cyclic=True), '#7a2f22', 'in', E, bevel=0, mat='cloth')
    E = at(rad(59), 2.18, 1.6) @ R(pi / 2, 'Z')
    Tu([(0, 0.01, 0), (0, -0.045, 0.006), (0, -0.05, 0.022)], 0.006, BRASS, 6, 3, E, gloss=0.6)
    part(cyl(0.016, 0.004, 8), BRASS, 'in', E @ T(0, -0.002, 0) @ YA, bevel=0, gloss=0.6)
    part(strap([E @ Vector(p) for p in ((-0.085, -0.035, -0.12), (-0.05, -0.04, -0.03), (0, -0.046, 0.012), (0.05, -0.04, -0.03), (0.085, -0.035, -0.12))], 0.02, 0.003, E.to_3x3() @ V3(0, 1, 0)), '#6a4a30', 'in', bevel=0, mat='leather')
    part(box(0.2, 0.06, 0.15), '#8c7a52', 'in', E @ T(0, -0.036, -0.2), bevel=0.02, seg=2, mat='canvas', jit=0.04, sub=1, rough=0.005, grit=9)
    part(sheet(8, 4, lambda u, v: (-0.102 + 0.204 * u, -0.068 - 0.006 * sin(pi * u) - 0.004 * v, -0.123 - 0.085 * v - 0.008 * sin(pi * u) * v), 0.004), '#7a6842', 'in', E, bevel=0, mat='canvas', jit=0.04, sharp=80)
    for sx in (-1, 1):
        B(0.018, 0.004, 0.07, '#6a4a30', E @ T(sx * 0.055, -0.0755, -0.19), bevel=0.001, mat='leather')
        B(0.024, 0.006, 0.016, BRASS, E @ T(sx * 0.055, -0.0775, -0.212), bevel=0.001, gloss=0.6)

    # ---- a striped edge on the board the fire bottle hangs from, top and bottom, and along the top of each pedal
    F = front(rad(-33), 1.335)
    for z in (-0.145, 0.145): B(0.13, 0.004, 0.012, RED, F @ T(0, -0.0138, z), bevel=0.001, mat='stripe')
    for sx in (-1, 1): B(0.1, 0.004, 0.008, RED, T(sx * 0.17, 1.60, ZF + 0.03) @ R(-rad(22), 'X') @ T(0, -0.0078, 0.1745), bevel=0.001, mat='stripe')
    # ---- a small plant in a tin on the sill, where the pilot can see it
    Ms = T(*P(rad(-14.3), 2.39, 1.94))
    part(lathe([(0, 0), (0.027, 0), (0.029, 0.004), (0.029, 0.046), (0.031, 0.05), (0.026, 0.05), (0.026, 0.042), (0, 0.042)], 14), '#8d8f8a', 'in', Ms, bevel=0, mat='tin', gloss=0.5, jit=0.03)
    for z in (0.012, 0.034): part(lathe([(0.0292, z - 0.0015), (0.0302, z - 0.0015), (0.0302, z + 0.0015), (0.0292, z + 0.0015)], 14, close=True), '#8d8f8a', 'in', Ms, bevel=0, mat='tin', gloss=0.5)
    part(cyl(0.0258, 0.003, 12), '#3a2a1e', 'in', Ms @ T(0, 0, 0.0435), bevel=0, mat='soot')
    for ring, (n, tilt, rr, sz) in enumerate(((8, 62, 0.019, 1.0), (6, 38, 0.011, 0.85), (3, 14, 0.004, 0.7))):
        for k in range(n):
            Ml = Ms @ T(0, 0, 0.046) @ R(k * 2 * pi / n + ring * 0.4, 'Z') @ T(rr, 0, 0) @ R(rad(tilt), 'Y')
            part(ball(0.0085 * sz, 6, 5, s=(1, 0.5, 2.6)), '#7fa06a', 'in', Ml @ T(0, 0, 0.018 * sz), bevel=0, mat='glaze', gloss=0.3, jit=0.08)
    # ---- on the next posts out: a bell with its cord at the right, a pair of field glasses on a hook at the left
    M = at(rad(36), 2.38, 2.64)
    B(0.03, 0.005, 0.07, BRASS, M @ T(0, -0.0095, 0), bevel=0.0015, gloss=0.5)
    for z in (-0.026, 0.026): screw(M @ T(0, -0.012, z), 0.0035)
    Tu([(0, -0.012, 0.01), (0, -0.05, 0.03), (0, -0.075, 0.012)], 0.005, BRASS, 6, 3, M, gloss=0.6)
    Mbell = M @ T(0, -0.075, 0.008)
    part(lathe([(0.0, 0.0), (0.008, -0.002), (0.018, -0.012), (0.026, -0.032), (0.035, -0.05), (0.032, -0.05), (0.0235, -0.032), (0.015, -0.014), (0.0, -0.006)], 16, close=True), BRASS, 'in', Mbell, bevel=0, gloss=0.7)
    part(ball(0.007, 8, 6), IRON, 'in', Mbell @ T(0.004, 0, -0.047), bevel=0, gloss=0.4)
    Tu([(0, 0, -0.006), (0.004, 0, -0.047)], 0.0018, IRON, 4, 1, Mbell, gloss=0.4)
    Tu([(0.004, 0, -0.05), (0.008, -0.002, -0.1), (0.004, 0, -0.15)], 0.0016, ROPE, 4, 3, Mbell)
    part(lathe([(0, -0.016), (0.006, -0.011), (0.007, 0.0), (0.004, 0.008), (0, 0.01)], 8), WOOD, 'in', Mbell @ T(0.004, 0, -0.158), bevel=0, jit=0.05)
    plate('BELL', at(rad(36), 2.38, 2.44) @ T(0, -0.0085, 0), 0.04)
    M = at(rad(-36), 2.38, 2.68)
    B(0.026, 0.005, 0.04, BRASS, M @ T(0, -0.0095, 0), bevel=0.0015, gloss=0.5)
    Tu([(0, -0.012, 0), (0, -0.04, 0.004), (0, -0.046, 0.02)], 0.004, BRASS, 6, 3, M, gloss=0.6)
    part(strap([M @ Vector(pt) for pt in ((-0.03, -0.034, -0.13), (-0.026, -0.036, -0.06), (0, -0.042, 0.008), (0.026, -0.036, -0.06), (0.03, -0.034, -0.13))], 0.012, 0.002, M.to_3x3() @ V3(0, 1, 0)), '#4a3226', 'in', bevel=0, mat='leather')
    for sx in (-1, 1):
        Mg = M @ T(sx * 0.025, -0.034, -0.18)
        part(lathe([(0, -0.05), (0.022, -0.05), (0.024, -0.044), (0.021, -0.02), (0.016, 0.02), (0.016, 0.045), (0.0185, 0.05), (0, 0.05)], 12), '#3a3026', 'in', Mg, bevel=0, mat='leather', jit=0.03)
        for z in (-0.047, 0.046): part(lathe([(0.0165 if z > 0 else 0.0225, z - 0.004), (0.0195 if z > 0 else 0.0255, z - 0.004), (0.0195 if z > 0 else 0.0255, z + 0.004), (0.0165 if z > 0 else 0.0225, z + 0.004)], 12, close=True), BRASS, 'in', Mg, bevel=0, gloss=0.6)
        part(cyl(0.021, 0.002, 12), '#7f9a8a', 'in', Mg @ T(0, 0, -0.0505), bevel=0, mat='glassy', gloss=0.6)
    B(0.03, 0.01, 0.012, BRASS, M @ T(0, -0.034, -0.165), bevel=0.002, gloss=0.6)
    part(cyl(0.006, 0.014, 8), BRASS, 'in', M @ T(0, -0.034, -0.15), bevel=0.001, seg=1, gloss=0.6)
    # ---- and the name of what the valve under the lip shuts
    plate('FUEL', door(-22) @ T(-0.19, -0.014, 0.2), 0.06)


# ----------------------------------------------------------------- the three boards on the lip, before the knees
def lip_panels():
    """
    Where the old screen's case hung, on the upright lip under the desk's front edge: three enamelled boards, the
    middle one cream with four fat pushes, the two beside it grey-green, with what starts and feeds the ship.
    """
    for a, col in ((-5.4, INS), (0.0, ENAMEL), (5.4, INS)):
        M = lipf(rad(a), 1.628); yf = -0.013
        B(0.168, 0.014, 0.106, col, M @ T(0, -0.006, 0), bevel=0.004, seg=2, gloss=0.28, jit=0.02)
        for sx in (-1, 1):
            for sz in (-1, 1): screw(M @ T(sx * 0.074, yf, sz * 0.043), 0.0035)
        if a == 0:
            for k, (c, name) in enumerate((('#a33a26', 'PUMP'), ('#c9a23a', 'VENT'), ('#3f6b5a', 'FANS'), ('#2f4a5a', 'HEATER'))):
                x = -0.054 + 0.036 * k
                pushbtn(M @ T(x, yf, 0.008), c, 0.0125)
                label(name, M @ T(x, yf - 0.0012, -0.021), 0.033)
                bead(M @ T(x, yf, 0.036), None, '#8dffa0' if k != 1 else '#ffb050', 0.0048, glow=1.0 if k in (0, 2) else 0.0)
            B(0.13, 0.003, 0.009, RED, M @ T(0, yf - 0.0006, -0.041), bevel=0.0008, mat='stripe')
        elif a < 0:
            for sx, name, c, turn in ((-1, 'MAIN', CREAM, 0.6), (1, 'AUX', '#a33a26', -0.4)):
                Mk = M @ T(sx * 0.038, yf, 0.004)
                B(0.062, 0.003, 0.062, BRASS, Mk @ T(0, -0.0005, 0), bevel=0.0012, gloss=0.5)
                for k in range(5): B(0.0026, 0.002, 0.007, DARK, Mk @ R(rad(-60 + 30 * k), 'Y') @ T(0, -0.0024, 0.0255), bevel=0, mat='paint')
                knob(Mk @ T(0, -0.002, 0), 0.016, 0.02, c, turn=turn)
                label(name, M @ T(sx * 0.038, yf - 0.0012, -0.04), 0.033)
        else:
            gauge(M @ T(-0.04, yf, 0.003), 0.026, 'gauge_c', live=False)
            for k, name in enumerate(('LAMPS', 'STOVE')):
                x = 0.022 + 0.04 * k
                toggle(M @ T(x, yf, 0.012), up=k == 0, tip='#a33a26' if k else STEEL)
                guard(M @ T(x, yf, 0.012))
                label(name, M @ T(x, yf - 0.0012, -0.03), 0.033)
    # (a lead from board to board, low, in two clips)
    for a in (-2.7, 2.7):
        M = lipf(rad(a), 1.584)
        Tu([(-0.03, -0.004, 0.004), (-0.012, -0.012, -0.008), (0.012, -0.012, -0.008), (0.03, -0.004, 0.004)], 0.0032, RUBBER, 5, 3, M, mat='rubber')


# -------------------------------------------------------------------------------- what is on the back of the seat
def seat_back():
    """Seen from the room: a blanket over one shoulder of it, a bottle of air strapped to the other, stripes on its foot."""
    sy, z0 = SEAT_Y, ZF
    Mb = T(0, sy - 0.285, z0 + 0.94) @ R(rad(11), 'X'); Mi = Mb.inverted()
    # ---- a striped blanket, folded over the top of it
    def blanket(u, v):
        x = -0.274 + 0.2 * u
        if v < 0.1:
            t = v / 0.1
            return (x, -0.032 - 0.056 * t, 0.4165 + 0.006 * sin(pi * t) - 0.004 * t)
        t = (v - 0.1) / 0.9
        return (x + 0.004 * sin(t * 5), -0.091 - 0.005 * sin(u * 8 + t * 4) * t - 0.004 * t, 0.4125 - 0.3 * t + 0.006 * sin(u * 6) * t)
    part(sheet(8, 56, blanket, 0.008), lambda q: '#d9cfb8' if ((Mi @ q).z * 15.5) % 1.0 < 0.2 else '#9a3524' if ((Mi @ q).z * 15.5) % 2.0 < 1.0 else '#8a2f20', 'in', Mb, bevel=0, mat='knit', jit=0.03, sharp=80, rough=0.003, grit=14)
    # ---- a bottle of air: sage, with a cream band; two saddles of wood, two straps; a valve, a small glass, a hose
    Ma = Mb @ T(0.165, -0.146, -0.02)
    def paint(q):
        z = (Mi @ q).z + 0.02
        return '#d9cfb8' if 0.12 < z < 0.17 else '#6f8a6a'
    part(lathe([(0, 0), (0.03, 0.004), (0.047, 0.018), (0.052, 0.04), (0.052, 0.12), (0.052, 0.17), (0.052, 0.292), (0.047, 0.318), (0.032, 0.338), (0.019, 0.346), (0.019, 0.362), (0, 0.362)], 20), paint, 'in', Ma, bevel=0, mat='enamel', gloss=0.32, jit=0.02, cuts=None)
    for z in (0.07, 0.25):
        B(0.1, 0.05, 0.034, WOOD_D, Mb @ T(0.165, -0.093, -0.02 + z), bevel=0.004, seg=2)
        part(lathe([(0.0525, -0.012), (0.0555, -0.012), (0.0555, 0.012), (0.0525, 0.012)], 20, close=True), LEATHER, 'in', Ma @ T(0, 0, z), bevel=0, jit=0.03)
        B(0.026, 0.008, 0.03, BRASS, Ma @ T(0, -0.0575, z), bevel=0.002, gloss=0.6)
        B(0.014, 0.01, 0.006, STEEL, Ma @ T(0, -0.0585, z), bevel=0.001, gloss=0.6)
    part(cyl(0.015, 0.03, 10), BRASS, 'in', Ma @ T(0, 0, 0.375), bevel=0.003, seg=1, gloss=0.6)
    Tu([(0, 0, 0.378), (0, -0.04, 0.378)], 0.0055, BRASS, 6, 1, Ma, gloss=0.6)
    handwheel(Ma @ T(0, -0.042, 0.378) @ R(pi / 2, 'X'), 0.026)
    Tu([(0, 0, 0.378), (0.034, 0, 0.378)], 0.006, BRASS, 6, 1, Ma, gloss=0.6)
    gauge(Ma @ T(0.05, -0.012, 0.378) @ R(-0.5, 'Z'), 0.018, 'gauge_a', live=False)
    Tu([(-0.014, 0, 0.38), (-0.05, -0.01, 0.37), (-0.066, -0.02, 0.3), (-0.058, -0.03, 0.17), (-0.064, -0.02, 0.09)], 0.006, RUBBER, 6, 4, Ma, mat='rubber')
    part(lathe([(0.006, 0), (0.008, 0.012), (0.015, 0.03), (0.013, 0.031), (0.005, 0.012)], 10, close=True), '#2b2c33', 'in', Ma @ T(-0.064, -0.02, 0.09) @ R(pi, 'X'), bevel=0, mat='rubber')
    plate('AIR', Ma @ T(0, -0.0528, 0.145), 0.038)
    # ---- stripes along the batten at its foot
    B(0.5, 0.004, 0.012, RED, Mb @ T(0, -0.0858, -0.365), bevel=0.001, mat='stripe')


# ------------------------------------------------------------------------------- tins, by the pilot's right hand
def tins():
    """A caddy of tea and a tin of biscuits on the desk, between the glass and the push glass."""
    M = desk(atan2(0.435, 2.172), hypot(0.435, 2.172)) @ R(-rad(19.6), 'X') @ T(0, 0, -0.012)
    part(lathe([(0, 0), (0.04, 0), (0.042, 0.003), (0.042, 0.092), (0.04, 0.095), (0, 0.095)], 18), '#a33a26', 'in', M, bevel=0, mat='enamel', gloss=0.35, jit=0.03)
    part(lathe([(0.0424, 0.036), (0.0432, 0.036), (0.0432, 0.07), (0.0424, 0.07)], 18, close=True), '#d9cfb8', 'in', M, bevel=0, mat='enamel', gloss=0.3)
    part(lathe([(0, 0.095), (0.043, 0.095), (0.0435, 0.108), (0.038, 0.112), (0.01, 0.113), (0.009, 0.122), (0.012, 0.128), (0, 0.13)], 18), BRASS, 'in', M, bevel=0, gloss=0.6)
    label('TEA', M @ T(0, 0, 0.053) @ R(-(atan2(0.435, 2.172 - 0.68) - atan2(0.435, 2.172)), 'Z') @ T(0, -0.0436, 0), 0.03)
    Mt = desk(atan2(0.44, 2.045), hypot(0.44, 2.045), 0.004) @ R(0.3, 'Z')
    B(0.115, 0.08, 0.05, '#d8b24a', Mt @ T(0, 0, 0.025), bevel=0.004, seg=2, mat='enamel', gloss=0.32, jit=0.03)
    B(0.119, 0.084, 0.014, '#a33a26', Mt @ T(0, 0, 0.05), bevel=0.003, seg=2, mat='enamel', gloss=0.32, jit=0.03)
    label('BISCUITS', Mt @ T(0, 0, 0.0582) @ FLAT, 0.075)
    B(0.115, 0.0015, 0.01, '#d9cfb8', Mt @ T(0, -0.0403, 0.02), bevel=0, mat='enamel', gloss=0.3)


# --------------------------------------------------------------------- hung on two of the doors under the desk
def hung_on_doors():
    # ---- a flask in a leather holster, on the door RATIONS
    M = door(22) @ T(-0.16, -0.058, -0.03)
    part(lathe([(0, -0.1), (0.033, -0.1), (0.036, -0.094), (0.036, 0.05), (0.03, 0.062), (0.03, 0.066), (0, 0.066)], 16), '#6f8a6a', 'in', M, bevel=0, mat='enamel', gloss=0.35, jit=0.03)
    part(lathe([(0, 0.066), (0.031, 0.066), (0.0325, 0.07), (0.0325, 0.105), (0.029, 0.112), (0, 0.113)], 16), '#d9cfb8', 'in', M, bevel=0, mat='enamel', gloss=0.35, jit=0.02)
    part(lathe([(0.0305, 0.058), (0.0335, 0.058), (0.0335, 0.068), (0.0305, 0.068)], 16, close=True), BRASS, 'in', M, bevel=0, gloss=0.6)
    for z in (-0.07, 0.02): part(lathe([(0.0365, z - 0.014), (0.0395, z - 0.014), (0.0395, z + 0.014), (0.0365, z + 0.014)], 16, close=True), '#6a4a30', 'in', M, bevel=0, mat='leather', jit=0.03)
    B(0.05, 0.022, 0.15, '#6a4a30', M @ T(0, 0.047, -0.025), bevel=0.003, mat='leather', jit=0.03)
    B(0.012, 0.004, 0.11, '#6a4a30', M @ T(0, -0.0395, -0.025), bevel=0.001, mat='leather')
    B(0.04, 0.02, 0.006, '#6a4a30', M @ T(0, -0.0, -0.1035), bevel=0.001, mat='leather')
    for z in (-0.07, 0.02): part(cyl(0.004, 0.003, 6), BRASS, 'in', M @ T(0, -0.041, z) @ YA, bevel=0, gloss=0.6)
    # ---- a pouch of canvas with papers in it, on the door CHARTS
    M = door(-22) @ T(-0.14, -0.012, -0.05)
    part(box(0.2, 0.04, 0.15), '#cbb88f', 'in', M @ T(0, -0.02, 0), bevel=0.012, seg=2, mat='canvas', jit=0.04, sub=1, rough=0.004, grit=10)
    part(sheet(8, 4, lambda u, v: (-0.102 + 0.204 * u, -0.043 - 0.005 * sin(pi * u) - 0.003 * v, 0.078 - 0.07 * v - 0.006 * sin(pi * u) * v), 0.004), '#b8a479', 'in', M, bevel=0, mat='canvas', jit=0.04, sharp=80)
    part(cyl(0.007, 0.004, 8), BRASS, 'in', M @ T(0, -0.05, 0.018) @ YA, bevel=0.001, seg=1, gloss=0.6)
    for x, c2, h in ((-0.05, '#e3d8ba', 0.05), (0.0, '#d9cdaa', 0.035), (0.045, '#efe6c8', 0.06)):
        B(0.085, 0.004, 0.1, c2, M @ T(x, -0.012 - 0.004 * (x > 0), 0.045 + h / 2) @ R(0.06 * (x * 20), 'Y'), bevel=0, mat='paper')
    Tu([(0.075, -0.02, 0.05), (0.082, -0.022, 0.14)], 0.0036, '#a33a26', 6, 1, M, mat='paint')
    for sx in (-1, 1): Tu([(sx * 0.085, -0.004, 0.07), (sx * 0.085, -0.01, 0.1), (sx * 0.085, 0.002, 0.11)], 0.004, BRASS, 5, 3, M, gloss=0.6)


# ---------------------------------------------------------------------- a string of pennants at the window's head
def pennants():
    """Small flags of four colours on a line, pinned to the four middle posts and sagging between them."""
    cols = ('#a33a26', '#d9cfb8', '#3f7272', '#c9a23a', '#6f8a6a')
    line = lambda a, t: P(rad(a), 2.336 - 0.012 * 4 * t * (1 - t), HEAD - 0.018 - 0.055 * 4 * t * (1 - t))
    n = 0
    for a0 in (-36, -12, 12):
        Tu([line(a0 + 24 * i / 12, i / 12) for i in range(13)], 0.0016, ROPE, 4, 1)
        for i in range(7):
            t = (i + 0.5) / 7; a = a0 + 24 * t; p = line(a, t)
            M = at(rad(a), hypot(p.x, p.y), p.z) @ R(0.25 * sin(n * 2.3), 'Z') @ R(0.12 * cos(n * 1.7), 'X')
            w, h = 0.05, 0.072
            fl = lambda u, v: ((u - 0.5) * w * (1 - v * 0.96), 0.004 * sin(v * 3 + n) * v, -0.001 - h * v)
            part(sheet(2, 4, fl, 0.0012), cols[n % 5], 'in', M, bevel=0, mat='cloth', jit=0.04, sharp=80)
            n += 1
    for a in (-36, -12, 12, 36):
        part(ball(0.0045, 6, 5), BRASS, 'in', T(*P(rad(a), 2.336, HEAD - 0.018)), bevel=0, gloss=0.6)
        Tu([P(rad(a), 2.336, HEAD - 0.018), P(rad(a), 2.378, HEAD - 0.016)], 0.002, BRASS, 5, 1, gloss=0.6)


# ------------------------------------------------------------------------------ small things along the window's sill
def sill_things():
    """
    On the sill under the panes either side of the middle one (which is kept clear): three small bottles of coloured
    glass, a picture in a brass frame, a cactus in a red pot, two books.
    """
    rm = (RO - 0.085) * cos(rad(12)); zs = SILL + 0.02
    sill = lambda a, x, y: at(rad(a), rm, zs) @ T(x, y, 0)          # on the sill of the pane whose middle is at a: x along it, y in from the glass
    # ---- three bottles, under the pane left of the middle
    for x, c, h, r in ((0.13, '#3f7272', 0.062, 0.017), (0.176, '#c98a3a', 0.048, 0.02), (0.222, '#a33a26', 0.07, 0.015)):
        M = sill(-24, x, -0.05 + 0.012 * sin(x * 40))
        part(lathe([(0, 0), (r, 0), (r + 0.001, 0.004), (r + 0.001, h * 0.62), (r * 0.5, h * 0.82), (r * 0.42, h), (r * 0.55, h + 0.004), (0, h + 0.004)], 12), c, 'in', M, bevel=0, mat='glassy', gloss=0.6, jit=0.03)
        part(cyl(r * 0.4, 0.012, 8, r2=r * 0.46), '#a98b62', 'in', M @ T(0, 0, h + 0.008), bevel=0.001, seg=1, mat='wood')
    # ---- a picture in a frame, leaning on its strut, under the pane right of the middle
    M = sill(24, 0.15, -0.052) @ R(rad(8), 'Z') @ R(-rad(12), 'X')
    B(0.108, 0.01, 0.086, BRASS, M @ T(0, 0, 0.045), bevel=0.003, gloss=0.6)
    label('photo_b', M @ T(0, -0.0062, 0.045), 0.092)
    Tu([(0, 0.004, 0.07), (0, 0.035, 0.002)], 0.003, BRASS, 5, 1, M, gloss=0.6)
    # ---- a cactus in a red pot, under the right-hand pane; two books, under the left-hand one
    M = sill(48, -0.19, -0.05)
    part(lathe([(0, 0), (0.024, 0), (0.031, 0.04), (0.034, 0.04), (0.034, 0.048), (0.027, 0.048), (0.027, 0.042), (0, 0.042)], 14), '#a33a26', 'in', M, bevel=0, mat='glaze', gloss=0.4, jit=0.03)
    part(cyl(0.0265, 0.003, 12), '#3a2a1e', 'in', M @ T(0, 0, 0.0435), bevel=0, mat='soot')
    part(ball(0.02, 10, 8, s=(1, 1, 1.9)), '#5f8a52', 'in', M @ T(0, 0, 0.075), bevel=0, mat='glaze', gloss=0.3, jit=0.05, rough=0.0015, grit=40)
    part(ball(0.011, 8, 6, s=(1, 1, 1.5)), '#5f8a52', 'in', M @ T(0.02, 0.004, 0.072) @ R(0.7, 'Y'), bevel=0, mat='glaze', gloss=0.3, jit=0.05)
    part(ball(0.006, 6, 5), '#d98a9a', 'in', M @ T(0, 0, 0.114), bevel=0, mat='glaze', gloss=0.3)
    M = sill(-48, 0.22, -0.052) @ R(0.12, 'Z')
    for k, (c, w, d, t) in enumerate((('#6f8a6a', 0.15, 0.062, 0.022), ('#a33a26', 0.135, 0.058, 0.017))):
        z = 0.0 if k == 0 else 0.022
        Mk = M @ R(0.2 * k, 'Z')
        B(w, d, t, c, Mk @ T(0, 0, z + t / 2), bevel=0.002, mat='cloth', jit=0.03)
        B(w - 0.006, d - 0.004, t - 0.006, '#e3d8ba', Mk @ T(0, -0.003, z + t / 2), bevel=0, mat='paper')
        B(w, 0.003, t, c, Mk @ T(0, d / 2 - 0.001, z + t / 2), bevel=0.001, mat='cloth')


# ------------------------------------------------------------- the wireless's hand piece, on its hook at the lip
def hand_mic():
    """To speak into: a cream box with a grille, hung by its ring on a hook left of the three boards, its red cord in coils to a socket."""
    M = lipf(rad(-10.6), 1.662)
    B(0.03, 0.005, 0.04, BRASS, M @ T(0, -0.0025, 0.004), bevel=0.0015, gloss=0.6)
    for sz in (-1, 1): screw(M @ T(0, -0.005, 0.004 + sz * 0.013), 0.003)
    Tu([(0, -0.005, 0.0), (0, -0.026, -0.002), (0, -0.03, 0.012)], 0.0036, BRASS, 6, 3, M, gloss=0.6)
    Mm = M @ T(0, -0.028, -0.058) @ R(rad(6), 'X')
    part(tube([(0.011 * cos(i * pi / 6), 0, 0.05 + 0.011 * sin(i * pi / 6)) for i in range(12)], 0.0022, 5, 1, cyclic=True), STEEL, 'in', Mm, bevel=0, gloss=0.6)
    B(0.052, 0.034, 0.084, ENAMEL, Mm, bevel=0.009, seg=3, gloss=0.28, jit=0.02)
    part(cyl(0.019, 0.003, 16), '#141418', 'in', Mm @ T(0, -0.0172, 0.014) @ YA, bevel=0, mat='rubber')
    part(lathe([(0.0185, 0), (0.0225, 0), (0.0225, 0.003), (0.0185, 0.0045)], 16, close=True), BRASS, 'in', Mm @ T(0, -0.017, 0.014) @ YA, bevel=0, gloss=0.6)
    for k in range(4):
        x = -0.0105 + 0.007 * k
        B(0.0024, 0.002, 2 * sqrt(0.0185 ** 2 - x * x), BRASS, Mm @ T(x, -0.0192, 0.014), bevel=0, gloss=0.6)
    B(0.03, 0.004, 0.012, '#a33a26', Mm @ T(0, -0.018, -0.024), bevel=0.0015, mat='enamel', gloss=0.4)
    B(0.006, 0.02, 0.034, '#a33a26', Mm @ T(0.0275, 0, 0.004), bevel=0.002, mat='enamel', gloss=0.4)
    part(cyl(0.007, 0.012, 8), RUBBER, 'in', Mm @ T(0, 0, -0.047), bevel=0.001, seg=1)
    # (its cord: coils of red, sagging to a socket further along the lip)
    A = Mm @ Vector((0, 0, -0.053)); Ms = lipf(rad(-16.6), 1.6); Bq = Ms @ Vector((0, -0.012, 0))
    part(cyl(0.012, 0.006, 10), BRASS, 'in', Ms @ T(0, -0.003, 0) @ YA, bevel=0.001, seg=1, gloss=0.6)
    part(cyl(0.007, 0.012, 8), RUBBER, 'in', Ms @ T(0, -0.01, 0) @ YA, bevel=0.001, seg=1)
    mid = lambda t: A.lerp(Bq, t) + Vector((0, -0.03 * 4 * t * (1 - t), -0.085 * 4 * t * (1 - t) - 0.02 * sin(pi * t) * (1 - t)))
    pts, turns, per = [], 30, 8
    for i in range(turns * per + 1):
        t = i / (turns * per); c0 = mid(t); d = (mid(min(t + 0.01, 1)) - mid(max(t - 0.01, 0))).normalized()
        u = d.cross(Vector((0, 0, 1))).normalized(); v = d.cross(u)
        ang = 2 * pi * i / per; rr = 0.0058 * min(1, 6 * t, 6 * (1 - t)) + 0.0002
        pts.append(c0 + (u * cos(ang) + v * sin(ang)) * rr)
    Tu(pts, 0.0017, '#a33a26', 5, 1, mat='rubber')


# ------------------------------------------------------------------------------------- two more small things
def small_things():
    # ---- a painted wooden bird, on the wireless
    Mw = Mradio(); Mb = Mw @ T(-0.135, 0.085, 0.12) @ R(0.5, 'Z')
    part(ball(0.017, 12, 8, s=(1.0, 1.45, 1.0)), '#3f7272', 'in', Mb @ T(0, 0, 0.016) @ R(-0.25, 'X'), bevel=0, mat='enamel', gloss=0.35, jit=0.03)
    part(ball(0.0135, 10, 6, s=(0.9, 1.2, 0.7)), '#d9cfb8', 'in', Mb @ T(0, -0.005, 0.0105) @ R(-0.25, 'X'), bevel=0, mat='enamel', gloss=0.35)
    part(ball(0.0115, 10, 8), '#3f7272', 'in', Mb @ T(0, -0.02, 0.034), bevel=0, mat='enamel', gloss=0.35, jit=0.03)
    part(cyl(0.004, 0.012, 6, r2=0.0004), '#c9a23a', 'in', Mb @ T(0, -0.0355, 0.0335) @ R(pi / 2, 'X'), bevel=0, mat='enamel', gloss=0.4)
    for sx in (-1, 1): part(ball(0.0018, 5, 4), '#141418', 'in', Mb @ T(sx * 0.0065, -0.0285, 0.0375), bevel=0, mat='enamel', gloss=0.5)
    B(0.012, 0.03, 0.004, '#a33a26', Mb @ T(0, 0.034, 0.024) @ R(0.4, 'X'), bevel=0.001, mat='enamel', gloss=0.35)
    part(cyl(0.012, 0.004, 10), WOOD_D, 'in', Mb @ T(0, 0, 0.002), bevel=0.001, seg=1)
    # ---- a watch, left on the desk by the glass, its chain run out
    M = desk(rad(-10.9), 1.972, 0.004)
    part(lathe([(0, 0), (0.021, 0), (0.0245, 0.003), (0.0245, 0.0075), (0.0215, 0.0098), (0, 0.0098)], 20), BRASS, 'in', M, bevel=0, gloss=0.7)
    part(cyl(0.02, 0.0012, 20), '#ece4cb', 'in', M @ T(0, 0, 0.0102), bevel=0, mat='paper')
    for a, L in ((0.9, 0.013), (2.9, 0.017)): B(0.0016, L, 0.0008, DARK, M @ T(0, 0, 0.0112) @ R(a, 'Z') @ T(0, L / 2, 0), bevel=0, mat='paint')
    for k in range(12): B(0.001, 0.003, 0.0006, DARK, M @ T(0, 0, 0.0111) @ R(k * pi / 6, 'Z') @ T(0, 0.0175, 0), bevel=0, mat='paint')
    part(cyl(0.004, 0.008, 8), BRASS, 'in', M @ T(0, 0.028, 0.005) @ R(pi / 2, 'X'), bevel=0.001, seg=1, gloss=0.7)
    part(tube([(0.008 * cos(i * pi / 5), 0.037 + 0.008 * sin(i * pi / 5), 0.004) for i in range(10)], 0.0014, 5, 1, cyclic=True), BRASS, 'in', M, bevel=0, gloss=0.7)
    Tu([(0, 0.045, 0.003), (-0.02, 0.07, 0.003), (-0.05, 0.065, 0.003), (-0.062, 0.04, 0.003), (-0.085, 0.03, 0.003), (-0.1, 0.05, 0.003)], 0.0019, BRASS, 5, 5, M, gloss=0.7)


# ------------------------------------------------------------------------ the ship's badge, at either end of the desk
def badges():
    """On the two end faces of the desk, near the corner the pilot passes: her badge in enamel, in a ring of brass."""
    for sg in (-1, 1):
        E = at(sg * rad(59), 1.955, 1.545) @ R(sg * pi / 2, 'Z')
        part(lathe([(0.058, 0), (0.07, 0), (0.07, 0.005), (0.062, 0.008), (0.058, 0.005)], 28, close=True), BRASS, 'in', E @ YA, bevel=0, gloss=0.6)
        part(disc(0.059, 28, cell('emblem')), '#ffffff', 'in', E @ T(0, -0.004, 0), bevel=0, mat='print', jit=0)
        for k in range(4): part(cyl(0.0035, 0.003, 6), STEEL, 'in', E @ R(pi / 4 + k * pi / 2, 'Y') @ T(0, -0.0078, 0.064) @ YA, bevel=0, gloss=0.6)


def check_swing():
    """(Only when asked: C3_CHECK.) How near the landing glass comes to anything that does not move, all the way down."""
    from mathutils.bvhtree import BVHTree
    H = Vector(cockpit.SCREEN_HINGE)
    V, F, moving = [], [], []
    for o in COL['in'].objects:
        M = o.matrix_world; me = o.data
        if 'screen' in o.vertex_groups:
            for pl in me.polygons:
                vs = [M @ me.vertices[i].co for i in pl.vertices]
                if len(vs) < 3: continue
                a, b, c = vs[0], vs[1], vs[-1]
                nu = max(1, int((b - a).length / 0.012)); nv = max(1, int((c - a).length / 0.012))
                for i in range(nu + 1):
                    for j in range(nv + 1): moving.append(a + (b - a) * (i / nu) + (c - a) * (j / nv))
            continue
        bb = [M @ Vector(c) for c in o.bound_box]
        cen = sum(bb, Vector()) / 8
        if (cen - H).length > 0.75: continue
        n = len(V)
        V += [M @ v.co for v in me.vertices]
        F += [[n + i for i in pl.vertices] for pl in me.polygons]
    tree = BVHTree.FromPolygons(V, F)
    print('check_swing: moving samples', len(moving), 'fixed faces', len(F))
    near = {}
    steps = 64
    for k in range(steps + 1):
        Mk = T(*H) @ R(cockpit.SCREEN_SWING * k / steps, 'X') @ T(*(-H))
        for q in moving:
            w = Mk @ q
            hit = tree.find_nearest(w, 0.006)
            if hit[0] is None: continue
            key = (round(hit[0].x / 0.03) * 0.03, round(hit[0].y / 0.03) * 0.03, round(hit[0].z / 0.03) * 0.03)
            d = hit[3]
            if key not in near or d < near[key][0]: near[key] = (d, k, tuple(round(c, 3) for c in hit[0]))
    for key, (d, k, at_) in sorted(near.items(), key=lambda kv: kv[1][0])[:60]:
        print('  near %.4f at step %d/%d  fixed point %s' % (d, k, steps, at_))
