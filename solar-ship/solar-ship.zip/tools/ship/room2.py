# The room behind the pilot, and the suit: what build.py's room(), table(), hammock(), stove(), suit() and
# lights_and_pipes() make (they hand over to the builders of the same names here), and, from build(), everything
# else that makes the room somewhere a person lives: what is stowed under the roof, hung on the walls, stood on the
# floor, and what is seen of a helmet from inside it.
#
# Round the wall, by degrees from the window toward the pilot's right: 61..78 padding, a peg rail; 70..130 the
# hammock, with stores under it and a shelf over it; 131..144 tools and air; 146..164 the suit; 165..195 the door;
# -158..-165 the ramp's lever and the two lamps that say whether there is air outside; -140..-158 the stove's
# shield (the stove stands out from it); -128..-70 the chart table; -61..-70 a glass for the weather.
import os
import bpy, bmesh, random
from dims import *
from math import asin, acos, hypot, floor

UP = Vector((0, 0, 1))


# ------------------------------------------------------------------------------------------------- small helpers
def W(th, z, off=0.016):
    """A frame on the wall, so many degrees round: its -Y looks into the room, its +X runs along the wall."""
    return at(rad(th), RI - off, z)


def rod(a, b, r, col, n=8, grp='in', **kw):
    return part(tube([Vector(a), Vector(b)], r, n, 1), col, grp, bevel=0, **kw)


def hoop(c, axis, r, t=0.006, n=14, col=None, grp='in', seg=6, sq=1.0, **kw):
    """A ring of wire or cord round a middle; sq squashes it across its second direction."""
    c = Vector(c); a = Vector(axis).normalized(); e1 = a.orthogonal().normalized(); e2 = a.cross(e1)
    return part(tube([c + (e1 * cos(2 * pi * i / n) + e2 * sin(2 * pi * i / n) * sq) * r for i in range(n)], t, seg, 1, cyclic=True), col or BRASS, grp, bevel=0, **kw)


def ehoop(M, a, b, z, t=0.006, n=24, col=None, grp='in', **kw):
    """A cord round something oval, in a frame's own flat."""
    return part(tube([(a * cos(2 * pi * i / n), b * sin(2 * pi * i / n), z) for i in range(n)], t, 6, 1, cyclic=True), col or BRASS, grp, M, bevel=0, **kw)


def path(pts, sub=6):
    return crom([Vector(p) for p in pts], sub) if len(pts) > 2 else [Vector(p) for p in pts]


def ribbon(pts, w, t, hint, sub=6):
    """A flat band through points. hint: the way its face looks (one direction, or a rule (point) -> direction)."""
    Pp = path(pts, sub)
    bm = bmesh.new(); rows = []
    for i, p in enumerate(Pp):
        d = (Pp[min(i + 1, len(Pp) - 1)] - Pp[max(i - 1, 0)]).normalized()
        nrm = Vector(hint(p)) if callable(hint) else Vector(hint)
        side = d.cross(nrm)
        side = side.normalized() if side.length > 1e-4 else Vector((1, 0, 0))
        ww = w(i / (len(Pp) - 1)) if callable(w) else w
        rows.append((bm.verts.new(p - side * ww / 2), bm.verts.new(p + side * ww / 2)))
    for a, b in zip(rows, rows[1:]): bm.faces.new((a[0], a[1], b[1], b[0]))
    bmesh.ops.solidify(bm, geom=bm.faces[:], thickness=t)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    return bm


def sleeve(pts, r, ribs=(), amp=0.009, n=10, dense=14):
    """A sleeve through points, with bellows: ribs = [(from, to, how many)] along its way (0..1)."""
    Pp = path(pts, dense)
    def rr(u):
        b = r(u) if callable(r) else r
        for u0, u1, k in ribs:
            if u0 <= u <= u1: b += amp * abs(sin((u - u0) / (u1 - u0) * pi * k))
        return b
    return tube(Pp, rr, n, 1)


def nail(M, r=0.005, h=0.003, col=None, grp='in'):
    """A nail's head: the frame's +Z is the way it stands out."""
    part(cyl(r, h, 6), col or DARK, grp, M @ T(0, 0, h / 2 - 0.0005), bevel=0, gloss=0.3, jit=0.02)


INTO = R(pi / 2, 'X')      # turns a thing made along +Z to stand out of a wall frame, into the room


def wall_ring(tp, zp, r0, r1, off, thick, n=40):
    """A flat ring lying on the round wall about a place on it (a surround for a porthole)."""
    bm = bmesh.new(); cols = []
    for i in range(n):
        a = 2 * pi * i / n; ring = []
        for rho, R_ in ((r0, RI - off), (r0, RI - off - thick), (r1, RI - off - thick), (r1, RI - off)):
            x, z = rho * cos(a), rho * sin(a)
            ring.append(bm.verts.new(P(tp + asin(x / R_), R_, zp + z)))
        cols.append(ring)
    for i in range(n):
        A, B = cols[i], cols[(i + 1) % n]
        for j in range(4): bm.faces.new((A[j], A[(j + 1) % 4], B[(j + 1) % 4], B[j]))
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    return bm


def log(M, r, L, n=9):
    """A length of firewood along its frame's +Z: bark round it, pale where it was sawn."""
    Mi = M.inverted()
    part(cyl(r, L, n), lambda p: '#c9a877' if abs((Mi @ p).z) > L / 2 - 0.004 else '#5b4332', 'in', M, bevel=0.004, jit=0.07, mat='wood', rough=0.004, grit=14)


# ================================================================================================== the room
def room():
    lincol = lambda p: SAGE if p.z < 1.86 else HONEY
    # the lining: boards of uneven widths, each a little in or out of true, nailed top and bottom
    def cut(tc, hw, z0, z1):
        cuts = []
        if abs(tc) < WS: cuts.append((SILL, HEAD))
        if abs(abs(tc) - pi) < DA: cuts.append((z0 - 1, DOOR_TOP))
        for tp, zp, rp in PORTS:
            d = max(abs(RI * ang(tc - tp)) - hw, 0.0); rc = rp + 0.05
            if d < rc: h = sqrt(rc * rc - d * d); cuts.append((zp - h, zp + h))
        out = [(z0, z1)]
        for a, b in cuts:
            nxt = []
            for s, e in out:
                if b <= s or a >= e: nxt.append((s, e)); continue
                if a > s: nxt.append((s, a))
                if b < e: nxt.append((b, e))
            out = nxt
        return [(s, e) for s, e in out if e - s > 0.04]
    joints = []
    for a0, a1 in ((-pi + DA, -WS), (-WS, WS), (WS, pi - DA), (pi - DA, pi + DA)):
        n = max(2, round((a1 - a0) * RL / 0.172))
        ws = [random.uniform(0.72, 1.3) for _ in range(n)]; k = (a1 - a0) / sum(ws)
        t = a0
        for w in ws:
            t0, t1 = t, t + w * k; t = t1; tc = (t0 + t1) / 2; wide = 2 * RL * sin((t1 - t0) / 2)
            if t1 < a1 - 1e-6: joints.append(t1)
            inn = random.uniform(0, 0.002)
            for s, e in cut(tc, wide / 2, ZF, ZW - 0.02):
                part(box(wide - 0.004, 0.025, e - s), lincol, 'in', at(tc, RL - inn, (s + e) / 2), bevel=0.004, jit=0.07, cuts=[z for z in (1.86,) if s < z < e])
                if abs(tc) < WS and s < SILL: continue        # (behind the pilot's desk nobody sees a nail)
                for z in (s + 0.05, e - 0.05):
                    for sx in (-1, 1): nail(at(tc, RI - inn, z) @ T(sx * wide * 0.27, 0, 0) @ INTO, 0.0045, 0.003)
    # (a batten over every joint of the lower wall, a rail along its top, a board along its foot)
    for t in joints:
        if abs(t) < WS + 0.01 or abs(abs(t) - pi) < DA + 0.01: continue
        part(box(0.03, 0.009, 1.84 - ZF - 0.1), SAGE, 'in', at(t, RI - 0.0045, (1.84 + ZF + 0.1) / 2), bevel=0.003, jit=0.06)
    for a0, a1 in ((rad(60), pi - DA), (-(pi - DA), rad(-60))):
        part(slab(RI - 0.03, RI, 1.84, 1.90, a0, a1, 24), WOOD_D, 'in', bevel=0.006)
        part(slab(RI - 0.02, RI, ZF, ZF + 0.1, a0, a1, 24), WOOD_D, 'in', bevel=0.005)
    # a wooden surround to each porthole, bolted through
    for tp, zp, rp in PORTS:
        part(wall_ring(tp, zp, rp + 0.15, rp + 0.285, -0.004, 0.016), WOOD_D, 'in', bevel=0.004, jit=0.04)
        for k in range(10):
            a = (k + 0.5) * pi / 5; x, z = (rp + 0.235) * cos(a), (rp + 0.235) * sin(a)
            nail(at(tp + asin(x / RI), RI - 0.012, zp + z) @ INTO, 0.009, 0.006, BRASS)
    # the floor: boards from front to back in two or three lengths, nailed at every joist, on a dark deck
    n = 28; pw = 2 * RI / n
    hidden = lambda x, y: hypot(x + 0.1, y + 0.62) < 0.74 or hypot(x + 0.925, y + 1.6) < 0.5 or (abs(x - 0.95) < 0.33 and abs(y + 0.55) < 0.33) or (abs(x) < 0.39 and abs(y + 1.95) < 0.22) or hypot(x, y - 0.66) < 0.28 or hypot(x + 1.61, y + 0.255) < 0.4 or y > 1.25
    for i in range(n):
        x = -RI + (i + 0.5) * pw; half = sqrt(RI * RI - x * x) + 0.03
        ends = [-half]
        while half - ends[-1] > 2.3: ends.append(ends[-1] + random.uniform(0.9, 1.9))
        ends.append(half)
        for y0, y1 in zip(ends, ends[1:]):
            part(box(pw - 0.006, y1 - y0 - 0.004, 0.045), FLOOR, 'in', T(x, (y0 + y1) / 2, ZF - 0.0225), bevel=0.004, jit=0.1)
        for y in sorted(set([e + d for e in ends[1:-1] for d in (-0.035, 0.035)] + [-1.8, -0.9, 0.0, 0.9, 1.8])):
            for sx in (-1, 1):
                px = x + sx * pw * 0.29
                if hypot(px, y) < RI - 0.12 and not hidden(px, y): nail(T(px, y, ZF), 0.0055, 0.003)
    part(lathe([(0, ZF - 0.05), (RO - 0.06, ZF - 0.05), (RO - 0.06, ZB), (0, ZB)], 48, close=True), WOOD_D, 'in', bevel=0)
    # a round rug, braided: each ring a low roll of its own, the whole of it worn out of true
    rings = ((0, 0.14, '#8f3a2a'), (0.14, 0.25, '#c4b490'), (0.25, 0.37, '#3b6566'), (0.37, 0.46, '#c4b490'), (0.46, 0.56, '#8f3a2a'), (0.56, 0.63, '#3b6566'), (0.63, 0.7, '#c4b490'))
    for r0, r1, col in rings:
        m = (r0 + r1) / 2
        part(lathe([(r0, ZF + 0.003), (r1, ZF + 0.003), (r1, ZF + 0.009), (m + (r1 - m) * 0.5, ZF + 0.0145), (m - (m - r0) * 0.5, ZF + 0.0145), (r0, ZF + 0.009)], 48, close=True), col, 'in', T(-0.1, -0.62, 0),
             bevel=0, jit=0.07, mat='knit', rough=0.0016, grit=5)


# ================================================================================================= the stove
def stove():
    sp = Vector((-0.925, -1.60, ZF)); M = T(*sp)
    phi = atan2(-sp.x, -0.3 - sp.y); F = M @ R(-phi, 'Z')        # F's +Y: the stove's front, toward the room
    # the hearth: a thick plate with a raised rim, standing on the boards; three cast feet
    part(lathe([(0, -0.002), (0.46, -0.002), (0.47, 0.004), (0.47, 0.03), (0.445, 0.03), (0.438, 0.022), (0, 0.022)], 36, close=True), IRON, 'in', M, bevel=0, gloss=0.35, jit=0.03)
    for k in range(14):
        a = k * 2 * pi / 14 + 0.2
        part(ball(0.009, 8, 5, s=(1, 1, 0.6)), DARK, 'in', M @ T(0.4575 * cos(a), 0.4575 * sin(a), 0.03), bevel=0, gloss=0.4)
    for a in (0.5, 2.6, 4.7):
        part(tube([(0.15 * cos(a), 0.15 * sin(a), 0.2), (0.22 * cos(a), 0.22 * sin(a), 0.12), (0.26 * cos(a), 0.26 * sin(a), 0.045)], lambda u: 0.03 - 0.008 * u, 8, 4), DARK, 'in', M, bevel=0, gloss=0.3)
        part(lathe([(0, 0.02), (0.045, 0.02), (0.04, 0.045), (0.02, 0.06), (0, 0.06)], 10, close=True), DARK, 'in', M @ T(0.26 * cos(a), 0.26 * sin(a), 0), bevel=0, gloss=0.3)
    # the body: a pot belly, banded and riveted, with a plate on top and a rail round it
    part(lathe([(0, 0.12), (0.2, 0.12), (0.255, 0.17), (0.29, 0.29), (0.3, 0.42), (0.285, 0.58), (0.24, 0.7), (0.2, 0.76), (0.2, 0.8), (0, 0.8)], 28), DARK, 'in', M, bevel=0, gloss=0.35, mat='iron')
    for z, r in ((0.2, 0.2715), (0.415, 0.3), (0.63, 0.271)):
        part(slab(r - 0.004, r + 0.01, z - 0.016, z + 0.016, 0, 2 * pi, 28), IRON, 'in', M, bevel=0.003, gloss=0.4)
        for k in range(12):
            a = k * pi / 6 + z
            if z == 0.415 and abs(ang(a - (pi / 2 - phi))) < 0.5: continue
            part(ball(0.007, 6, 4), DARK, 'in', M @ T((r + 0.011) * cos(a), (r + 0.011) * sin(a), z), bevel=0, gloss=0.4)
    part(cyl(0.215, 0.03, 24), IRON, 'in', M @ T(0, 0, 0.815), bevel=0.006, gloss=0.4)
    for r in (0.09, 0.17):
        part(slab(r - 0.008, r, 0.83, 0.834, 0, 2 * pi, 20), DARK, 'in', M, bevel=0, gloss=0.3)
    for k in range(4):
        a = k * pi / 2 + 0.4
        rod(sp + Vector((0.2 * cos(a), 0.2 * sin(a), 0.83)), sp + Vector((0.235 * cos(a), 0.235 * sin(a), 0.9)), 0.006, BRASS, 6, gloss=0.6)
    hoop(sp + Vector((0, 0, 0.9)), UP, 0.235, 0.007, 28, BRASS, gloss=0.6)
    # its door: hinged on the left, latched on the right, the fire seen through bars
    part(box(0.24, 0.035, 0.24), IRON, 'in', F @ T(0, 0.284, 0.44), bevel=0.012, gloss=0.4)
    part(box(0.2, 0.02, 0.2), DARK, 'in', F @ T(0, 0.302, 0.44), bevel=0.008, gloss=0.35, mat='iron')
    part(box(0.135, 0.004, 0.095), '#ff7a2a', 'in', F @ T(0, 0.3115, 0.45), bevel=0, glow=7)
    for k in range(6): part(box(0.008, 0.01, 0.105), DARK, 'in', F @ T(-0.06 + 0.024 * k, 0.317, 0.45), bevel=0.002, mat='iron')
    for z in (0.398, 0.502): part(box(0.15, 0.012, 0.012), DARK, 'in', F @ T(0, 0.317, z), bevel=0.003, mat='iron')
    for z in (0.37, 0.51):
        part(cyl(0.011, 0.045, 8), IRON, 'in', F @ T(-0.112, 0.312, z), bevel=0.002, gloss=0.4)
        part(box(0.07, 0.006, 0.022), IRON, 'in', F @ T(-0.075, 0.314, z), bevel=0.002, gloss=0.4)
        nail(F @ T(-0.05, 0.317, z) @ R(-pi / 2, 'X'), 0.004, 0.003)
    part(tube([(0.085, 0.312, 0.44), (0.1, 0.345, 0.44), (0.1, 0.35, 0.4)], 0.006, 6, 3), STEEL, 'in', F, bevel=0, gloss=0.6)
    part(ball(0.017, 10, 8, s=(1, 1, 1.4)), WOOD, 'in', F @ T(0.1, 0.35, 0.385), bevel=0, jit=0.04)
    part(box(0.07, 0.006, 0.018), IRON, 'in', F @ T(0, 0.3125, 0.352), bevel=0.002, gloss=0.4)
    part(ball(0.008, 8, 6), BRASS, 'in', F @ T(0.02, 0.318, 0.352), bevel=0, gloss=0.6)
    # an ash drawer under it
    part(box(0.17, 0.04, 0.055), IRON, 'in', F @ T(0, 0.262, 0.215), bevel=0.008, gloss=0.4)
    part(box(0.09, 0.006, 0.01), DARK, 'in', F @ T(0, 0.283, 0.228), bevel=0, mat='soot')
    part(ball(0.012, 8, 6), BRASS, 'in', F @ T(0, 0.29, 0.203), bevel=0, gloss=0.6)
    LIGHTS.append((F @ Vector((0, 0.5, 0.44)), '#ff8a3a', 22))
    # the kettle (the ship there was before this one)
    K = M @ T(0.02, 0, 0.834) @ R(0.7, 'Z')
    part(lathe([(0, 0), (0.09, 0), (0.12, 0.04), (0.11, 0.1), (0.06, 0.14), (0, 0.15)], 18), COPPER, 'in', K, bevel=0, gloss=0.7)
    part(slab(0.085, 0.094, -0.004, 0.006, 0, 2 * pi, 18), COPPER, 'in', K, bevel=0.002, gloss=0.6)
    part(tube([(0.1, 0, 0.06), (0.17, 0, 0.1), (0.2, 0, 0.15)], lambda u: 0.016 - 0.006 * u, 6, 4), COPPER, 'in', K, bevel=0, gloss=0.7)
    part(tube([(-0.07, 0, 0.13), (-0.04, 0, 0.21), (0.04, 0, 0.21), (0.07, 0, 0.13)], 0.007, 5, 4), DARK, 'in', K, bevel=0)
    part(tube([(-0.035, 0, 0.212), (0.035, 0, 0.212)], 0.011, 8, 1), WOOD, 'in', K, bevel=0)
    part(ball(0.016, 8, 6), DARK, 'in', K @ T(0, 0, 0.158), bevel=0)
    part(slab(0.058, 0.064, 0.136, 0.142, 0, 2 * pi, 14), BRASS, 'in', K, bevel=0, gloss=0.6)
    # the pipe, in lengths, with a collar at each joint and a damper in it
    top = 3.62 - ZF
    part(tube([sp + Vector((0, 0, 0.8)), sp + Vector((0, 0, top))], 0.07, 14, 1), DARK, 'in', bevel=0, gloss=0.3)
    for z in (0.87, 1.48, 2.1):
        part(slab(0.069, 0.08, z - 0.02, z + 0.02, 0, 2 * pi, 16), IRON, 'in', M, bevel=0.003, gloss=0.4)
        for k in range(3): part(ball(0.006, 6, 4), STEEL, 'in', M @ T(0.081 * cos(k * 2.1 + z), 0.081 * sin(k * 2.1 + z), z), bevel=0, gloss=0.6)
    part(box(0.004, 0.006, top - 0.82), IRON, 'in', F @ T(0, -0.071, (top + 0.8) / 2), bevel=0, gloss=0.3)
    Fd = F @ T(0, 0, 1.2)
    part(tube([(-0.09, 0, 0), (0.1, 0, 0)], 0.006, 6, 1), STEEL, 'in', Fd, bevel=0, gloss=0.6)
    part(tube([(0.1 + 0.022 * (1 - cos(t)), 0, 0.022 * sin(t)) for t in [i * pi / 5 for i in range(10)]], 0.0045, 5, 1, cyclic=True), STEEL, 'in', Fd, bevel=0, gloss=0.6)
    part(cyl(0.012, 0.01, 8), BRASS, 'in', Fd @ T(-0.078, 0, 0) @ R(pi / 2, 'Y'), bevel=0.002, gloss=0.6)
    part(slab(0.075, 0.16, 3.555, 3.585, 0, 2 * pi, 16), BRASS, 'in', T(sp.x, sp.y, 0), bevel=0.004, gloss=0.6)
    for k in range(6): nail(T(sp.x + 0.125 * cos(k * pi / 3), sp.y + 0.125 * sin(k * pi / 3), 3.555) @ R(pi, 'X'), 0.007, 0.005, STEEL)
    # a shield of tin on the wall behind it, standing off on pegs, scorched where the pipe is nearest
    part(slab(RI - 0.036, RI - 0.032, ZF + 0.13, 2.13, rad(-158), rad(-140), 10), '#8f918c', 'in', bevel=0.001, gloss=0.45, mat='tin', jit=0.03)
    part(slab(RI - 0.0385, RI - 0.035, ZF + 0.5, 1.9, rad(-153), rad(-146), 6), '#2a2622', 'in', bevel=0, mat='soot')
    for a in (-157.2, -149, -140.8):
        for z in (ZF + 0.19, (ZF + 0.13 + 2.13) / 2, 2.07):
            rod(P(rad(a), RI, z), P(rad(a), RI - 0.034, z), 0.007, IRON, 6)
            part(ball(0.009, 8, 5, s=(1, 1, 1)), BRASS, 'in', T(*P(rad(a), RI - 0.038, z)), bevel=0, gloss=0.6)
    # the fire irons on their stand, on the hearth: a poker, a shovel, a brush
    S0 = sp + Vector((-0.3, 0.24, 0.022))
    part(lathe([(0, 0), (0.07, 0), (0.065, 0.012), (0.02, 0.024), (0, 0.024)], 14, close=True), DARK, 'in', T(*S0), bevel=0, gloss=0.3)
    rod(S0, S0 + Vector((0, 0, 0.66)), 0.008, DARK, 6)
    part(ball(0.016, 8, 6), BRASS, 'in', T(*(S0 + Vector((0, 0, 0.67)))), bevel=0, gloss=0.6)
    for k, what in enumerate(('poker', 'shovel', 'brush')):
        a = 0.6 + k * 2.1; arm = S0 + Vector((0.06 * cos(a), 0.06 * sin(a), 0.6)); lean = Vector((0.012 * cos(a), 0.012 * sin(a), 0))
        rod(S0 + Vector((0, 0, 0.6)), arm, 0.005, DARK, 5)
        foot = arm + lean * 3 + Vector((0, 0, -0.5))
        rod(arm + Vector((0, 0, -0.04)), foot, 0.0045, STEEL, 6, gloss=0.5)
        hoop(arm + Vector((0, 0, -0.022)), Vector((sin(a), -cos(a), 0)), 0.018, 0.004, 10, STEEL, gloss=0.5)
        part(tube([arm + Vector((0, 0, -0.045)), arm + Vector((0, 0, -0.13))], 0.009, 8, 1), BRASS, 'in', bevel=0, gloss=0.6)
        if what == 'poker': part(tube([foot, foot + Vector((0.03 * cos(a), 0.03 * sin(a), -0.012))], 0.0045, 6, 1), STEEL, 'in', bevel=0, gloss=0.5)
        elif what == 'shovel': part(box(0.085, 0.006, 0.1), IRON, 'in', T(*(foot + Vector((0, 0, -0.045)))) @ R(a + pi / 2, 'Z') @ R(0.15, 'X'), bevel=0.002, gloss=0.4)
        else: part(box(0.05, 0.03, 0.07), '#5a4630', 'in', T(*(foot + Vector((0, 0, -0.03)))) @ R(a + pi / 2, 'Z'), bevel=0.006, mat='rope', rough=0.003, grit=30)
    # two logs lying by its feet; kindling and more logs in a basket by the wall
    log(M @ T(0.29, -0.2, 0.062) @ R(2.54, 'Z') @ R(pi / 2, 'X'), 0.04, 0.26)
    log(M @ T(0.285, -0.2, 0.128) @ R(2.75, 'Z') @ R(pi / 2, 'X'), 0.034, 0.22)
    B = at(rad(-132.8), 2.13, ZF)
    part(lathe([(0, 0), (0.125, 0), (0.15, 0.13), (0.158, 0.27), (0.166, 0.285), (0.15, 0.285), (0.138, 0.14), (0.115, 0.02), (0, 0.02)], 22, close=True), '#a8824e', 'in', B, bevel=0, mat='wicker', jit=0.05, rough=0.004, grit=9)
    for sx in (-1, 1): part(tube([(sx * 0.15, -0.03, 0.27), (sx * 0.19, 0, 0.3), (sx * 0.15, 0.03, 0.27)], 0.009, 6, 4), ROPE, 'in', B, bevel=0)
    for k in range(4): log(B @ T(0.05 * cos(k * 1.7), 0.05 * sin(k * 1.7), 0.2 + 0.02 * k) @ R(k * 0.9, 'Z') @ R(0.16 + 0.05 * k, 'X'), 0.036 - 0.003 * k, 0.34 + 0.03 * (k % 2))
    for k in range(8): part(cyl(0.008, 0.36, 5), '#7a5a3a', 'in', B @ T(0.085 * cos(k * 0.8 + 0.4), 0.085 * sin(k * 0.8 + 0.4), 0.21) @ R(k * 1.3, 'Z') @ R(0.2, 'X'), bevel=0, jit=0.1, mat='wood')


# ================================================================================================== the suit
SUIT_AT = at(rad(155), 2.14, ZF)
SUIT, SUIT_D = '#c9772e', '#9c5a26'


def suit():
    M = SUIT_AT
    # the board it hangs before, framed; its stand: a post with a neck that goes down through the collar to a yoke
    part(slab(2.36, 2.39, ZF + 0.3, ZF + 1.92, rad(145.5), rad(164.5), 6), WOOD_D, 'in', bevel=0.006)
    for z in (ZF + 0.3, ZF + 1.92): part(slab(2.35, 2.392, z - 0.025, z + 0.025, rad(145.2), rad(164.8), 6), WOOD, 'in', bevel=0.006)
    part(box(0.05, 0.045, 1.6), WOOD, 'in', M @ T(0, 0.192, 0.82), bevel=0.012, seg=3)
    part(box(0.34, 0.06, 0.03), WOOD_D, 'in', M @ T(0, 0.185, 0.016), bevel=0.008)
    part(box(0.06, 0.1, 0.03), WOOD_D, 'in', M @ T(0, 0.165, 0.016), bevel=0.008)
    part(tube([(0, 0.192, 1.6), (0, 0.18, 1.71), (0, 0.09, 1.76), (0, 0.02, 1.71), (0, 0.02, 1.47)], 0.011, 8, 5), IRON, 'in', M, bevel=0, gloss=0.4)
    part(tube([(-0.2, 0.0, 1.405), (-0.11, 0.015, 1.455), (0, 0.02, 1.47), (0.11, 0.015, 1.455), (0.2, 0.0, 1.405)], 0.022, 8, 4), WOOD, 'in', M, bevel=0, jit=0.04)
    part(lathe([(0, 1.6), (0.03, 1.6), (0.035, 1.615), (0.02, 1.63), (0, 1.63)], 10, close=True), BRASS, 'in', M @ T(0, 0.192, 0), bevel=0, gloss=0.6)
    # a tray for its boots
    part(lathe([(0, 0.001), (0.33, 0.001), (0.345, 0.035), (0.335, 0.035), (0.322, 0.009), (0, 0.009)], 4, close=True), '#7f8a86', 'in', M @ T(0, -0.075, 0) @ S(1, 0.76, 1) @ R(pi / 4, 'Z'), bevel=0.003, gloss=0.4, mat='tin', jit=0.03)
    q = dict(tag='suit', mat='quilt', jit=0.03)
    Mo = M @ S(1, 0.67, 1)                 # (a body is wider than it is deep)
    TORSO = [(0, 0.88), (0.13, 0.88), (0.19, 0.93), (0.2, 1.0), (0.186, 1.1), (0.2, 1.22), (0.224, 1.34), (0.214, 1.42), (0.17, 1.48), (0.13, 1.5), (0, 1.5)]
    def tr(z):
        for (r0, z0), (r1, z1) in zip(TORSO[1:], TORSO[2:]):
            if z0 <= z <= z1 and z1 > z0: return r0 + (r1 - r0) * (z - z0) / (z1 - z0)
        return 0.13
    skin = lambda x, z, off=0.006: -0.67 * sqrt(max(tr(z) ** 2 - x * x, 1e-4)) - off
    # the body: quilted, with a flap down its front fastened by toggles, and a belt
    part(lathe(TORSO, 22), SUIT, 'in', Mo, bevel=0, rough=0.003, grit=10, **q)
    part(lathe([(0, 0.8), (0.1, 0.8), (0.19, 0.86), (0.2, 0.93), (0.19, 0.99), (0, 0.99)], 22), SUIT_D, 'in', Mo, bevel=0, tag='suit', mat='cloth', jit=0.03, rough=0.003, grit=10)
    front = lambda z: skin(0.012, z, 0.007)
    part(ribbon([(0.012, front(z), z) for z in (1.04, 1.1, 1.16, 1.22, 1.3, 1.36, 1.42, 1.46)], 0.05, 0.006, (0, -1, 0)), SUIT_D, 'in', M, bevel=0, tag='suit', mat='leather', jit=0.03)
    for z in (1.39, 1.445):
        part(tube([(-0.006, front(z) - 0.006, z), (0.03, front(z) - 0.006, z)], 0.006, 6, 1), WOOD, 'in', M, bevel=0, tag='suit')
        part(tube([(-0.02, front(z) - 0.004, z + 0.008), (0.012, front(z) - 0.009, z), (-0.02, front(z) - 0.004, z - 0.008)], 0.0025, 4, 3), ROPE, 'in', M, bevel=0, tag='suit')
    part(slab(0.196, 0.207, 0.985, 1.03, 0, 2 * pi, 24), LEATHER, 'in', Mo, bevel=0.003, tag='suit', jit=0.03)
    part(box(0.06, 0.012, 0.055), BRASS, 'in', M @ T(0, -0.142, 1.007), bevel=0.004, gloss=0.6, tag='suit')
    part(box(0.034, 0.014, 0.03), LEATHER, 'in', M @ T(0, -0.142, 1.007), bevel=0.002, tag='suit')
    for sgn in (-1, 1):
        Pm = M @ T(sgn * 0.158, -0.086, 0.985) @ R(sgn * rad(50), 'Z')
        part(box(0.075, 0.04, 0.085), LEATHER, 'in', Pm @ T(0, -0.016, 0), bevel=0.012, seg=3, tag='suit', jit=0.04)
        part(box(0.08, 0.01, 0.04), '#6e2e1e', 'in', Pm @ T(0, -0.04, 0.024), bevel=0.004, tag='suit', mat='leather')
        part(ball(0.006, 6, 4), BRASS, 'in', Pm @ T(0, -0.046, 0.012), bevel=0, gloss=0.6, tag='suit')
    # a harness over the shoulders and across the chest
    out = lambda p: ((M.inverted() @ p).x * 2.2, (M.inverted() @ p).y / 0.45, 0.25)
    hint = lambda p: (M.to_3x3() @ Vector(out(p))).normalized()
    for sgn in (-1, 1):
        pts = [M @ Vector(v) for v in [(sgn * x, skin(x, z, 0.007), z) for x, z in ((0.122, 1.035), (0.125, 1.14), (0.13, 1.28), (0.128, 1.4))] + [(sgn * 0.118, -0.06, 1.492), (sgn * 0.11, 0.04, 1.49)] + [(sgn * x, -skin(x, z, 0.007), z) for x, z in ((0.1, 1.4), (0.09, 1.2), (0.09, 1.035))]]
        part(ribbon(pts, 0.032, 0.006, hint, 5), '#5a3a26', 'in', bevel=0, tag='suit', mat='leather', jit=0.03)
        part(box(0.042, 0.01, 0.03), BRASS, 'in', M @ T(sgn * 0.127, skin(0.127, 1.2, 0.012), 1.2) @ R(sgn * rad(28), 'Z'), bevel=0.003, gloss=0.6, tag='suit')
    # the box on its chest: two small dials, three lamps, a knob; a hose from it over the shoulder to the air on its back
    C = M @ T(0, -0.166, 1.25)
    part(box(0.2, 0.09, 0.15), ENAMEL, 'in', C @ T(0, 0.015, 0), bevel=0.012, seg=3, gloss=0.3, tag='suit', jit=0.03)
    part(box(0.17, 0.004, 0.12), '#3a4a44', 'in', C @ T(0, -0.031, 0), bevel=0.001, mat='enamel', tag='suit')
    for x, name in ((-0.045, 'gauge_a'), (0.045, 'gauge_b')):
        Mg = C @ T(x, -0.034, 0.022)
        part(lathe([(0.021, 0), (0.03, 0), (0.031, 0.005), (0.026, 0.008), (0.021, 0.006)], 16, close=True), BRASS, 'in', Mg @ YA, bevel=0, gloss=0.6, tag='suit')
        part(disc(0.022, 16, cell(name)), '#ffffff', 'in', Mg @ T(0, -0.003, 0), bevel=0, mat='print', jit=0, tag='suit')
    for k, col in enumerate(('#ff6a50', '#8dffa0', '#ffd27a')):
        part(ball(0.007, 8, 6, s=(1, 0.6, 1)), col, 'in', C @ T(-0.05 + 0.028 * k, -0.034, -0.035), bevel=0, mat='glassy', gloss=0.6, jit=0, tag='suit')
        part(slab(0.0065, 0.01, 0, 0.003, 0, 2 * pi, 10), BRASS, 'in', C @ T(-0.05 + 0.028 * k, -0.0325, -0.035) @ YA, bevel=0, gloss=0.6, tag='suit')
    part(cyl(0.013, 0.016, 12, r2=0.011), RUBBER, 'in', C @ T(0.052, -0.04, -0.035) @ YA, bevel=0.002, tag='suit', mat='rubber')
    for sx in (-1, 1):
        for sz in (-1, 1): part(cyl(0.004, 0.003, 6), STEEL, 'in', C @ T(sx * 0.09, -0.0315, sz * 0.065) @ YA, bevel=0, gloss=0.6, tag='suit')
    part(tube([M @ Vector(v) for v in ((0.1, -0.17, 1.27), (0.16, -0.17, 1.3), (0.2, -0.1, 1.44), (0.2, 0.02, 1.53), (0.13, 0.13, 1.5), (0.075, 0.168, 1.44))], 0.012, 8, 6), '#2a2a2e', 'in', bevel=0, tag='suit', mat='rubber')
    for v in ((0.1, -0.17, 1.27), (0.075, 0.168, 1.44)): part(ball(0.016, 8, 6), BRASS, 'in', M @ T(*v), bevel=0, gloss=0.6, tag='suit')
    # the air itself: two bottles on a back board, strapped, a valve on each and a pipe between
    part(box(0.27, 0.02, 0.42), '#5a3a26', 'in', M @ T(0, 0.13, 1.21), bevel=0.008, tag='suit', mat='leather')
    for sx in (-1, 1):
        Mb = M @ T(sx * 0.078, 0.168, 1.02)
        part(lathe([(0, 0), (0.03, 0.004), (0.045, 0.03), (0.045, 0.33), (0.03, 0.37), (0.014, 0.385), (0.014, 0.41), (0, 0.41)], 14), '#6c9a94', 'in', Mb, bevel=0, gloss=0.3, jit=0.04, mat='enamel', tag='suit')
        part(cyl(0.02, 0.022, 8), BRASS, 'in', Mb @ T(0, 0, 0.42), bevel=0.003, gloss=0.6, tag='suit')
        hoop(Mb @ Vector((0, 0, 0.45)), UP, 0.022, 0.004, 10, RED, tag='suit', mat='enamel')
        rod(Mb @ Vector((0, 0, 0.43)), Mb @ Vector((0, 0, 0.45)), 0.004, STEEL, 5, tag='suit')
    part(tube([M @ Vector(v) for v in ((-0.078, 0.168, 1.435), (-0.04, 0.168, 1.46), (0.04, 0.168, 1.46), (0.078, 0.168, 1.435))], 0.006, 6, 3), COPPER, 'in', bevel=0, gloss=0.6, tag='suit')
    for z in (1.09, 1.3): part(slab(0.128, 0.134, z - 0.016, z + 0.016, 0, 2 * pi, 20), LEATHER, 'in', M @ T(0, 0.166, 0) @ S(1, 0.46, 1), bevel=0.002, tag='suit', jit=0.03)
    # the collar: a brass ring with its bolts, dark inside
    part(slab(0.122, 0.172, 1.493, 1.533, 0, 2 * pi, 24), BRASS, 'in', M @ T(0, 0.004, 0), bevel=0.006, gloss=0.6, tag='suit')
    for k in range(12): part(cyl(0.008, 0.006, 6), STEEL, 'in', M @ T(0.147 * cos(k * pi / 6), 0.004 + 0.147 * sin(k * pi / 6), 1.535), bevel=0.001, gloss=0.6, tag='suit')
    part(slab(0.03, 0.124, 1.496, 1.5, 0, 2 * pi, 20), '#1a1614', 'in', M @ T(0, 0.004, 0), bevel=0, tag='suit', mat='rubber')
    for sgn in (-1, 1):
        # an arm: bellows at the shoulder and the elbow, a brass cuff, a gauntlet, a glove with its fingers
        arm = [M @ Vector(v) for v in ((sgn * 0.2, 0.0, 1.43), (sgn * 0.262, 0.0, 1.33), (sgn * 0.295, -0.008, 1.14), (sgn * 0.305, -0.04, 0.93), (sgn * 0.306, -0.043, 0.875))]
        part(sleeve(arm, lambda u: 0.078 - 0.016 * u, ((0.03, 0.2, 3), (0.38, 0.6, 4)), 0.011, 10, 13), SUIT, 'in', bevel=0, rough=0.003, grit=12, tag='suit', mat='cloth', jit=0.03)
        W0 = M @ T(sgn * 0.306, -0.043, 0)
        part(slab(0.058, 0.07, 0.868, 0.9, 0, 2 * pi, 16), BRASS, 'in', W0, bevel=0.004, gloss=0.6, tag='suit')
        part(lathe([(0, 0.872), (0.064, 0.872), (0.05, 0.8), (0.043, 0.79), (0, 0.79)], 14), '#6b5a48', 'in', W0, bevel=0, tag='suit', mat='leather', jit=0.04)
        G = W0 @ T(0, -0.004, 0.745)
        part(box(0.078, 0.034, 0.1), '#6b5a48', 'in', G, bevel=0.014, seg=3, tag='suit', mat='leather', jit=0.04, rough=0.002, grit=20)
        for k in range(4):
            x = -0.029 + 0.0193 * k; L = (0.058, 0.066, 0.062, 0.05)[k]
            part(tube([(x, 0, -0.045), (x, -0.004, -0.045 - L * 0.5), (x, -0.016, -0.045 - L)], lambda u: 0.0092 - 0.0015 * u, 6, 3), '#6b5a48', 'in', G, bevel=0, tag='suit', mat='leather', jit=0.04)
        part(tube([(sgn * -0.04, -0.004, 0.01), (sgn * -0.058, -0.016, -0.02), (sgn * -0.058, -0.028, -0.05)], lambda u: 0.011 - 0.002 * u, 6, 3), '#6b5a48', 'in', G, bevel=0, tag='suit', mat='leather', jit=0.04)
        # a leg: bellows at the knee, a gaiter buckled over the boot
        leg = [M @ Vector(v) for v in ((sgn * 0.1, 0.0, 0.9), (sgn * 0.105, -0.006, 0.72), (sgn * 0.11, -0.016, 0.52), (sgn * 0.114, -0.005, 0.24))]
        part(sleeve(leg, lambda u: 0.094 - 0.018 * u, ((0.42, 0.68, 4),), 0.011, 10, 16), SUIT, 'in', bevel=0, rough=0.003, grit=12, tag='suit', mat='cloth', jit=0.03)
        L0 = M @ T(sgn * 0.114, -0.005, 0)
        part(lathe([(0, 0.2), (0.066, 0.2), (0.085, 0.215), (0.083, 0.3), (0.09, 0.375), (0.091, 0.392), (0, 0.392)], 14), '#6b5a48', 'in', L0, bevel=0, tag='suit', mat='leather', jit=0.04)
        hoop(L0 @ Vector((0, 0, 0.392)), UP, 0.089, 0.008, 14, '#3a2a20', tag='suit', mat='leather')
        for z in (0.25, 0.33):
            part(slab(0.083, 0.089, z - 0.011, z + 0.011, 0, 2 * pi, 14), '#3a2a20', 'in', L0, bevel=0.002, tag='suit', mat='leather')
            part(box(0.026, 0.008, 0.03), BRASS, 'in', L0 @ T(sgn * 0.045, -0.076, z) @ R(sgn * rad(30), 'Z'), bevel=0.002, gloss=0.6, tag='suit')
        # the boot: a thick sole with a heel, a capped toe, laced
        Bt = L0 @ T(0, -0.05, 0.009)
        part(box(0.125, 0.3, 0.03), '#1c1a1a', 'in', Bt @ T(0, 0, 0.015), bevel=0.01, tag='suit', mat='rubber')
        part(box(0.115, 0.09, 0.02), '#1c1a1a', 'in', Bt @ T(0, 0.1, 0.0), bevel=0.006, tag='suit', mat='rubber')
        part(box(0.112, 0.28, 0.09), '#4a3528', 'in', Bt @ T(0, 0, 0.07), bevel=0.036, seg=4, tag='suit', mat='leather', jit=0.04)
        part(lathe([(0, 0.07), (0.062, 0.07), (0.07, 0.12), (0.07, 0.2), (0.064, 0.215), (0, 0.215)], 14), '#4a3528', 'in', Bt @ T(0, 0.05, 0), bevel=0, tag='suit', mat='leather', jit=0.04)
        part(ball(0.058, 12, 8, s=(1, 1.1, 0.72)), '#2e2420', 'in', Bt @ T(0, -0.095, 0.064), bevel=0, tag='suit', mat='leather', gloss=0.3)
        for k in range(4):
            part(tube([(-0.03, -0.035 + 0.02 * k, 0.118 + 0.012 * k), (0, -0.04 + 0.02 * k, 0.123 + 0.012 * k), (0.03, -0.035 + 0.02 * k, 0.118 + 0.012 * k)], 0.003, 4, 3), CANVAS, 'in', Bt, bevel=0, tag='suit', mat='rope')
    # patches: a knee mended, the ship's mark on its breast, a name
    part(slab(0.0915, 0.096, 0.7, 0.8, pi - 0.55, pi + 0.45, 6), '#b9a36a', 'in', M @ T(0.104, -0.004, 0), bevel=0.001, tag='suit', mat='canvas', jit=0.04)
    for x, name, w in ((0.072, 'emblem', 0.062), (-0.072, 'tag_a', 0.06)):
        Pm = M @ T(x, skin(abs(x), 1.4, 0.004), 1.4) @ R(rad(19 if x > 0 else -19), 'Z')
        part(box(w + 0.012, 0.004, (w if name == 'emblem' else w / 2) + 0.012), '#b9a36a', 'in', Pm, bevel=0.001, tag='suit', mat='canvas')
        label(name, Pm @ T(0, -0.0032, 0), w).vertex_groups.new(name='suit').add(range(4), 1.0, 'REPLACE')
    # a line coiled at its belt, and a small glass strapped to its wrist
    for k in range(5): hoop(M @ Vector((-0.2, -0.05 - 0.004 * k, 0.9 - 0.004 * k)), (0.5, -0.86, 0.1), 0.055 - 0.002 * k, 0.006, 14, ROPE, tag='suit', jit=0.06)
    part(ribbon([M @ Vector(v) for v in ((-0.2, -0.06, 0.96), (-0.205, -0.085, 0.95), (-0.2, -0.06, 0.94))], 0.02, 0.003, (0, -1, 0), 4), LEATHER, 'in', bevel=0, tag='suit')
    Mw = M @ T(0.302, -0.098, 0.98) @ R(rad(6), 'Z')
    part(box(0.05, 0.016, 0.05), ENAMEL, 'in', Mw, bevel=0.005, tag='suit', gloss=0.3)
    part(disc(0.018, 14, cell('gauge_c')), '#ffffff', 'in', Mw @ T(0, -0.0085, 0), bevel=0, mat='print', jit=0, tag='suit')
    part(slab(0.064, 0.07, 0.965, 0.995, 0, 2 * pi, 14), '#3a2a20', 'in', M @ T(0.302, -0.03, 0), bevel=0.002, tag='suit', mat='leather')

    # ---- the helmet, on a shelf of its own over the suit ----
    part(slab(2.08, 2.39, ZF + 1.95, ZF + 1.98, rad(145), rad(165), 6), WOOD, 'in', bevel=0.006)
    part(slab(2.075, 2.09, ZF + 1.975, ZF + 1.995, rad(145.3), rad(164.7), 6), WOOD_D, 'in', bevel=0.004)
    for a in (146.5, 163.5):
        part(box(0.03, 0.26, 0.03), WOOD_D, 'in', at(rad(a), 2.25, ZF + 1.935), bevel=0.006)
        rod(P(rad(a), 2.13, ZF + 1.93), P(rad(a), 2.385, ZF + 1.72), 0.011, IRON, 6, gloss=0.4)
    H = at(rad(155), 2.22, ZF + 1.98 + 0.186)
    Hs = H @ S(1.15, 1, 0.95)
    Hf = Hs @ INTO                         # (turned so that what is made round +Z is round the way the helmet looks)
    kh = dict(tag='suit')
    Rh, lat = 0.19, 0.685                  # the dome; how far round from the front its window reaches (radians)
    back = [lat + (pi - lat) * i / 16 for i in range(1, 17)]
    dome = [(Rh * sin(lat) - 0.012, Rh * cos(lat) - 0.014), (Rh * sin(lat), Rh * cos(lat) + 0.004)] + [(Rh * sin(a), Rh * cos(a)) for a in back] + [((Rh - 0.012) * sin(a), (Rh - 0.012) * cos(a)) for a in reversed(back[:-1])]
    part(lathe(dome, 40, close=True), CREAM, 'in', Hf, bevel=0, gloss=0.4, jit=0.02, mat='enamel', **kh)
    part(lathe([(0, 0.176), (0.045, 0.171), (0.085, 0.156), (0.112, 0.138), (0.112, 0.128), (0.085, 0.146), (0.045, 0.161), (0, 0.166)], 32, close=True), '#18222c', 'in', Hf, bevel=0, gloss=0.7, jit=0, mat='glassy', **kh)
    part(tube([(Rh * sin(lat) * cos(t), Rh * sin(lat) * sin(t), Rh * cos(lat) + 0.002) for t in [i * 2 * pi / 40 for i in range(40)]], 0.011, 8, 1, cyclic=True), BRASS, 'in', Hf, bevel=0, gloss=0.6, **kh)
    for k in range(10):
        t = k * pi / 5 + 0.31
        part(ball(0.006, 6, 4), STEEL, 'in', Hf @ T(Rh * sin(lat) * cos(t), Rh * sin(lat) * sin(t), Rh * cos(lat) + 0.012), bevel=0, gloss=0.6, **kh)
    # its neck ring, with bolts and a gasket; a brass boss over each ear; a lamp, an aerial, a strip of padding over the crown
    part(slab(0.128, 0.178, -0.186, -0.15, 0, 2 * pi, 24), BRASS, 'in', H, bevel=0.006, gloss=0.6, **kh)
    part(slab(0.12, 0.17, -0.19, -0.184, 0, 2 * pi, 24), '#1c1a1a', 'in', H, bevel=0, mat='rubber', **kh)
    for k in range(12): part(cyl(0.008, 0.006, 6), STEEL, 'in', H @ T(0.153 * cos(k * pi / 6 + 0.26), 0.153 * sin(k * pi / 6 + 0.26), -0.148), bevel=0.001, gloss=0.6, **kh)
    for sx in (-1, 1):
        E = H @ T(sx * 0.208, 0.02, -0.01) @ R(sx * pi / 2, 'Y')
        part(lathe([(0, 0.02), (0.035, 0.02), (0.05, 0.008), (0.052, -0.02), (0, -0.02)], 16, close=True), BRASS, 'in', E, bevel=0, gloss=0.6, **kh)
        for k in range(6): part(ball(0.005, 6, 4), STEEL, 'in', E @ T(0.041 * cos(k * pi / 3), 0.041 * sin(k * pi / 3), 0.015), bevel=0, gloss=0.6, **kh)
    Lm = H @ T(0.2, -0.075, 0.085)
    part(cyl(0.028, 0.07, 12, r2=0.034), BRASS, 'in', Lm @ YA, bevel=0.003, gloss=0.6, **kh)
    part(cyl(0.029, 0.006, 12), '#ffd890', 'in', Lm @ T(0, -0.037, 0) @ YA, bevel=0, mat='glassy', gloss=0.6, jit=0, **kh)
    part(box(0.03, 0.05, 0.016), BRASS, 'in', H @ T(0.185, -0.04, 0.07), bevel=0.004, gloss=0.6, **kh)
    rod(H @ Vector((-0.125, 0.06, 0.13)), H @ Vector((-0.15, -0.02, 0.21)), 0.004, STEEL, 5, gloss=0.6, **kh)
    part(ball(0.011, 8, 6), RED, 'in', H @ T(-0.15, -0.02, 0.214), bevel=0, mat='enamel', **kh)
    part(cyl(0.016, 0.02, 8), BRASS, 'in', H @ T(-0.125, 0.06, 0.133), bevel=0.003, gloss=0.6, **kh)
    crown = [Hs @ Vector((0, -(Rh + 0.004) * cos(a), (Rh + 0.004) * sin(a))) for a in [rad(58 + 12 * i) for i in range(10)]]
    part(ribbon(crown, 0.05, 0.008, lambda p: (p - Hs.translation).normalized(), 3), '#5a3a26', 'in', bevel=0, mat='leather', jit=0.03, **kh)
    Vm = H @ T(0, -0.128, -0.143)
    part(cyl(0.022, 0.034, 10), BRASS, 'in', Vm @ YA, bevel=0.003, gloss=0.6, **kh)
    for k in range(3): part(box(0.028, 0.004, 0.004), DARK, 'in', Vm @ T(0, -0.018, -0.009 + 0.009 * k), bevel=0, **kh)
    part(tube([H @ Vector(v) for v in ((0, 0.19, -0.06), (0.0, 0.215, -0.1), (0.0, 0.2, -0.16))], 0.014, 8, 3), BRASS, 'in', bevel=0, gloss=0.6, **kh)
    # what else is on the shelf: a pair of spare gloves, a tin, a folded cloth
    Sx = at(rad(163.2), 2.26, ZF + 1.98)
    part(box(0.1, 0.16, 0.035), '#6b5a48', 'in', Sx @ T(0, 0, 0.018) @ R(0.3, 'Z'), bevel=0.014, seg=3, mat='leather', jit=0.04, rough=0.003, grit=18)
    part(box(0.09, 0.15, 0.03), '#6b5a48', 'in', Sx @ T(0.01, 0.01, 0.05) @ R(0.55, 'Z'), bevel=0.012, seg=3, mat='leather', jit=0.06, rough=0.003, grit=18)
    Sy = at(rad(147.2), 2.25, ZF + 1.98)
    part(cyl(0.05, 0.07, 14), '#3f6b8a', 'in', Sy @ T(0, 0, 0.036), bevel=0.004, mat='tin', gloss=0.4)
    part(cyl(0.052, 0.012, 14), STEEL, 'in', Sy @ T(0, 0, 0.076), bevel=0.003, gloss=0.6, mat='tin')
    label('SPARES', Sy @ T(0, -0.051, 0.036), 0.07)
    part(box(0.12, 0.14, 0.03), '#b9a98a', 'in', Sy @ T(0.02, -0.02, 0.1) @ R(0.2, 'Z'), bevel=0.01, seg=3, mat='cloth', jit=0.04, rough=0.003, grit=14)

    # ---- bottles of air beside it: strapped to the wall, a valve and a gauge on each ----
    for k in range(2):
        Mo2 = at(rad(139 + 4.6 * k), 2.24, ZF)
        part(lathe([(0, 0.004), (0.06, 0.004), (0.085, 0.02), (0.09, 0.05), (0.09, 0.55), (0.06, 0.64), (0.025, 0.68), (0.025, 0.72), (0, 0.72)], 16), '#6c9a94', 'in', Mo2, bevel=0, gloss=0.3, jit=0.04, mat='enamel')
        part(slab(0.089, 0.094, 0.44, 0.5, 0, 2 * pi, 16), RED, 'in', Mo2, bevel=0.001, mat='stripe')
        part(cyl(0.035, 0.03, 8), BRASS, 'in', Mo2 @ T(0, 0, 0.735), bevel=0.004, gloss=0.6)
        rod(Mo2 @ Vector((0, 0, 0.75)), Mo2 @ Vector((0, 0, 0.79)), 0.006, STEEL, 6, gloss=0.6)
        hoop(Mo2 @ Vector((0, 0, 0.79)), UP, 0.035, 0.005, 12, RED, mat='enamel')
        for a in (0, pi / 2): part(box(0.07, 0.006, 0.006), RED, 'in', Mo2 @ T(0, 0, 0.79) @ R(a, 'Z'), bevel=0, mat='enamel')
        rod(Mo2 @ Vector((0, -0.03, 0.735)), Mo2 @ Vector((0, -0.07, 0.735)), 0.007, BRASS, 6, gloss=0.6)
        gauge(Mo2 @ T(0, -0.075, 0.735) @ R(rad(-25), 'X'), 0.026, 'gauge_b' if k else 'gauge_a', live=False)
        label('AIR  12', Mo2 @ T(0, -0.0915, 0.3), 0.075)
    for z in (ZF + 0.2, ZF + 0.56):
        strap = [P(rad(136.6), 2.39, z), P(rad(136.75), 2.2, z), P(rad(137.6), 2.146, z), P(rad(141.3), 2.143, z), P(rad(145.0), 2.146, z), P(rad(145.85), 2.2, z), P(rad(146.0), 2.39, z)]
        part(ribbon(strap, 0.032, 0.004, lambda q: (-q.x, -q.y, 0), 1), '#4a3528', 'in', bevel=0, mat='leather', jit=0.03)
        part(box(0.035, 0.01, 0.03), BRASS, 'in', at(rad(141.3), 2.132, z), bevel=0.003, gloss=0.6)


def door_panel():
    """By the door, on the stove's side: the lever that works the ramp, and the two lamps that say whether there is air outside."""
    D = W(-161.2, 2.42, 0.011)
    part(box(0.24, 0.016, 0.54), WOOD_D, 'in', D, bevel=0.006)
    f = -0.0085
    for sx in (-1, 1):
        for sz in (-1, 1): nail(D @ T(sx * 0.105, f, sz * 0.255) @ INTO, 0.005, 0.003, BRASS)
    for x, kind, col, name in ((-0.052, 'lit6', '#7dff9a', 'AIR'), (0.052, 'lit7', '#ff5a40', 'NO AIR')):
        part(box(0.086, 0.004, 0.084), BRASS, 'in', D @ T(x, f - 0.001, 0.195), bevel=0.001, gloss=0.5)
        bead(D @ T(x, f - 0.003, 0.207), kind, col, 0.015)
        label(name, D @ T(x, f - 0.0042, 0.168), 0.07)
    label('SUIT UP', D @ T(0, f - 0.001, 0.105), 0.19)
    for sx in (-1, 1): nail(D @ T(sx * 0.103, f - 0.001, 0.105) @ INTO, 0.004, 0.003, STEEL)
    Ml = D @ T(0, f, -0.035)
    part(box(0.1, 0.05, 0.2), IRON, 'in', Ml @ T(0, -0.022, 0), bevel=0.012, gloss=0.4)
    part(box(0.016, 0.012, 0.13), DARK, 'in', Ml @ T(0, -0.045, 0), bevel=0.003, mat='soot')
    part(tube([(0, -0.045, -0.04), (0, -0.16, 0.09)], 0.012, 6, 1), STEEL, 'in', Ml, bevel=0, gloss=0.6)
    part(ball(0.03, 12, 8), RED, 'in', Ml @ T(0, -0.17, 0.1), bevel=0, gloss=0.3, mat='enamel')
    for sx in (-1, 1):
        for sz in (-1, 1): nail(Ml @ T(sx * 0.038, -0.047, sz * 0.085) @ INTO, 0.005, 0.004, STEEL)
    label('PULL TO SEAL', D @ T(0, f - 0.001, -0.168), 0.16)
    part(box(0.2, 0.006, 0.035), RED, 'in', D @ T(0, f - 0.002, -0.228), bevel=0.001, mat='stripe')
    part(ball(0.016, 10, 8), '#9fe6a0', 'in', at(pi - rad(6), RI - 0.05, DOOR_TOP + 0.24), bevel=0, glow=1.5)


# ============================================================================= what is seen from inside the helmet
def visor():
    """
    Built round the wearer's eye at the origin, looking along +Y, about four times the size of life. The window is
    as wide and as tall as an oval would be but squarer in its corners, so that at 16:9 only a little of what is
    round it shows there, and a line of it along the top and bottom. Round the window: a gasket, a narrow brass
    rim with its rivets, a stitched pad, and the lining beyond; small things in the corners.
    """
    O = Vector([float(v) for v in os.environ.get('VISOR_AT', '0,0,0').split(',')])     # (moved aside only to be looked at)
    MO = T(*O)
    A, Bv, Y0, n, pw = 0.436, 0.234, 0.40, 96, 4.6
    def edge(f):
        c, sn = cos(f), sin(f)
        r = (abs(c / A) ** pw + abs(sn / Bv) ** pw) ** (-1 / pw)
        return Vector((r * c, 0, r * sn))
    def frame(f):
        """The window's edge that way round: where it is, which way is along it, which way is out from it."""
        t = (edge(f + 1e-3) - edge(f - 1e-3)).normalized()
        return edge(f), t, Vector((t.z, 0, -t.x))
    FR = [frame(2 * pi * i / n) for i in range(n)]
    def oval(prof):
        """A closed section [(out, deep)] carried round the window: out, from its edge; deep, away from the eye."""
        bm = bmesh.new(); m = len(prof)
        cols = [[bm.verts.new(c + nr * da + Vector((0, Y0 + dy, 0))) for da, dy in prof] for c, t, nr in FR]
        for i in range(n):
            a, b = cols[i], cols[(i + 1) % n]
            for j in range(m): bm.faces.new((a[j], a[(j + 1) % m], b[(j + 1) % m], b[j]))
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        return bm
    def on(da, dy, f):
        """A frame on what is round the window: its +X outward, its -Y toward the eye, its +Z along the edge."""
        c, t, nr = frame(f)
        m = Matrix((nr, Vector((0, 1, 0)), t)).transposed().to_4x4(); m.translation = c + nr * da + Vector((0, Y0 + dy, 0))
        return m
    # (places a set distance apart along the edge)
    cum = [0.0]
    for i in range(n): cum.append(cum[-1] + (FR[(i + 1) % n][0] - FR[i][0]).length)
    def spaced(step, start=0.0):
        k = max(1, round(cum[-1] / step)); out = []
        for j in range(k):
            d = (start + j * cum[-1] / k) % cum[-1]
            i = max(i for i in range(n) if cum[i] <= d)
            out.append(2 * pi * (i + (d - cum[i]) / (cum[i + 1] - cum[i])) / n)
        return out
    part(oval([(0.0, 0.006), (0.0, -0.0075), (0.0035, -0.01), (0.008, -0.0095), (0.0095, -0.005), (0.0095, 0.006)]), RUBBER, 'visor', MO, bevel=0, jit=0.02)
    part(oval([(0.0095, 0.004), (0.011, -0.0068), (0.0185, -0.0068), (0.0205, -0.0088), (0.0245, -0.0088), (0.0265, -0.0068), (0.0345, -0.0068), (0.037, -0.002), (0.037, 0.03), (0.02, 0.03)]), BRASS, 'visor', MO, bevel=0, gloss=0.6, jit=0.02)
    for f in spaced(0.052, 0.02):
        part(lathe([(0, 0), (0.0036, 0), (0.003, 0.0018), (0.0015, 0.0027), (0, 0.003)], 7), STEEL, 'visor', MO @ on(0.0305, -0.0068, f) @ R(pi / 2, 'X'), bevel=0, gloss=0.6)
    for f in spaced(0.104, 0.046):
        part(lathe([(0, 0), (0.0026, 0), (0.002, 0.0014), (0, 0.002)], 6), BRASS, 'visor', MO @ on(0.0148, -0.0068, f) @ R(pi / 2, 'X'), bevel=0, gloss=0.6)
    # the pad: leather, stitched along both its edges
    part(oval([(0.0372, 0.006), (0.0385, -0.011), (0.046, -0.0185), (0.057, -0.021), (0.068, -0.0195), (0.0775, -0.013), (0.08, 0.006)]), '#3f2d24', 'visor', MO, bevel=0, mat='leather', jit=0.03)
    for da, dy, st in ((0.0432, -0.0166, 0.0), (0.0738, -0.0167, 0.011)):
        for f in spaced(0.022, st):
            part(box(0.0016, 0.0014, 0.01), '#c2b38a', 'visor', MO @ on(da, dy, f), bevel=0, mat='rope', jit=0.06)
    part(oval([(0.0785, -0.011), (0.3, -0.15), (0.6, -0.34), (0.61, -0.325), (0.31, -0.13), (0.081, 0.004)]), '#4a3a2c', 'visor', MO, bevel=0, mat='quilt', jit=0.03)
    # ---- in the corners ----
    def toward(p):
        y = Vector(p).normalized(); x = y.cross(UP).normalized(); z = x.cross(y)
        m = Matrix((x, y, z)).transposed().to_4x4(); m.translation = Vector(p)
        return m
    corner = lambda sx, sz, x=0.39, z=0.212, y=0.3925: (sx * x * y / Y0, y, sz * z * y / Y0)
    flat = lambda *a: T(*corner(*a))        # (lying on the rim's own face, not turned to the eye)
    # low on the left: a small glass for the air, on its own pipe
    Mg = toward(corner(-1, -1, 0.39, 0.212, 0.378))
    gauge(MO @ Mg, 0.016, 'air', grp='visor')
    part(tube([Mg @ Vector((0.024, 0.01, -0.016)), Mg @ Vector((0.045, 0.015, -0.03)), Mg @ Vector((0.08, 0.017, -0.036))], 0.0032, 6, 3), COPPER, 'visor', MO, bevel=0, gloss=0.6)
    part(lathe([(0.003, 0), (0.0062, 0), (0.0062, 0.009), (0.003, 0.009)], 6, close=True), BRASS, 'visor', MO @ Mg @ T(0.026, 0.01, -0.017) @ R(-0.9, 'Y'), bevel=0, gloss=0.6)
    # low on the right: two small lamps, air about and none
    for k, (kind, col) in enumerate((('lit6', '#7dff9a'), ('lit7', '#ff5a40'))):
        Ml = flat(1, -1, 0.385 + 0.02 * k, 0.218 - 0.018 * k)
        bead(MO @ Ml, kind, col, 0.0062, grp='visor')
    # high on the right: the helmet's number; high on the left, the screw that holds the glass shut
    Mn = flat(1, 1, 0.385, 0.214, 0.3885) @ R(0.5, 'Y')
    part(box(0.05, 0.002, 0.0178), BRASS, 'visor', MO @ Mn @ T(0, 0.001, 0), bevel=0.0006, gloss=0.5)
    label('No. 2', MO @ Mn @ T(0, -0.0008, 0), 0.046, grp='visor')
    for sx in (-1, 1): part(lathe([(0, 0), (0.0016, 0), (0.0012, 0.001), (0, 0.0013)], 6), STEEL, 'visor', MO @ Mn @ T(sx * 0.0222, 0, 0) @ R(pi / 2, 'X'), bevel=0, gloss=0.6)
    Mw = flat(-1, 1, 0.39, 0.214)
    part(lathe([(0, 0), (0.0105, 0), (0.0105, 0.003), (0.006, 0.005), (0.006, 0.012), (0, 0.012)], 10), BRASS, 'visor', MO @ Mw @ R(pi / 2, 'X'), bevel=0, gloss=0.6)
    for sgn in (-1, 1):
        part(ball(0.0095, 8, 5, s=(1, 0.22, 0.62)), BRASS, 'visor', MO @ Mw @ R(0.6, 'Y') @ T(sgn * 0.0135, -0.0098, 0), bevel=0, gloss=0.6)
    # the valve one breathes out through, low in the middle: all but its top is below what can be seen
    Mv = toward((0.0, 0.384, -0.652 * 0.384))
    part(lathe([(0, -0.01), (0.021, -0.01), (0.027, -0.003), (0.027, 0.008), (0, 0.008)], 16, close=True), BRASS, 'visor', MO @ Mv @ R(-pi / 2, 'X'), bevel=0, gloss=0.6)
    for k in range(5): part(box(0.034 - 0.009 * abs(k - 2), 0.003, 0.0034), DARK, 'visor', MO @ Mv @ T(0, -0.0105, -0.015 + 0.0075 * k), bevel=0, mat='soot')
    # where the rim has been knocked, and rubbed
    for f, da, turn, L in ((rad(-31), 0.027, 0.5, 0.016), (rad(-27), 0.016, -0.3, 0.012), (rad(151), 0.028, 0.2, 0.018), (rad(33), 0.015, 1.2, 0.014), (rad(208), 0.03, -0.6, 0.02), (rad(147), 0.014, 0.9, 0.01), (rad(-150), 0.029, 0.4, 0.013)):
        part(box(L, 0.0008, 0.0011), STEEL, 'visor', MO @ on(da, -0.0072, f) @ R(turn, 'Y'), bevel=0, gloss=0.7, mat='steel')


# ============================================================================================ the chart table
def table():
    zt = 1.84
    part(slab(1.78, 2.39, zt - 0.04, zt, rad(-128), rad(-70), 16), WOOD, 'in', bevel=0.008)
    # (a brass rail along its edge, so that nothing slides off when the ship leans)
    part(tube([P(rad(a), 1.797, zt + 0.028) for a in range(-127, -70, 4)], 0.005, 6, 1), BRASS, 'in', bevel=0, gloss=0.6)
    for a in range(-127, -70, 8): rod(P(rad(a), 1.797, zt - 0.002), P(rad(a), 1.797, zt + 0.028), 0.004, BRASS, 5, gloss=0.6)
    for a0, a1 in ((-128, -115), (-83, -70)):
        part(slab(1.86, 2.39, ZF, zt - 0.04, rad(a0), rad(a1), 4), HONEY, 'in', bevel=0.008)
        # three drawers in each, with a pull and a tag
        for k, (z0, z1) in enumerate(((ZF + 0.05, ZF + 0.27), (ZF + 0.29, ZF + 0.51), (ZF + 0.53, zt - 0.06))):
            part(slab(1.846, 1.864, z0, z1, rad(a0 + 0.7), rad(a1 - 0.7), 4), WOOD, 'in', bevel=0.004, jit=0.06)
            Md = at(rad((a0 + a1) / 2), 1.846, (z0 + z1) / 2)
            part(tube([(-0.04, 0, -0.025), (-0.03, -0.024, -0.025), (0.03, -0.024, -0.025), (0.04, 0, -0.025)], 0.005, 6, 3), BRASS, 'in', Md, bevel=0, gloss=0.6)
            label(('tag_a', 'tag_b', 'tag_c')[k], Md @ T(0, -0.0015, 0.04), 0.075)
    # a stool
    st = P(rad(-99), 1.98, ZF)
    part(cyl(0.16, 0.04, 16), LEATHER, 'in', T(st.x, st.y, ZF + 0.46), bevel=0.012, jit=0.03, rough=0.003, grit=12)
    part(cyl(0.165, 0.02, 16), WOOD, 'in', T(st.x, st.y, ZF + 0.43), bevel=0.006)
    for a in (0, 2.1, 4.2): part(tube([st + Vector((0.07 * cos(a), 0.07 * sin(a), 0.42)), st + Vector((0.15 * cos(a), 0.15 * sin(a), 0))], 0.014, 6, 1), WOOD_D, 'in', bevel=0)
    hoop(st + Vector((0, 0, 0.16)), UP, 0.118, 0.007, 14, IRON, gloss=0.4)
    for k in range(8): part(ball(0.006, 6, 4), BRASS, 'in', T(st.x + 0.158 * cos(k * pi / 4), st.y + 0.158 * sin(k * pi / 4), ZF + 0.46), bevel=0, gloss=0.6)
    on = lambda th, r, turn=0.0: at(rad(th), r, zt) @ R(turn, 'Z')
    # the chart, with what is used on it: a rule, dividers, a glass
    part(box(0.64, 0.5, 0.004), '#dccfa8', 'in', on(-97, 2.07, 0.15) @ T(0, 0, 0.002), bevel=0, mat='paper')
    label('chart_table', on(-97, 2.07, 0.15) @ T(0, 0, 0.0052) @ FLAT, 0.62)
    part(box(0.3, 0.03, 0.006), BRASS, 'in', on(-104, 1.95, 0.6) @ T(0, 0, 0.009), bevel=0.002, gloss=0.6)
    Dv = on(-94.5, 2.05, -0.5) @ T(0, 0, 0.0095)
    for sgn in (-1, 1): part(tube([(0, 0, 0), (sgn * 0.035, -0.13, 0)], lambda u: 0.004 - 0.0025 * u, 6, 1), STEEL, 'in', Dv, bevel=0, gloss=0.6)
    part(cyl(0.008, 0.012, 10), BRASS, 'in', Dv @ T(0, 0, 0.002), bevel=0.002, gloss=0.6)
    part(tube([(0, 0, 0), (0, 0.03, 0)], 0.004, 6, 1), BRASS, 'in', Dv, bevel=0, gloss=0.6)
    Mg = on(-100.5, 1.93, 0.9) @ T(0, 0, 0.0098)
    hoop(Mg @ Vector((0, 0, 0.002)), Mg.to_3x3() @ UP, 0.04, 0.005, 18, BRASS, gloss=0.6)
    part(cyl(0.038, 0.004, 18), '#c4dcd8', 'in', Mg @ T(0, 0, 0.002), bevel=0, mat='glassy', gloss=0.7, jit=0)
    part(tube([(0.044, 0, 0.002), (0.14, 0, 0.004)], lambda u: 0.006 + 0.003 * u, 8, 1), WOOD_D, 'in', Mg, bevel=0)
    # books, with ribbons to keep a place
    for k, col in enumerate(('#7a3b2e', '#3f5f6b', '#c2a45a')):
        Mb = on(-120, 2.12, 0.3 * k - 0.2) @ T(0, 0, 0.018 + 0.036 * k)
        part(box(0.21 - 0.02 * k, 0.15, 0.035), col, 'in', Mb, bevel=0.006, jit=0.04, mat='leather')
        part(box(0.2 - 0.02 * k, 0.153, 0.027), '#e2d6b6', 'in', Mb @ T(0.0065, 0, 0), bevel=0, mat='paper')
        part(box(0.012, 0.05, 0.002), RED, 'in', Mb @ T(0.03 - 0.04 * k, -0.085, -0.005), bevel=0, mat='cloth')
    # a mug, a plate of biscuits
    part(lathe([(0, 0), (0.04, 0), (0.045, 0.09), (0.038, 0.09), (0.034, 0.012), (0, 0.012)], 14, close=True), CREAM, 'in', on(-85.6, 2.03), bevel=0, mat='enamel', gloss=0.3)
    part(tube([(0.043, 0, 0.02), (0.075, 0, 0.035), (0.075, 0, 0.06), (0.044, 0, 0.075)], 0.006, 5, 3), CREAM, 'in', on(-85.6, 2.03), bevel=0, mat='enamel')
    part(cyl(0.034, 0.003, 12), '#5a3a22', 'in', on(-85.6, 2.03) @ T(0, 0, 0.07), bevel=0, mat='glaze', gloss=0.5)
    part(lathe([(0, 0), (0.05, 0), (0.075, 0.012), (0.072, 0.016), (0.048, 0.006), (0, 0.006)], 16, close=True), '#d8d2c0', 'in', on(-83.4, 1.89), bevel=0, mat='enamel', gloss=0.3)
    for k in range(3): part(cyl(0.022, 0.008, 10), '#c79a5a', 'in', on(-83.4, 1.89) @ T(0.02 * cos(k * 2.1), 0.02 * sin(k * 2.1), 0.012 + 0.006 * k) @ R(0.2 * k, 'X'), bevel=0.002, jit=0.06, mat='paint', rough=0.0015, grit=40)
    # ink, pens, a candle for when the lamps are out
    Mi = on(-90.5, 2.27) @ T(0, 0, 0.0052)
    part(box(0.13, 0.07, 0.016), WOOD_D, 'in', Mi @ T(0, 0, 0.008), bevel=0.004)
    part(lathe([(0, 0), (0.024, 0), (0.027, 0.03), (0.015, 0.04), (0.013, 0.05), (0, 0.05)], 12), '#141c2c', 'in', Mi @ T(-0.035, 0, 0.016), bevel=0, mat='glassy', gloss=0.7, jit=0)
    part(slab(0.011, 0.017, 0.048, 0.056, 0, 2 * pi, 12), BRASS, 'in', Mi @ T(-0.035, 0, 0.016), bevel=0, gloss=0.6)
    for k in range(2):
        Mp = Mi @ T(0.025, -0.012 + 0.022 * k, 0.02) @ R(0.2 - 0.5 * k, 'Z')
        part(tube([(-0.06, 0, 0), (0.05, 0, 0)], lambda u: 0.0035 + 0.001 * sin(u * 3), 6, 1), ('#7a3b2e', '#2c2c30')[k], 'in', Mp, bevel=0, mat='enamel')
        part(tube([(0.05, 0, 0), (0.075, 0, 0)], lambda u: 0.003 * (1 - u) + 0.0005, 5, 1), STEEL, 'in', Mp, bevel=0, gloss=0.6)
    Mc = on(-94.6, 2.3) @ T(0, 0, 0.0052)
    part(lathe([(0, 0), (0.035, 0), (0.04, 0.008), (0.012, 0.014), (0.012, 0.03), (0.018, 0.034), (0, 0.034)], 14), BRASS, 'in', Mc, bevel=0, gloss=0.6)
    part(cyl(0.011, 0.09, 10), '#e8dcc0', 'in', Mc @ T(0, 0, 0.078), bevel=0.002, mat='paper', rough=0.001, grit=40)
    part(ball(0.006, 6, 6, s=(1, 1, 2.2)), '#ffc060', 'in', Mc @ T(0, 0, 0.138), bevel=0, glow=3)
    part(tube([(0.036, 0, 0.006), (0.058, 0, 0.012), (0.056, 0, 0.03), (0.04, 0, 0.026)], 0.003, 5, 3), BRASS, 'in', Mc, bevel=0, gloss=0.6)
    # the log, open at today, with a pencil across it
    Ml_ = on(-78.4, 2.08, 0.25)
    for sgn in (-1, 1):
        part(box(0.16, 0.225, 0.008), '#5a3a26', 'in', Ml_ @ T(sgn * 0.081, 0, 0.004), bevel=0.002, mat='leather')
        part(box(0.15, 0.212, 0.014), '#e2d6b6', 'in', Ml_ @ T(sgn * 0.077, 0, 0.014), bevel=0.003, mat='paper')
    label('note_a', Ml_ @ T(0, 0, 0.0226) @ FLAT, 0.29)
    part(tube([(-0.05, -0.06, 0.03), (0.1, 0.04, 0.03)], 0.004, 6, 1), '#c9a23a', 'in', Ml_, bevel=0, mat='enamel')
    # a rack of rolled charts at the back, and two more lying by the wall
    Mr = on(-113.2, 2.27, 0.1)
    part(box(0.2, 0.11, 0.012), WOOD_D, 'in', Mr @ T(0, 0, 0.006), bevel=0.003)
    for sx in (-1, 1): part(box(0.012, 0.11, 0.15), WOOD_D, 'in', Mr @ T(sx * 0.094, 0, 0.075), bevel=0.003)
    for sy in (-1, 1): part(box(0.2, 0.01, 0.05), WOOD, 'in', Mr @ T(0, sy * 0.05, 0.11), bevel=0.003, jit=0.05)
    for k in range(5):
        x = -0.07 + 0.035 * k; L = random.uniform(0.38, 0.52); r = random.uniform(0.014, 0.021)
        Mk = Mr @ T(x, 0.015 * (k % 2) - 0.008, 0.012) @ R(random.uniform(-0.08, 0.08), 'Y') @ R(random.uniform(-0.03, 0.1), 'X')
        part(cyl(r, L, 10), '#dccfa8', 'in', Mk @ T(0, 0, L / 2), bevel=0, mat='paper', jit=0.06)
        part(cyl(r * 0.55, L + 0.006, 8), '#b9a67c', 'in', Mk @ T(0, 0, L / 2), bevel=0, mat='paper')
        part(slab(r, r + 0.002, L * 0.55, L * 0.55 + 0.012, 0, 2 * pi, 10), (RED, '#3f5f6b')[k % 2], 'in', Mk, bevel=0, mat='cloth')
    for k in range(1):
        a0, a1 = -79.5 + 0.6 * k, -72.2 - 0.9 * k; r = 2.335 - 0.05 * k
        part(tube([P(rad(a0), r, zt + 0.021 + 0.002 * k), P(rad(a1), r, zt + 0.021 + 0.002 * k)], 0.02, 10, 1), '#dccfa8', 'in', bevel=0, mat='paper', jit=0.06)
        part(tube([P(rad(a0 - 0.15), r, zt + 0.021 + 0.002 * k), P(rad(a1 + 0.15), r, zt + 0.021 + 0.002 * k)], 0.011, 8, 1), '#b9a67c', 'in', bevel=0, mat='paper')
    # a globe of the home world
    Mg2 = on(-123, 2.2)
    part(cyl(0.06, 0.015, 12), BRASS, 'in', Mg2 @ T(0, 0, 0.008), bevel=0.004, gloss=0.6)
    part(tube([(0, 0, 0.01), (0, 0, 0.07)], 0.008, 6, 1), BRASS, 'in', Mg2, bevel=0, gloss=0.6)
    land = lambda p: '#5f8f4e' if sin(p.x * 31 + 1.3) * sin(p.y * 27) + sin(p.z * 23 + p.x * 9) * 0.6 > 0.25 else '#3f7f96'
    part(ball(0.105, 20, 14), land, 'in', Mg2 @ T(0, 0, 0.19), bevel=0, gloss=0.2, jit=0.02, mat='glaze')
    part(tube([(0.118 * sin(a), 0, 0.19 + 0.118 * cos(a)) for a in [i * pi / 12 for i in range(13)]], 0.006, 5, 1), BRASS, 'in', Mg2 @ R(0.4, 'Y'), bevel=0, gloss=0.6)
    # a lamp on the table
    Ml = on(-75, 2.22)
    part(cyl(0.055, 0.02, 12), BRASS, 'in', Ml @ T(0, 0, 0.01), bevel=0.004, gloss=0.6)
    part(tube([(0, 0, 0.02), (0, 0.02, 0.2), (0, -0.06, 0.3), (0, -0.13, 0.29)], 0.008, 6, 4), BRASS, 'in', Ml, bevel=0, gloss=0.6)
    part(lathe([(0.02, 0.05), (0.075, -0.03), (0.07, -0.03), (0.015, 0.045)], 14, close=True), TEAL, 'in', Ml @ T(0, -0.15, 0.275), bevel=0, gloss=0.3)
    part(ball(0.022, 8, 6), WARM, 'in', Ml @ T(0, -0.15, 0.262), bevel=0, glow=6)
    part(cyl(0.012, 0.012, 8), DARK, 'in', Ml @ T(0.03, -0.02, 0.026), bevel=0.002, mat='rubber')
    LIGHTS.append((Ml @ Vector((0, -0.15, 0.2)), WARM, 24))
    # under it: a keg in its cradle, a crate
    Mk = at(rad(-109.5), 2.17, ZF + 0.2) @ INTO
    part(lathe([(0, -0.19), (0.125, -0.19), (0.148, -0.1), (0.16, 0), (0.148, 0.1), (0.125, 0.19), (0, 0.19)], 20), WOOD, 'in', Mk, bevel=0, jit=0.05, mat='wood')
    for z, r in ((-0.15, 0.139), (-0.06, 0.156), (0.06, 0.156), (0.15, 0.139)): part(slab(r - 0.002, r + 0.006, z - 0.014, z + 0.014, 0, 2 * pi, 20), IRON, 'in', Mk, bevel=0.002, gloss=0.4)
    part(cyl(0.02, 0.02, 8), WOOD_D, 'in', Mk @ T(0, 0.158, 0) @ R(-pi / 2, 'X'), bevel=0.003)
    Kf = at(rad(-109.5), 2.17 - 0.19, ZF + 0.2)
    part(tube([(0, 0, -0.07), (0, -0.05, -0.07), (0, -0.06, -0.1)], 0.009, 6, 3), BRASS, 'in', Kf, bevel=0, gloss=0.6)
    part(box(0.012, 0.012, 0.05), BRASS, 'in', Kf @ T(0, -0.04, -0.045), bevel=0.002, gloss=0.6)
    label('LAMP OIL', Kf @ T(0, -0.002, 0.03), 0.13)
    for d in (-0.11, 0.11):
        part(box(0.3, 0.05, 0.075), WOOD_D, 'in', at(rad(-109.5), 2.17 + d, ZF + 0.038), bevel=0.008)
    Cr = at(rad(-89.5), 2.19, ZF)
    crate(Cr, 0.32, 0.3, 0.27, 'RATIONS')
    # a shelf over the porthole, with what is kept on it
    part(slab(2.12, 2.39, 3.02, 3.05, rad(-128), rad(-72), 14), WOOD, 'in', bevel=0.006)
    part(tube([P(rad(a), 2.13, 3.1) for a in range(-127, -72, 5)], 0.006, 5, 1), BRASS, 'in', bevel=0, gloss=0.6)
    for a in range(-127, -72, 10): rod(P(rad(a), 2.13, 3.05), P(rad(a), 2.13, 3.1), 0.004, BRASS, 5, gloss=0.6)
    for a in (-126, -100, -74): part(box(0.03, 0.24, 0.16), WOOD_D, 'in', at(rad(a), 2.27, 2.95), bevel=0.006)
    names = ['JAM', 'PICKLES', 'HONEY', 'SALT']
    for j in range(9):
        M = at(rad(-124.5 + 6.1 * j), 2.27, 3.05)
        kind = 'bjbjxbjbj'[j]
        if kind == 'b':
            h = random.uniform(0.16, 0.22)
            for q in range(random.choice((2, 3))):
                col = random.choice(('#7a3b2e', '#3f5f6b', '#c2a45a', '#5d6b4a', '#b9a98a')); hh = h - 0.02 * q
                Mb = M @ T(-0.05 + 0.04 * q, 0, hh / 2) @ R(random.uniform(-0.05, 0.05), 'Y')
                part(box(0.035, 0.14, hh), col, 'in', Mb, bevel=0.005, jit=0.05, mat='leather')
                part(box(0.027, 0.132, hh + 0.003), '#e2d6b6', 'in', Mb @ T(0, 0.006, 0), bevel=0, mat='paper')
                for z in (-0.3, 0.3): part(box(0.036, 0.004, 0.006), '#c9a23a', 'in', Mb @ T(0, -0.0695, hh * z), bevel=0, mat='brass', gloss=0.5)
        elif kind == 'j':
            h = random.uniform(0.11, 0.15); nm = names.pop()
            part(box(0.088, 0.088, h), random.choice(('#9ab8b0', '#c9b27a', '#b98a6a')), 'in', M @ T(0, 0, h / 2), bevel=0.012, seg=3, mat='glassy', gloss=0.6, jit=0.05)
            part(cyl(0.034, 0.024, 12), BRASS, 'in', M @ T(0, 0, h + 0.01), bevel=0.004, gloss=0.6)
            label(nm, M @ T(0, -0.0455, h * 0.5), 0.066)
        else:
            part(box(0.14, 0.14, 0.1), HONEY, 'in', M @ T(0, 0, 0.05), bevel=0.006, jit=0.06)
            part(box(0.146, 0.146, 0.02), WOOD, 'in', M @ T(0, 0, 0.1), bevel=0.004, jit=0.06)
            label('MATCHES', M @ T(0, -0.0715, 0.05), 0.1)
    # mugs on hooks under it
    for k, col in enumerate(('#3f6b8a', '#cfc8b2', '#b3432a')):
        Mm = at(rad(-122.5 + 3.2 * k), 2.14, 2.925)
        mug_on_hook(Mm, col)
    # a framed chart; a chart of the moon pinned up
    part(box(0.5, 0.02, 0.36), WOOD_D, 'in', at(rad(-137.6), RI - 0.012, 2.6), bevel=0.006)
    part(box(0.44, 0.022, 0.3), '#d3c8a6', 'in', at(rad(-137.6), RI - 0.014, 2.6), bevel=0)
    Mm = W(-77.6, 2.64, 0.014) @ R(-0.03, 'Y')
    label('map_moon', Mm, 0.4)
    for sx in (-1, 1):
        for sz in (-1, 1): part(ball(0.006, 6, 4), BRASS, 'in', Mm @ T(sx * 0.19, -0.002, sz * 0.14), bevel=0, gloss=0.6)


def mug_on_hook(Mm, col):
    """A mug hung by its handle from a hook under a shelf. Mm: under the shelf's edge, 95 mm below it."""
    part(tube([(0, 0, 0.095), (0, -0.02, 0.07), (0, -0.01, 0.045)], 0.003, 5, 3), BRASS, 'in', Mm, bevel=0, gloss=0.6)
    Mg = Mm @ T(0, 0.018, -0.026) @ R(rad(80), 'X')
    part(lathe([(0, 0), (0.036, 0), (0.04, 0.08), (0.034, 0.08), (0.03, 0.01), (0, 0.01)], 12, close=True), col, 'in', Mg, bevel=0, mat='enamel', gloss=0.3, jit=0.04)
    part(tube([(0, 0.038, 0.015), (0, 0.065, 0.03), (0, 0.065, 0.055), (0, 0.039, 0.068)], 0.005, 5, 3), col, 'in', Mg, bevel=0, mat='enamel')


def crate(M, w, d, h, name=None, lid=True):
    """A crate of slats on a frame, with rope handles. M: where it stands, its -Y its front."""
    part(box(w - 0.03, d - 0.03, h - 0.02), '#8a6a48', 'in', M @ T(0, 0, h / 2), bevel=0.004, jit=0.05, mat='wood')
    n = max(2, round(h / 0.085)); sh = h / n
    for k in range(n):
        for sy in (-1, 1): part(box(w, 0.012, sh - 0.012), HONEY, 'in', M @ T(0, sy * (d / 2 - 0.006), (k + 0.5) * sh), bevel=0.003, jit=0.08)
        for sx in (-1, 1): part(box(0.012, d - 0.024, sh - 0.012), HONEY, 'in', M @ T(sx * (w / 2 - 0.006), 0, (k + 0.5) * sh), bevel=0.003, jit=0.08)
    for sx in (-1, 1):
        for sy in (-1, 1): part(box(0.035, 0.035, h + 0.006), WOOD, 'in', M @ T(sx * (w / 2 - 0.005), sy * (d / 2 - 0.005), h / 2), bevel=0.004, jit=0.05)
        part(tube([(sx * (w / 2 + 0.002), -0.06, h * 0.68), (sx * (w / 2 + 0.05), -0.03, h * 0.52), (sx * (w / 2 + 0.05), 0.03, h * 0.52), (sx * (w / 2 + 0.002), 0.06, h * 0.68)], 0.008, 6, 4), ROPE, 'in', M, bevel=0, jit=0.05)
        for sy in (-1, 1): nail(M @ T(sx * (w / 2 - 0.02), -d / 2 - 0.0005, h * (0.25 + 0.25 * sy + 0.25)) @ INTO, 0.004, 0.003)
    if lid:
        for k in range(3): part(box(w / 3 - 0.008, d + 0.01, 0.012), HONEY, 'in', M @ T((k - 1) * w / 3, 0, h + 0.006), bevel=0.003, jit=0.08)
    if name: label(name, M @ T(0, -d / 2 - 0.0015, (n - 0.5) * sh if n < 3 else 1.5 * sh), min(0.17, w * 0.55))


# ================================================================================================ the hammock
def hammock():
    A, B = P(rad(70), 2.32, 2.45), P(rad(130), 2.32, 2.45)
    d = B - A; mid = (A + B) / 2
    n = Vector((-mid.x, -mid.y, 0)).normalized(); up = Vector((0, 0, 1))
    wid = lambda u: 0.36 * (0.22 + 0.78 * sin(pi * u) ** 0.6)
    def fn(u, v):
        c = A + d * (0.1 + 0.8 * u) + up * (-0.16 - 0.4 * sin(pi * u))
        s = (v - 0.5) * 2
        return c + n * (s * wid(u) + 0.02) + up * (0.15 * s * s * wid(u) / 0.36)
    for j in range(9):
        part(sheet(26, 2, lambda u, v: fn(u, (j + v) / 9), 0.012), '#a9604a' if j % 2 else CANVAS, 'in', bevel=0, jit=0.03, sharp=80, mat='canvas')
    for end, u in ((A, 0), (B, 1)):
        # an eye in the wall, a hook, a spreader of wood, cords from one to the other
        Me = at(rad(70 if u == 0 else 130), RI - 0.004, 2.45)
        part(cyl(0.04, 0.008, 12), BRASS, 'in', Me @ YA, bevel=0.002, gloss=0.6)
        for k in range(4): nail(Me @ T(0.028 * cos(k * pi / 2 + 0.8), -0.004, 0.028 * sin(k * pi / 2 + 0.8)) @ INTO, 0.004, 0.003, STEEL)
        hoop(end, Me.to_3x3() @ Vector((1, 0, 0)), 0.028, 0.006, 12, BRASS, gloss=0.6)
        rod(Me.translation, end + (Me.translation - end).normalized() * 0.026, 0.007, BRASS, 6, gloss=0.6)
        a_, b_ = Vector(fn(u, 0)), Vector(fn(u, 1))
        part(tube([a_ + (a_ - b_) * 0.06, b_ + (b_ - a_) * 0.06], 0.013, 8, 1), WOOD, 'in', bevel=0, jit=0.05)
        for v in (0, 0.2, 0.4, 0.6, 0.8, 1): part(tube([end, Vector(fn(u, v))], 0.005, 4, 1), ROPE, 'in', bevel=0)
    # a fringe along each side of it
    for v in (0, 1):
        for i in range(1, 16):
            p = Vector(fn(i / 16, v)); q = Vector(fn(i / 16, v + (0.04 if v else -0.04)))
            part(tube([p, p + (p - q).normalized() * -0.012 + up * -0.05], 0.0035, 4, 1), '#a9604a' if i % 2 else CANVAS, 'in', bevel=0, mat='rope', jit=0.05)
    # in it: a blanket folded, a pillow, a book left face down
    turn = atan2(-d.x, d.y)
    part(box(0.36, 0.32, 0.035), '#8a4a3a', 'in', T(*(Vector(fn(0.42, 0.5)) + up * 0.03)) @ R(turn, 'Z'), bevel=0.016, seg=3, jit=0.05, mat='knit', rough=0.008, grit=7, sub=2)
    part(box(0.34, 0.3, 0.035), '#b9a36a', 'in', T(*(Vector(fn(0.43, 0.5)) + up * 0.066)) @ R(turn + 0.06, 'Z'), bevel=0.016, seg=3, jit=0.05, mat='knit', rough=0.008, grit=7, sub=2)
    part(ball(0.16, 14, 10, s=(1, 0.7, 0.42)), '#e2d8bf', 'in', T(*(Vector(fn(0.82, 0.5)) + up * 0.07)) @ R(turn + pi / 2, 'Z'), bevel=0, mat='cloth', rough=0.012, grit=8)
    Bk = T(*(Vector(fn(0.62, 0.45)) + up * 0.05)) @ R(turn + 0.5, 'Z')
    for sgn in (-1, 1): part(box(0.1, 0.15, 0.012), '#3f5f6b', 'in', Bk @ R(sgn * 0.5, 'Y') @ T(sgn * 0.05, 0, 0), bevel=0.003, mat='leather', jit=0.04)
    # under it: a chest, a crate, sacks, a keg, a bucket, boots, a broom
    Mc = at(rad(100), 1.98, ZF)
    part(box(0.7, 0.42, 0.26), WOOD, 'in', Mc @ T(0, 0, 0.13), bevel=0.012, jit=0.05)
    part(box(0.72, 0.44, 0.1), WOOD_D, 'in', Mc @ T(0, 0, 0.31), bevel=0.03, seg=3)
    for x in (-0.22, 0.22):
        part(box(0.05, 0.45, 0.375), IRON, 'in', Mc @ T(x, 0, 0.186), bevel=0.006, gloss=0.4)
        for z in (0.05, 0.15, 0.24, 0.31): nail(Mc @ T(x, -0.2255, z) @ INTO, 0.006, 0.004, STEEL)
        for y in (-0.12, 0, 0.12): nail(Mc @ T(x, y, 0.374), 0.006, 0.004, STEEL)
    for sx in (-1, 1):
        for sy in (-1, 1):
            for z in (0.02, 0.24): part(box(0.05, 0.05, 0.04), BRASS, 'in', Mc @ T(sx * 0.33, sy * 0.19, z), bevel=0.006, gloss=0.5)
        part(tube([(sx * 0.352, -0.07, 0.2), (sx * 0.4, -0.04, 0.13), (sx * 0.4, 0.04, 0.13), (sx * 0.352, 0.07, 0.2)], 0.009, 6, 4), ROPE, 'in', Mc, bevel=0, jit=0.05)
    part(box(0.09, 0.012, 0.1), BRASS, 'in', Mc @ T(0, -0.218, 0.25), bevel=0.004, gloss=0.6)
    part(box(0.05, 0.022, 0.05), BRASS, 'in', Mc @ T(0, -0.236, 0.2), bevel=0.008, gloss=0.6)
    part(tube([(-0.016, -0.236, 0.222), (-0.016, -0.236, 0.25), (0.016, -0.236, 0.25), (0.016, -0.236, 0.222)], 0.004, 6, 3), STEEL, 'in', Mc, bevel=0, gloss=0.6)
    # (on its lid: a coil of line, a tin box)
    for k in range(5): hoop(Mc @ Vector((-0.02, 0.02, 0.37 + 0.011 * k)), UP, 0.1 - 0.004 * k, 0.007, 16, ROPE, jit=0.06)
    part(box(0.16, 0.11, 0.07), '#5d6b4a', 'in', Mc @ T(0.24, -0.04, 0.396) @ R(0.3, 'Z'), bevel=0.01, seg=3, mat='tin', gloss=0.4)
    part(tube([(-0.04, 0, 0.035), (-0.03, 0, 0.055), (0.03, 0, 0.055), (0.04, 0, 0.035)], 0.004, 5, 3), STEEL, 'in', Mc @ T(0.24, -0.04, 0.396) @ R(0.3, 'Z'), bevel=0, gloss=0.6)
    crate(at(rad(127), 2.0, ZF) @ R(0.2, 'Z'), 0.4, 0.4, 0.34, 'THIS WAY UP')
    # (sacks: one standing, tied at the neck; one lying on the crate)
    Ms = at(rad(76), 2.02, ZF)
    part(lathe([(0, 0), (0.17, 0), (0.22, 0.1), (0.21, 0.26), (0.15, 0.36), (0.06, 0.4), (0.07, 0.44), (0.1, 0.48), (0, 0.46)], 16), CANVAS, 'in', Ms, bevel=0, jit=0.04, mat='canvas', rough=0.02, grit=6)
    hoop(Ms @ Vector((0, 0, 0.405)), UP, 0.064, 0.007, 12, ROPE)
    rod(Ms @ Vector((0.05, -0.045, 0.405)), Ms @ Vector((0.085, -0.1, 0.33)), 0.0015, ROPE, 4)
    label('tag_b', Ms @ T(0.09, -0.105, 0.3) @ R(0.35, 'Y') @ R(-0.2, 'X'), 0.08)
    part(ball(0.2, 14, 10, s=(1, 0.62, 0.42)), '#b9a67c', 'in', at(rad(127), 2.0, ZF + 0.44) @ R(0.5, 'Z'), bevel=0, jit=0.04, mat='canvas', rough=0.02, grit=6)
    # (a keg standing, with a scoop on it)
    Mk = at(rad(86.2), 2.1, ZF)
    part(lathe([(0, 0), (0.125, 0), (0.15, 0.1), (0.158, 0.2), (0.15, 0.3), (0.125, 0.4), (0, 0.4)], 18), WOOD, 'in', Mk, bevel=0, jit=0.05, mat='wood')
    for z, r in ((0.04, 0.134), (0.13, 0.153), (0.27, 0.153), (0.36, 0.134)): part(slab(r - 0.002, r + 0.006, z - 0.014, z + 0.014, 0, 2 * pi, 18), IRON, 'in', Mk, bevel=0.002, gloss=0.4)
    part(lathe([(0, 0), (0.04, 0), (0.05, 0.05), (0.045, 0.05), (0.037, 0.006), (0, 0.006)], 12, close=True), '#8f918c', 'in', Mk @ T(0.02, -0.01, 0.4), bevel=0, mat='tin', gloss=0.45)
    part(tube([(0.065, -0.01, 0.435), (0.14, -0.03, 0.445)], 0.006, 6, 1), WOOD_D, 'in', Mk, bevel=0)
    label('SALT', Mk @ T(0, -0.1605, 0.2), 0.075)
    # (a bucket with a rag over its rim, a pair of boots, a broom against the wall)
    Mb = at(rad(113.6), 2.12, ZF)
    part(lathe([(0, 0), (0.1, 0), (0.135, 0.24), (0.14, 0.245), (0.128, 0.245), (0.094, 0.012), (0, 0.012)], 16, close=True), '#8f918c', 'in', Mb, bevel=0, mat='tin', gloss=0.45, jit=0.03)
    for z in (0.08, 0.2): part(slab(0.105 + 0.146 * z, 0.109 + 0.146 * z, z - 0.006, z + 0.006, 0, 2 * pi, 16), '#7c7e7a', 'in', Mb, bevel=0, mat='tin', gloss=0.4)
    part(tube([(0.137 * cos(t), 0, 0.235 + 0.137 * sin(t) * 0.6) for t in [pi + i * pi / 10 for i in range(11)]], 0.004, 5, 1), STEEL, 'in', Mb @ R(0.4, 'Z'), bevel=0, gloss=0.6)
    def rag(u, v):
        x = -0.05 + 0.1 * u
        if v < 0.4: return (x, -0.151 - 0.004 * sin(u * 6), 0.256 - (0.4 - v) / 0.4 * (0.16 + 0.02 * sin(u * 4)))
        if v < 0.6: a = (v - 0.4) / 0.2 * pi; return (x, -0.137 - 0.014 * cos(a), 0.256 + 0.006 * sin(a))
        z = 0.256 - (v - 0.6) / 0.4 * 0.07
        return (x, -(0.128 - 0.146 * (0.245 - z)) + 0.007, z)
    part(sheet(4, 10, rag, 0.005), '#b9a98a', 'in', Mb, bevel=0, mat='cloth', jit=0.04, sharp=80)
    for k in range(2):
        Mt = at(rad(119.2 + 3.1 * k), 2.2, ZF) @ R(0.2 - 0.5 * k, 'Z')
        part(box(0.1, 0.27, 0.025), '#1c1a1a', 'in', Mt @ T(0, 0, 0.0135), bevel=0.008, mat='rubber')
        part(box(0.092, 0.25, 0.08), '#4a3528', 'in', Mt @ T(0, 0, 0.06), bevel=0.032, seg=4, mat='leather', jit=0.05)
        part(lathe([(0, 0.06), (0.05, 0.06), (0.058, 0.12), (0.062, 0.3), (0.056, 0.31), (0, 0.3)], 12), '#4a3528', 'in', Mt @ T(0, 0.06, 0) @ R(0.08 - 0.2 * k, 'Y'), bevel=0, mat='leather', jit=0.05, rough=0.004, grit=14)
    foot, head = P(rad(131.5), 2.24, ZF + 0.14), P(rad(132.6), 2.375, ZF + 1.5)
    part(tube([foot, head], 0.013, 8, 1), WOOD, 'in', bevel=0, jit=0.05)
    Mbr = aim(foot, foot * 2 - head)
    part(box(0.26, 0.05, 0.05), WOOD_D, 'in', Mbr @ T(0, 0, 0.0), bevel=0.008)
    part(box(0.25, 0.04, 0.115), '#b0935f', 'in', Mbr @ T(0, 0, 0.08), bevel=0.004, mat='rope', rough=0.004, grit=30, jit=0.05)


# ======================================================================================== lamps, pipes and wires
def lights_and_pipes():
    part(tube([(0, 0, 4.15), (0, 0, 3.66)], 0.008, 5, 1), DARK, 'in', bevel=0)
    lantern('in', (0, 0, 3.5), 1.3, 7, 140)
    tl = P(rad(-100), 1.72, 3.28)
    part(tube([tl + Vector((0, 0, 0.36)), tl + Vector((0, 0, 0.13))], 0.006, 5, 1), DARK, 'in', bevel=0)
    lantern('in', tl, 1.1, 7, 50)
    # a copper pipe round the left wall from the stove to the desk, and a grey one round the right from the air:
    # each in lengths joined by flanges, held by brackets, with a wheel to shut it
    for col, sgn, r, a_from in ((COPPER, -1, 0.022, 150), (STEEL, 1, 0.016, 140)):
        run = [P(rad(sgn * a), 2.365, 3.25) for a in range(a_from, 61, -8)] + [P(rad(sgn * 62), 2.37, 2.6), P(rad(sgn * 61), 2.37, 1.95)]
        if sgn > 0: run = [P(rad(141), 2.25, ZF + 0.76), P(rad(141), 2.3, 2.6)] + run
        part(tube(run, r, 8, 3), col, 'in', bevel=0, gloss=0.6 if sgn < 0 else 0.5)
        for a in range(a_from - 10, 61, -24):
            Mf = at(rad(sgn * a), 2.365, 3.25) @ R(pi / 2, 'Y')
            part(slab(r - 0.001, r + 0.013, -0.012, 0.012, 0, 2 * pi, 12), BRASS, 'in', Mf, bevel=0.002, gloss=0.6)
            for k in range(4): part(ball(0.004, 6, 4), STEEL, 'in', Mf @ T((r + 0.008) * cos(k * pi / 2 + 0.7), (r + 0.008) * sin(k * pi / 2 + 0.7), 0.013), bevel=0, gloss=0.6)
        for a in range(a_from - 22, 61, -24):
            part(box(0.03, 0.05, 0.07), IRON, 'in', at(rad(sgn * a), 2.375, 3.25), bevel=0.006, gloss=0.4)
            part(slab(r + 0.001, r + 0.006, -0.012, 0.012, 0, 2 * pi, 10), IRON, 'in', at(rad(sgn * a), 2.365, 3.25) @ R(pi / 2, 'Y'), bevel=0, gloss=0.4)
        Mv = at(rad(-132), 2.32, 3.25) if sgn < 0 else at(rad(141), 2.255, 3.0)
        part(tube([(0.07 * cos(i * pi / 8), -0.02, 0.07 * sin(i * pi / 8)) for i in range(16)], 0.009, 5, 1, cyclic=True), RED, 'in', Mv, bevel=0, mat='enamel')
        for a in (0, pi / 2): part(box(0.14, 0.012, 0.012), RED, 'in', Mv @ T(0, -0.02, 0) @ R(a, 'Y'), bevel=0, mat='enamel')
        part(cyl(0.012, 0.05, 8), BRASS, 'in', Mv @ T(0, 0.012, 0) @ YA, bevel=0.002, gloss=0.6)
        part(box(0.05, 0.05, 0.06), BRASS, 'in', Mv @ T(0, 0.045, 0), bevel=0.008, gloss=0.6)
    # (a small glass on the copper one, where it comes down by the window)
    gauge(W(-62, 2.72, 0.06), 0.032, 'gauge_b', live=False)
    part(cyl(0.008, 0.04, 6), BRASS, 'in', W(-62, 2.72, 0.04) @ YA, bevel=0, gloss=0.6)
    # cables from the ring down to the desk, clipped to the rafter on their way
    cab = [(0.25, 0.2, 4.15), (0.9, 0.85, 3.74), (1.62, 1.42, 3.34), (1.86, 1.48, 2.5), (1.88, 1.45, 1.93)]
    part(tube(cab, 0.016, 6, 5), DARK, 'in', bevel=0, mat='rubber')
    part(tube([Vector(p) + Vector((0.02, -0.03, -0.03)) for p in cab], 0.008, 5, 5), '#7a2f22', 'in', bevel=0, mat='rubber')
    for p in path(cab, 5)[2:-2:3]: part(box(0.05, 0.05, 0.012), BRASS, 'in', aim(p + Vector((0, 0, 0.02)), p + Vector((0.3, -0.3, 1))), bevel=0.003, gloss=0.5)


# ======================================================================================= what else is in the room
zc = lambda r: 4.285 - (r - 0.34) * 0.4434        # the underside of the ceiling's boards, so far from the middle
BC = atan2(0.94, 2.12)                             # how steeply it slopes


def under_roof():
    # short timbers from rafter to rafter under the boards, in the bays behind the pilot
    for bay in (90, 120, 150, -90, -120, -150):
        for r in (1.15, 2.02):
            if bay == -150 and r > 2: continue
            for half in (-1, 1):
                th = rad(bay + half * 7.5); rm = r * cos(rad(7.5)); L = 2 * r * sin(rad(7.5))
                part(box(L - 0.058, 0.045, 0.05), WOOD_D, 'in', at(th, rm, zc(rm) - 0.031) @ R(-BC, 'X'), bevel=0.006, jit=0.06)
    # an oar and a fishing rod, slung under the rafters over the chart table
    for k, (ra, za) in enumerate(((2.25, 3.315), (2.2, 3.33))):
        a, b = P(rad(-73.5), ra, za), P(rad(-136.5), ra, za)
        if k == 0:
            part(tube([a, b], 0.019, 10, 1), WOOD, 'in', bevel=0, jit=0.05)
            Mo = aim(b, a)
            part(box(0.15, 0.014, 0.56), WOOD, 'in', Mo @ T(0, 0, 0.3), bevel=0.006, jit=0.05)
            part(box(0.16, 0.018, 0.03), COPPER, 'in', Mo @ T(0, 0, 0.03), bevel=0.003, gloss=0.6)
            part(tube([a, a + (b - a).normalized() * 0.22], 0.022, 10, 1), LEATHER, 'in', bevel=0, jit=0.04)
        else:
            part(tube([a, b], lambda u: 0.013 - 0.009 * u, 8, 1), '#6a4a2a', 'in', bevel=0, mat='wood', jit=0.05)
            ax = (b - a).normalized()
            part(tube([a, a + ax * 0.3], 0.017, 10, 1), '#b89a6a', 'in', bevel=0, mat='wicker')
            part(cyl(0.035, 0.03, 12), BRASS, 'in', aim(a + ax * 0.36 + Vector((0, 0, -0.04)), a + ax * 0.36 + Vector((0, 0, -0.04)) + ax.cross(UP)), bevel=0.004, gloss=0.6)
            for u in (0.3, 0.48, 0.66, 0.82, 0.97): hoop(a + ax * (b - a).length * u + Vector((0, 0, -0.022)), ax, 0.011, 0.002, 8, STEEL, gloss=0.6)
    for th in (-75, -135):
        rr = 1.897 / cos(rad(abs(th + 105)))
        Mu = at(rad(th), rr, 3.33)
        part(tube([(0.0, -0.12, 0.09), (0.0, -0.12, -0.05), (0.0, 0.08, -0.05), (0.0, 0.08, 0.09)], 0.006, 6, 3), IRON, 'in', Mu, bevel=0, gloss=0.4)
    # a roll of canvas strapped up in the bay to the right of the window; lengths of spare pipe in the bay to the left
    a, b = P(rad(62.8), 2.12, 3.4), P(rad(73.4), 2.12, 3.4)
    part(tube([a, b], 0.072, 14, 1), CANVAS, 'in', bevel=0, mat='canvas', jit=0.04, rough=0.006, grit=9)
    part(tube([a + (a - b).normalized() * 0.012, b + (b - a).normalized() * 0.012], 0.05, 12, 1), '#b9a67c', 'in', bevel=0, mat='canvas')
    for u in (0.22, 0.78):
        c = lerp(a, b, u)
        hoop(c, b - a, 0.076, 0.006, 14, LEATHER)
        rod(c + Vector((0, 0, 0.07)), c + Vector((0, 0, 0.11)), 0.006, LEATHER, 5)
        part(box(0.02, 0.008, 0.02), BRASS, 'in', T(*(c + Vector((0, 0, -0.078)))), bevel=0.002, gloss=0.6)
    a, b = P(rad(-62.8), 2.12, 3.42), P(rad(-73.4), 2.12, 3.42)
    ax = (b - a).normalized(); e1 = Vector((-ax.y, ax.x, 0))
    for k, off in enumerate(((0, 0), (0.045, 0), (0.0225, 0.039))):
        o = e1 * (off[0] - 0.0225) + UP * off[1]
        part(tube([a + o - ax * 0.03 * k, b + o + ax * 0.02 * k], 0.021, 10, 1), (COPPER, STEEL, COPPER)[k], 'in', bevel=0, gloss=0.6, jit=0.04)
    for u in (0.2, 0.8):
        c = lerp(a, b, u) + UP * 0.013
        for j in range(3): hoop(c + ax * 0.008 * (j - 1), ax, 0.05, 0.004, 12, ROPE, jit=0.05)
        rod(c + Vector((0, 0, 0.045)), c + Vector((0, 0, 0.085)), 0.004, IRON, 5)
    # by the stove's bay: herbs hung up to dry, a string of onions
    for k, r in enumerate((1.38, 1.6, 1.82)):
        top = P(rad(-135), r, zc(r) - 0.113)
        L = 0.2 + 0.07 * (k % 2)
        rod(top, top + Vector((0, 0, -L)), 0.002, ROPE, 4)
        tie = top + Vector((0, 0, -L))
        for j in range(7):
            a = j * 0.9 + k; tip = tie + Vector((0.03 * cos(a), 0.03 * sin(a), 0.05 + 0.01 * (j % 3)))
            part(tube([tip, tie, tie + Vector((0.4 * (tip.x - tie.x), 0.4 * (tip.y - tie.y), -0.07))], 0.003, 4, 2), '#7a6a3a', 'in', bevel=0, mat='rope', jit=0.08)
        hoop(tie, UP, 0.014, 0.004, 8, ROPE)
        for j in range(9):
            a = j * 2.4 + k; d = 0.012 + 0.006 * (j % 3); z = -0.05 - 0.024 * j
            part(ball(0.036 - 0.0015 * j, 7, 5, s=(1, 0.55, 1.5)), ('#6f8a4a', '#8a8a52', '#5f7a46', '#7a9450')[(j + k) % 4], 'in', T(tie.x + d * cos(a), tie.y + d * sin(a), tie.z + z) @ R(a, 'Z') @ R(0.35, 'X'), bevel=0, mat='paint', jit=0.1, rough=0.006, grit=40)
    top = P(rad(-137.5), 2.02, zc(2.02) - 0.02)
    for k in range(8):
        p = top + Vector((0.02 * sin(k * 2.4), 0.02 * cos(k * 2.4), -0.06 - 0.058 * k))
        part(ball(0.036, 10, 8, s=(1, 1, 0.9)), ('#c08a4a', '#b9763a', '#caa05a')[k % 3], 'in', T(*p), bevel=0, mat='glaze', gloss=0.3, jit=0.06, rough=0.003, grit=20)
        part(tube([p + Vector((0, 0, 0.03)), p + Vector((0, 0, 0.05))], 0.004, 4, 1), '#b9a67c', 'in', bevel=0, mat='rope')
    rod(top, top + Vector((0, 0, -0.52)), 0.003, ROPE, 4)
    # a ladder lashed up over the door
    Ld = at(pi, 1.55, zc(1.55) - 0.045) @ R(-BC, 'X')
    for sx in (-1, 1): part(box(0.03, 1.32, 0.05), WOOD, 'in', Ld @ T(sx * 0.165, 0, 0), bevel=0.006, jit=0.05)
    for k in range(6): part(tube([(-0.165, -0.55 + 0.22 * k, 0), (0.165, -0.55 + 0.22 * k, 0)], 0.013, 8, 1), WOOD_D, 'in', Ld, bevel=0, jit=0.05)
    for y in (-0.42, 0.42):
        for sx in (-1, 1):
            part(tube([(sx * 0.19, y, 0.045), (sx * 0.19, y, -0.03), (sx * 0.14, y, -0.03), (sx * 0.14, y, 0.045)], 0.004, 5, 3), IRON, 'in', Ld, bevel=0, gloss=0.4)
    # wiring: from the fuses along the wall's head and up a rafter to the lantern's ring, clipped every little way
    wire = [P(rad(a), RI - 0.082, 3.325) for a in range(190, 226, 6)] + [P(rad(225) + 0.045 / r, r, zc(r) - 0.075) for r in (2.3, 1.9, 1.5, 1.1, 0.7, 0.45)]
    part(tube(wire, 0.006, 6, 3), '#2a2a2e', 'in', bevel=0, mat='rubber')
    part(tube([p + Vector((0, 0, -0.014)) for p in wire], 0.004, 5, 3), '#7a2f22', 'in', bevel=0, mat='rubber')
    for p in path(wire, 3)[1:-1:2]: part(box(0.03, 0.012, 0.035), BRASS, 'in', T(*(p + Vector((0, 0, -0.006)))) @ R(-atan2(p.x, p.y), 'Z'), bevel=0.003, gloss=0.5)
    # a lantern hung near the suit, and the ship's own plan pinned to the ceiling beyond it
    lp = P(rad(143.5), 1.95, 3.22)
    rod(lp + Vector((0, 0, 0.11)), Vector((lp.x, lp.y, zc(1.95))), 0.004, DARK, 5)
    lantern('in', lp, 0.9, 7, 30)
    Mp = at(rad(154.5), 1.62, zc(1.62) - 0.012) @ R(-BC, 'X') @ R(pi / 2, 'X')
    label('blueprint', Mp, 0.44)
    for sx in (-1, 1):
        for sz in (-1, 1): part(ball(0.007, 6, 4), BRASS, 'in', Mp @ T(sx * 0.21, -0.002, sz * 0.155), bevel=0, gloss=0.6)


def on_walls():
    # a rail of pegs to the right of the window: a coil of line, a satchel, a glass in its case
    part(slab(RI - 0.024, RI - 0.002, 2.925, 2.985, rad(62.9), rad(70.4), 4), WOOD_D, 'in', bevel=0.005)
    for a in (63.6, 66.2, 69.4):
        rod(P(rad(a), RI - 0.02, 2.955), P(rad(a), RI - 0.095, 2.975), 0.008, WOOD, 6)
        part(ball(0.011, 8, 6), WOOD, 'in', T(*P(rad(a), RI - 0.097, 2.976)), bevel=0)
    for k in range(5): hoop(P(rad(63.6), RI - 0.06 - 0.006 * k, 2.86 - 0.003 * k), P(rad(63.6), 1, 0), 0.085 - 0.003 * k, 0.007, 16, ROPE, jit=0.06)
    Ms = W(66.2, 2.79, 0.06)
    part(box(0.2, 0.075, 0.2), CANVAS, 'in', Ms, bevel=0.03, seg=3, mat='canvas', jit=0.04, rough=0.007, grit=10)
    part(box(0.205, 0.02, 0.11), '#5a3a26', 'in', Ms @ T(0, -0.035, 0.05), bevel=0.008, mat='leather', rough=0.003, grit=12)
    part(box(0.03, 0.012, 0.04), BRASS, 'in', Ms @ T(0, -0.048, 0.0), bevel=0.003, gloss=0.6)
    part(ribbon([Ms @ Vector(v) for v in ((-0.09, 0.0, 0.1), (-0.05, 0.02, 0.17), (0, 0.035, 0.188), (0.05, 0.02, 0.17), (0.09, 0.0, 0.1))], 0.025, 0.004, (0, -1, 0), 4), '#5a3a26', 'in', bevel=0, mat='leather')
    Mc = W(69.4, 2.83, 0.055)
    for sx in (-1, 1): part(lathe([(0, -0.06), (0.03, -0.06), (0.034, -0.05), (0.03, 0.05), (0.024, 0.062), (0, 0.062)], 12), '#4a3528', 'in', Mc @ T(sx * 0.034, 0, 0), bevel=0, mat='leather', jit=0.04)
    part(box(0.04, 0.03, 0.03), BRASS, 'in', Mc @ T(0, 0, 0.01), bevel=0.006, gloss=0.6)
    part(ribbon([Mc @ Vector(v) for v in ((-0.04, 0.0, 0.06), (-0.02, 0.01, 0.125), (0, 0.02, 0.143), (0.02, 0.01, 0.125), (0.04, 0.0, 0.06))], 0.014, 0.003, (0, -1, 0), 4), '#3a2a20', 'in', bevel=0, mat='leather')
    # to the left of it: a glass for the weather, and one for the heat
    Mb = W(-66.4, 2.97, 0.012)
    part(cyl(0.085, 0.02, 20), WOOD_D, 'in', Mb @ YA, bevel=0.006)
    gauge(Mb @ T(0, -0.011, 0), 0.055, 'gauge_a', live=False)
    part(box(0.05, 0.016, 0.16), WOOD_D, 'in', Mb @ T(0, 0, -0.14), bevel=0.006)
    part(cyl(0.02, 0.01, 12), BRASS, 'in', Mb @ T(0, -0.01, -0.19) @ YA, bevel=0.002, gloss=0.6)
    hoop(Mb @ Vector((0, -0.004, 0.095)), Mb.to_3x3() @ Vector((0, 1, 0)), 0.014, 0.003, 10, BRASS, gloss=0.6)
    Mt = W(-69.8, 2.93, 0.01)
    part(box(0.04, 0.012, 0.24), '#d8cfae', 'in', Mt, bevel=0.003, mat='pwood')
    part(tube([(0, -0.009, -0.09), (0, -0.009, 0.1)], 0.003, 6, 1), '#b84030', 'in', Mt, bevel=0, mat='glassy', gloss=0.7, jit=0)
    part(ball(0.007, 8, 6), '#b84030', 'in', Mt @ T(0, -0.009, -0.095), bevel=0, mat='glassy', gloss=0.7, jit=0)
    for z in (-0.105, 0.108): part(box(0.03, 0.006, 0.008), BRASS, 'in', Mt @ T(0, -0.008, z), bevel=0.001, gloss=0.6)
    # washing on a line over the stove's corner
    A, B = P(rad(-128.5), RI - 0.02, 3.13), P(rad(-164.2), RI - 0.02, 3.14)
    for p, th in ((A, -128.5), (B, -164.2)):
        part(tube([(0, 0.02, 0), (0, -0.02, 0), (0, -0.03, 0.03)], 0.005, 6, 3), BRASS, 'in', at(rad(th), RI - 0.02, p.z - 0.004), bevel=0, gloss=0.6)
    line = lambda u: lerp(A, B, u) + Vector((0, 0, -0.09 * sin(pi * u)))
    part(tube([line(i / 14) for i in range(15)], 0.0025, 4, 1), ROPE, 'in', bevel=0)
    def hang(u, w, L, col, mat='cloth'):
        c = line(u); t = (line(u + 0.02) - line(u - 0.02)).normalized(); nn = Vector((-t.y, t.x, 0)).normalized()
        ph = random.uniform(0, 6)
        def f(a, b):
            d = abs(b - 0.5) * 2; front = b < 0.5
            fold = 0.014 * sin(a * 11 + ph) * (0.3 + d) + 0.01 * sin(a * 5 + ph * 2) * d
            return c + t * (a - 0.5) * w * (1 - 0.1 * d * sin(a * pi)) + nn * ((0.008 if front else -0.008) + fold) + Vector((0, 0, 0.004 - L * d * (1 if front else 0.72) * (1 + 0.06 * sin(a * 7 + ph))))
        part(sheet(10, 10, f, 0.004), col, 'in', bevel=0, mat=mat, jit=0.05, sharp=80)
        for a in (0.2, 0.8): part(box(0.008, 0.014, 0.035), WOOD, 'in', T(*(c + t * (a - 0.5) * w + Vector((0, 0, -0.008)))) @ R(-atan2(nn.x, nn.y), 'Z'), bevel=0.002, jit=0.05)
    hang(0.3, 0.3, 0.3, '#c9c0a8')
    hang(0.52, 0.11, 0.22, '#8a4a3a', 'knit'); hang(0.6, 0.11, 0.2, '#8a4a3a', 'knit')
    hang(0.76, 0.2, 0.17, '#6f8a9a')
    # the board of tools: more on it, and a shelf of small things under it
    M = at(rad(136), RI - 0.02, 2.62)
    for k in range(3):
        x = -0.13 + 0.035 * k
        x = -0.14 + 0.035 * k
        part(tube([(x, -0.025, 0.24), (x, -0.025, 0.19)], 0.009, 8, 1), (RED, '#c9a23a', '#3f5f6b')[k], 'in', M, bevel=0, mat='enamel')
        part(tube([(x, -0.025, 0.19), (x, -0.025, 0.128 + 0.012 * k)], 0.003, 6, 1), STEEL, 'in', M, bevel=0, gloss=0.6)
    part(box(0.12, 0.012, 0.025), '#5a3a26', 'in', M @ T(-0.105, -0.031, 0.205), bevel=0.003, mat='leather')
    hoop(M @ Vector((0.12, -0.028, 0.165)), M.to_3x3() @ Vector((0, 1, 0)), 0.035, 0.012, 14, '#2a2a2e', mat='rubber')
    part(tube([(0.12, 0, 0.19), (0.12, -0.05, 0.192)], 0.005, 5, 1), WOOD_D, 'in', M, bevel=0)
    for sx in (-1, 1):
        for sz in (-1, 1): nail(M @ T(sx * 0.165, -0.011, sz * 0.295) @ INTO, 0.005, 0.003, BRASS)
    part(slab(RI - 0.12, RI - 0.002, 2.225, 2.245, rad(131.6), rad(140.4), 5), WOOD, 'in', bevel=0.005)
    for a in (132.4, 139.6): part(box(0.02, 0.1, 0.08), WOOD_D, 'in', at(rad(a), RI - 0.06, 2.19), bevel=0.005)
    for k, (col, nm) in enumerate((('#9ab8b0', 'NAILS'), ('#c9b27a', None), ('#b98a6a', None))):
        Mj = at(rad(133.2 + 1.9 * k), RI - 0.065, 2.245)
        part(box(0.06, 0.06, 0.07), col, 'in', Mj @ T(0, 0, 0.035), bevel=0.009, seg=3, mat='glassy', gloss=0.6, jit=0.05)
        part(cyl(0.028, 0.014, 10), '#7c7e7a', 'in', Mj @ T(0, 0, 0.076), bevel=0.003, mat='tin', gloss=0.45)
        if nm: label(nm, Mj @ T(0, -0.0315, 0.036), 0.05)
    Mo = at(rad(139), RI - 0.065, 2.245)
    part(lathe([(0, 0), (0.035, 0), (0.035, 0.05), (0.012, 0.075), (0, 0.075)], 12), '#8f918c', 'in', Mo, bevel=0, mat='tin', gloss=0.45)
    part(tube([(0, 0, 0.07), (0, -0.03, 0.11), (0, -0.08, 0.12)], lambda u: 0.006 - 0.003 * u, 6, 3), '#8f918c', 'in', Mo, bevel=0, mat='tin', gloss=0.45)
    # the shelf over the hammock: a clock, a picture in a frame, mugs on hooks under it, a note hung from its edge
    Mk = at(rad(126.3), 2.27, 3.05)
    part(box(0.12, 0.08, 0.13), WOOD_D, 'in', Mk @ T(0, 0, 0.065), bevel=0.008)
    part(lathe([(0, 0.04), (0.06, 0.04), (0.06, -0.04), (0, -0.04)], 14, 0, pi, close=True), WOOD_D, 'in', Mk @ T(0, 0, 0.128) @ Matrix(((0, 1, 0, 0), (0, 0, 1, 0), (1, 0, 0, 0), (0, 0, 0, 1))), bevel=0.004)
    gauge(Mk @ T(0, -0.041, 0.11), 0.048, 'clock')
    for sx in (-1, 1): part(ball(0.012, 8, 6), BRASS, 'in', Mk @ T(sx * 0.045, -0.03, 0.008), bevel=0, gloss=0.6)
    Mf = at(rad(73.5), 2.26, 3.05) @ R(rad(-10), 'X')
    part(box(0.125, 0.014, 0.1), WOOD, 'in', Mf @ T(0, 0, 0.053), bevel=0.004)
    label('photo_a', Mf @ T(0, -0.0085, 0.053), 0.105)
    part(box(0.012, 0.07, 0.008), WOOD_D, 'in', Mf @ T(0, 0.03, 0.03) @ R(rad(40), 'X'), bevel=0)
    for k, col in enumerate(('#b3432a', '#cfc8b2', '#5d6b4a')):
        Mm = at(rad(80.5 + 3.3 * k), 2.16, 2.925)
        mug_on_hook(Mm, col)
    label('note_d', at(rad(118), 2.136, 2.985) @ R(0.05, 'Y'), 0.12)
    part(box(0.012, 0.01, 0.03), WOOD, 'in', at(rad(118), 2.134, 3.016), bevel=0.002)
    # pictures on the wall over the hammock's foot; a note over the ramp's lever
    Mq = W(120.4, 2.7, 0.012) @ R(0.02, 'Y')
    label('poster_a', Mq, 0.27)
    for sx in (-1, 1): part(ball(0.006, 6, 4), RED, 'in', Mq @ T(sx * 0.12, -0.002, 0.165), bevel=0, mat='enamel')
    Mq = W(126.2, 2.82, 0.012) @ R(-0.05, 'Y')
    label('photo_b', Mq, 0.15)
    part(ball(0.006, 6, 4), BRASS, 'in', Mq @ T(0, -0.002, 0.045), bevel=0, gloss=0.6)
    Mq = W(-161.2, 2.775, 0.012) @ R(0.06, 'Y')
    label('note_c', Mq, 0.13)
    part(ball(0.006, 6, 4), RED, 'in', Mq @ T(0, -0.002, 0.022), bevel=0, mat='enamel')
    # the wall mended: a sheet of tin over the boards by the hammock's foot, a board over a split by the table
    part(slab(RI - 0.0135, RI - 0.0105, ZF + 0.42, ZF + 0.68, rad(112.2), rad(117.6), 3), '#8f918c', 'in', bevel=0.001, mat='tin', gloss=0.45, jit=0.03)
    for a in (112.6, 114.9, 117.2):
        for z in (ZF + 0.445, ZF + 0.55, ZF + 0.655): nail(at(rad(a), RI - 0.0135, z) @ INTO, 0.005, 0.003, STEEL)
    Mw = W(-116.2, 2.86, 0.0055) @ R(0.08, 'Y')
    part(box(0.15, 0.009, 0.1), HONEY, 'in', Mw, bevel=0.003, jit=0.1)
    for sx in (-1, 1):
        for sz in (-1, 1): nail(Mw @ T(sx * 0.06, -0.0045, sz * 0.036) @ INTO, 0.005, 0.003)


def on_floor():
    # a rag rug before the chart table
    Mr = at(rad(-99), 1.63, ZF + 0.004)
    cols = ('#8a4a3a', '#c4b490', '#3b6566', '#b9823e', '#c4b490', '#8a4a3a')
    for k, col in enumerate(cols):
        part(box(0.62, 0.07, 0.011), col, 'in', Mr @ T(0, -0.175 + 0.07 * k, 0.0055), bevel=0.004, jit=0.07, mat='knit', rough=0.001, grit=8, sub=2)
    for sx in (-1, 1):
        for k in range(12): part(tube([(sx * 0.31, -0.2 + 0.036 * k, 0.005), (sx * 0.345, -0.2 + 0.036 * k + 0.006 * sin(k * 3.3), 0.003)], 0.003, 4, 1), '#c4b490', 'in', Mr, bevel=0, mat='rope')


def suit_more():
    """What else is on the suit: caps on its shoulders, a pocket on its thigh."""
    M = SUIT_AT
    for sgn in (-1, 1):
        part(ball(0.082, 12, 8, s=(1.05, 0.95, 0.55)), '#5a3a26', 'in', M @ T(sgn * 0.205, 0.0, 1.452) @ R(sgn * -0.5, 'Y'), bevel=0, tag='suit', mat='leather', jit=0.04)
    Mt = M @ T(-0.104, -0.004, 0)
    part(slab(0.0915, 0.102, 0.66, 0.79, pi - 0.5, pi + 0.5, 6), SUIT_D, 'in', Mt, bevel=0.002, tag='suit', mat='cloth', jit=0.04)
    part(slab(0.1, 0.106, 0.74, 0.795, pi - 0.52, pi + 0.52, 6), '#5a3a26', 'in', Mt, bevel=0.002, tag='suit', mat='leather')
    part(ball(0.007, 6, 4), BRASS, 'in', Mt @ T(0, -0.108, 0.755), bevel=0, gloss=0.6, tag='suit')


def small_things():
    # over the door: a flag rolled on two hooks, a striped bar either side of the warning
    for a in (168.5, 179.5):
        part(tube([(0, 0.02, 0), (0, -0.035, -0.012), (0, -0.05, 0.03)], 0.005, 6, 3), BRASS, 'in', at(rad(a), RI - 0.02, 3.158), bevel=0, gloss=0.6)
    a, b = P(rad(167.3), RI - 0.062, 3.168), P(rad(180.7), RI - 0.062, 3.168)
    part(tube([a, b], 0.013, 8, 1), WOOD, 'in', bevel=0, jit=0.05)
    part(tube([lerp(a, b, 0.07), lerp(a, b, 0.93)], 0.036, 12, 1), '#9c3b28', 'in', bevel=0, mat='cloth', jit=0.04, rough=0.004, grit=14)
    part(tube([lerp(a, b, 0.09), lerp(a, b, 0.6)], 0.0375, 12, 1), '#cfc3a2', 'in', bevel=0, mat='cloth', jit=0.04, rough=0.004, grit=14)
    for u in (0.25, 0.75): hoop(lerp(a, b, u), b - a, 0.04, 0.004, 12, ROPE)
    for e in (a, b): part(ball(0.02, 8, 6), BRASS, 'in', T(*e), bevel=0, gloss=0.6)
    for sx in (-1, 1): part(box(0.26, 0.012, 0.04), RED, 'in', at(pi, 2.312, DOOR_TOP + 0.04) @ T(sx * 0.35, 0, 0), bevel=0.002, mat='stripe')
    # the hatch in the floor has a striped edge
    Mf = T(0.95, -0.55, ZF + 0.0125)
    for k in range(4): part(box(0.6, 0.03, 0.005), RED, 'in', Mf @ R(k * pi / 2, 'Z') @ T(0, 0.295, 0), bevel=0.001, mat='stripe')
    # the fuses: a great switch beside them, and the pipes the wires leave by
    Ms = at(pi + rad(13.1), RI - 0.02, 3.2)
    part(box(0.1, 0.03, 0.2), ENAMEL, 'in', Ms @ T(0, -0.01, 0), bevel=0.008, gloss=0.3)
    part(box(0.07, 0.006, 0.16), '#3a4a44', 'in', Ms @ T(0, -0.027, 0), bevel=0.001, mat='enamel')
    for z in (-0.055, 0.055): part(box(0.03, 0.02, 0.02), BRASS, 'in', Ms @ T(0, -0.036, z), bevel=0.003, gloss=0.6)
    part(tube([(0, -0.036, -0.055), (0, -0.09, 0.05)], 0.006, 6, 1), COPPER, 'in', Ms, bevel=0, gloss=0.6)
    part(tube([(0, -0.09, 0.05), (0, -0.115, 0.095)], 0.012, 8, 1), DARK, 'in', Ms, bevel=0, mat='rubber')
    label('MAIN', Ms @ T(0, -0.0265, -0.089), 0.06)
    part(tube([at(pi + rad(7), RI - 0.02, 3.245) @ Vector(v) for v in ((0.17, -0.02, 0.03), (0.2, -0.02, 0.03), (0.215, -0.02, 0.0))], 0.012, 8, 3), STEEL, 'in', bevel=0, gloss=0.5)
    # the water: a tube of glass to show how much is left, a cup on a hook for the drips
    Mw = at(rad(-128.5), RI - 0.17, 2.32)
    part(tube([(0.085, -0.135, -0.17), (0.085, -0.135, 0.17)], 0.008, 8, 1), '#9fc6c8', 'in', Mw, bevel=0, mat='glassy', gloss=0.7, jit=0)
    for z in (-0.17, 0.17):
        part(cyl(0.012, 0.02, 8), BRASS, 'in', Mw @ T(0.085, -0.135, z), bevel=0.002, gloss=0.6)
        part(tube([(0.085, -0.135, z), (0.07, -0.118, z)], 0.006, 6, 1), BRASS, 'in', Mw, bevel=0, gloss=0.6)
    for z in (-0.17, 0.17):
        for k in range(7): part(ball(0.005, 6, 4), STEEL, 'in', Mw @ T(0.159 * sin(-pi + 0.5 * (k - 3)), 0.159 * cos(-pi + 0.5 * (k - 3)), z), bevel=0, gloss=0.6)
    part(lathe([(0, 0), (0.03, 0), (0.034, 0.055), (0.029, 0.055), (0.026, 0.008), (0, 0.008)], 12, close=True), '#8f918c', 'in', Mw @ T(0.0, -0.2, -0.345), bevel=0, mat='tin', gloss=0.45)
    part(tube([(0.0, -0.2, -0.29), (0, -0.2, -0.26), (0.02, -0.2, -0.255)], 0.002, 4, 2), STEEL, 'in', Mw, bevel=0, gloss=0.6)
    # more in the net under the roof: a bag, a folded sheet
    A = lambda u, v: P(rad(84 + 56 * u), 2.25 - 1.05 * v, 3.36 + 0.42 * v - 0.2 * sin(pi * u) * (0.35 + sin(pi * v)))
    c = A(0.82, 0.42)
    part(ball(0.13, 12, 8, s=(1.1, 0.8, 0.6)), '#8a7a5a', 'in', T(c.x, c.y, c.z + 0.09) @ R(0.6, 'Z'), bevel=0, mat='canvas', jit=0.05, rough=0.015, grit=8)
    c = A(0.16, 0.6)
    part(box(0.26, 0.2, 0.06), '#6f8a9a', 'in', T(c.x, c.y, c.z + 0.05) @ R(1.9, 'Z') @ R(0.15, 'X'), bevel=0.02, seg=3, mat='knit', jit=0.05, rough=0.008, grit=8, sub=1)
    # more pinned up: a picture on the ceiling over the table, a note by the hammock's head
    Mp = at(rad(-118), 1.45, zc(1.45) - 0.011) @ R(-BC, 'X') @ R(pi / 2, 'X')
    label('poster_b', Mp, 0.3)
    for sx in (-1, 1):
        for sz in (-1, 1): part(ball(0.007, 6, 4), BRASS, 'in', Mp @ T(sx * 0.14, -0.002, sz * 0.19), bevel=0, gloss=0.6)
    Mq = W(81.4, 2.56, 0.012) @ R(-0.07, 'Y')
    label('note_b', Mq, 0.13)
    part(ball(0.006, 6, 4), RED, 'in', Mq @ T(0, -0.002, 0.022), bevel=0, mat='enamel')


# ============================================================== a third pass: colour, the ceiling, the room's edges
MUSTARD, ORANGE, REDB, CREAMW, TEALE, SAGEE = '#c9a23a', '#d8782c', '#b3432a', '#e0d6ba', '#3f7272', '#6f8a78'
DOWN = Vector((0, 0, -1))


def s_hook(top, L=0.05, turn=0.0, over=0.0):
    """An S of wire hung over something `over` thick whose middle is at `top`: gives back the place a thing hangs from it."""
    top = Vector(top); o = over
    pts = [(o + 0.004, -0.008), (o + 0.0035, 0.006), (0, o + 0.004), (-o - 0.0035, 0.004), (-o - 0.002, -o - 0.01), (-0.002, -L * 0.6 - o), (0.006, -L - o - 0.006), (0, -L - o - 0.014), (-0.007, -L - o - 0.004)]
    part(tube([(x, 0, z) for x, z in pts], 0.0024, 5, 3), STEEL, 'in', T(*top) @ R(turn, 'Z'), bevel=0, gloss=0.6)
    return top + Vector((0, 0, -L - o - 0.0115))


def by_handle(h, turn, y, z, a=1.36):
    """The frame of a jug or a mug hung at `h` by its handle, whose top is at (0, y, z) in the thing's own frame."""
    return T(*h) @ R(turn, 'Z') @ T(0, -(y * cos(a) - z * sin(a)), -(y * sin(a) + z * cos(a))) @ R(a, 'X')


def net_bag(c, rx, rz, top, n=6, t=0.0018, col=None):
    """A bag of netting round something: cords from under it, up its sides, gathered at `top`; two cords round it."""
    c = Vector(c); top = Vector(top)
    for k in range(n):
        f = k * 2 * pi / n
        pts = [c + Vector((rx * cos(a) * cos(f), rx * cos(a) * sin(f), rz * sin(a))) for a in (-1.45, -1.0, -0.5, 0.0, 0.5, 0.95)] + [top]
        part(tube(pts, t, 4, 3), col or ROPE, 'in', bevel=0)
    for a in (-0.5, 0.35):
        part(tube([c + Vector((rx * cos(a) * cos(f), rx * cos(a) * sin(f), rz * sin(a))) for f in [i * 2 * pi / 12 for i in range(12)]], t, 4, 1, cyclic=True), col or ROPE, 'in', bevel=0)


def centre():
    """
    Over the middle of the room: a bell of enamel over the lantern, to keep its smoke off the boards; a cord to trim
    it by; and round it a wooden hoop on three ropes, where whatever has no other place is hung.
    """
    part(lathe([(0.012, 3.771), (0.06, 3.766), (0.158, 3.729), (0.216, 3.686), (0.224, 3.688), (0.218, 3.7), (0.16, 3.744), (0.06, 3.781), (0.012, 3.786)], 28, close=True), TEALE, 'in', bevel=0, mat='enamel', gloss=0.35, jit=0.03)
    part(lathe([(0.012, 3.7665), (0.06, 3.7615), (0.156, 3.7245), (0.21, 3.6845), (0.214, 3.6865), (0.158, 3.7285), (0.06, 3.7655), (0.012, 3.7705)], 28, close=True), CREAMW, 'in', bevel=0, mat='enamel', gloss=0.35, jit=0.03)
    part(tube([(0.2225 * cos(i * pi / 16), 0.2225 * sin(i * pi / 16), 3.6865) for i in range(32)], 0.0035, 5, 1, cyclic=True), BRASS, 'in', bevel=0, gloss=0.6)
    part(lathe([(0.0085, 3.786), (0.02, 3.786), (0.024, 3.795), (0.018, 3.812), (0.0085, 3.816)], 12, close=True), BRASS, 'in', bevel=0, gloss=0.6)
    for k in range(3):
        a = k * 2 * pi / 3 + 0.5
        part(ball(0.005, 6, 4), BRASS, 'in', T(0.115 * cos(a), 0.115 * sin(a), 3.7625), bevel=0, gloss=0.6)
    # (the iron ring the rafters meet at: bolts under it, and line wound round it where things have been hung)
    for k in range(12): part(ball(0.011, 7, 5, s=(1, 1, 0.6)), BRASS, 'in', T(0.35 * cos(k * pi / 6 + 0.26), 0.35 * sin(k * pi / 6 + 0.26), 4.099), bevel=0, gloss=0.6)
    for k in range(6):
        for j in range(3 if k % 2 else 4):
            f = k * pi / 3 + 0.9 + (j - 1.5) * 0.034
            sq = lambda a: 0.0745 * (abs(cos(a)) ** 6 + abs(sin(a)) ** 6) ** (-1 / 6)
            part(tube([((0.35 + sq(a) * cos(a)) * cos(f), (0.35 + sq(a) * cos(a)) * sin(f), 4.17 + sq(a) * sin(a)) for a in [i * pi / 10 for i in range(20)]], 0.0055, 5, 1, cyclic=True), ROPE, 'in', bevel=0, jit=0.06)
    # (the cord, with an acorn of wood on its end)
    rod((0, 0, 3.346), (0, 0, 3.2), 0.0016, ROPE, 4)
    part(lathe([(0, 0), (0.008, 0.004), (0.013, 0.02), (0.01, 0.036), (0.004, 0.044), (0, 0.044)], 10), WOOD, 'in', T(0, 0, 3.158), bevel=0, jit=0.05)
    # the hoop, its straps, its ropes
    Rh, zh = 0.5, 3.44
    part(tube([(Rh * cos(i * pi / 20), Rh * sin(i * pi / 20), zh) for i in range(40)], 0.014, 8, 1, cyclic=True), WOOD, 'in', bevel=0, jit=0.04, rough=0.003, grit=5)
    for k in range(4):
        f = k * pi / 2 + 0.4
        hoop((Rh * cos(f), Rh * sin(f), zh), (-sin(f), cos(f), 0), 0.0162, 0.003, 10, BRASS, gloss=0.6)
    for k in range(3):
        f = pi / 2 + k * 2 * pi / 3
        a, b = Vector((Rh * cos(f), Rh * sin(f), zh + 0.012)), Vector((0.35 * cos(f), 0.35 * sin(f), 4.1))
        rod(a, b, 0.0048, ROPE, 6, jit=0.05)
        hoop(a - Vector((0, 0, 0.012)), (-sin(f), cos(f), 0), 0.019, 0.0045, 10, ROPE, jit=0.05)
        for u in (0.05, 0.94): hoop(lerp(a, b, u), b - a, 0.0062, 0.002, 8, '#7a2f22', mat='cloth')
        part(ball(0.012, 8, 6), BRASS, 'in', T(*b), bevel=0, gloss=0.6)
    hang = lambda deg, L=0.045: s_hook((Rh * cos(rad(deg)), Rh * sin(rad(deg)), zh), L, rad(deg), 0.014)
    # a jug of enamel, by its handle
    h = hang(20, 0.05)
    Mj = by_handle(h, rad(20) + pi / 2, 0.103, 0.115)
    part(lathe([(0, 0), (0.05, 0), (0.066, 0.03), (0.07, 0.09), (0.058, 0.15), (0.046, 0.185), (0.052, 0.2), (0.046, 0.2), (0.041, 0.186), (0.052, 0.15), (0.063, 0.09), (0.06, 0.035), (0.046, 0.008), (0, 0.008)], 16, close=True), TEALE, 'in', Mj, bevel=0, mat='enamel', gloss=0.35, jit=0.03)
    part(slab(0.0465, 0.0535, 0.193, 0.2015, 0, 2 * pi, 16), CREAMW, 'in', Mj, bevel=0.001, mat='enamel', gloss=0.35)
    part(tube([(0, 0.056, 0.152), (0, 0.098, 0.142), (0, 0.105, 0.092), (0, 0.068, 0.05)], 0.006, 6, 4), TEALE, 'in', Mj, bevel=0, mat='enamel', gloss=0.35)
    # red peppers on a string
    h = hang(65, 0.04)
    rod(h, h + DOWN * 0.25, 0.002, ROPE, 4)
    for j in range(11):
        a = j * 2.4; d = Vector((cos(a), sin(a), 0)); p = h + Vector((0, 0, -0.03 - 0.02 * j))
        part(tube([p, p + d * 0.022 + DOWN * 0.012, p + d * 0.04 + DOWN * 0.04, p + d * 0.038 + DOWN * 0.07], lambda u: 0.0075 * (1 - 0.8 * u) + 0.001, 6, 3), (REDB, '#a8321f', '#c4522a')[j % 3], 'in', bevel=0, mat='glaze', gloss=0.3, jit=0.05)
        part(tube([p, p + d * 0.004 + UP * 0.008], 0.0026, 4, 1), '#5f7a46', 'in', bevel=0, mat='paint')
    # oranges in a net
    h = hang(110, 0.05)
    c = h + DOWN * 0.15
    for k, v in enumerate(((0.036, 0, -0.03), (-0.03, 0.026, -0.036), (-0.012, -0.036, -0.03), (0.0, 0.0, 0.036), (0.008, 0.01, -0.092))):
        part(ball(0.04, 10, 8), (ORANGE, '#e08a34', '#cf6a24')[k % 3], 'in', T(*(c + Vector(v))), bevel=0, mat='glaze', gloss=0.2, jit=0.05, rough=0.002, grit=30)
    net_bag(c + DOWN * 0.025, 0.084, 0.112, h, 6)
    # candles, tied in a bundle by their wicks
    h = hang(155, 0.04)
    cc = h + DOWN * 0.165
    for k in range(7):
        o = Vector((0.0225 * cos(k * pi / 3), 0.0225 * sin(k * pi / 3), random.uniform(-0.012, 0.012))) if k else Vector((0, 0, 0.006))
        part(cyl(0.0105, 0.19, 8), ('#e4d8b8', '#d8c9a0')[k % 2], 'in', T(*(cc + o)), bevel=0.002, mat='glaze', gloss=0.15, jit=0.03)
        part(tube([cc + o + UP * 0.095, cc + o * 0.4 + UP * 0.125, h], 0.0012, 4, 2), '#b9a67c', 'in', bevel=0, mat='rope')
    for z in (-0.05, 0.055): hoop(cc + UP * z, UP, 0.0345, 0.0025, 12, ROPE)
    # a pair of mittens on their string
    h = hang(200, 0.04)
    for sgn, L in ((-1, 0.1), (1, 0.15)):
        p = h + Vector((sgn * 0.035, 0, -L))
        rod(h, p + UP * 0.05, 0.0018, '#cfc3a2', 4, mat='rope')
        Mm = T(*p) @ R(rad(200) + sgn * 0.4, 'Z') @ R(sgn * 0.12, 'Y')
        part(ball(0.05, 10, 8, s=(0.78, 0.36, 1.25)), REDB, 'in', Mm @ T(0, 0, -0.03), bevel=0, mat='knit', jit=0.04, rough=0.004, grit=14)
        part(ball(0.022, 8, 6, s=(0.8, 0.5, 1.3)), REDB, 'in', Mm @ T(sgn * 0.04, 0, -0.035) @ R(sgn * -0.5, 'Y'), bevel=0, mat='knit', jit=0.04)
        part(cyl(0.031, 0.04, 10), CREAMW, 'in', Mm @ T(0, 0, 0.035) @ S(1, 0.5, 1), bevel=0.004, mat='knit', jit=0.04)
    # a bell, to be rung for supper
    h = hang(245, 0.035)
    part(tube([h, h + DOWN * 0.03], 0.004, 5, 1), '#5a3a26', 'in', bevel=0, mat='leather')
    Mb = T(h.x, h.y, h.z - 0.03) @ R(pi, 'X')
    part(lathe([(0, 0.008), (0.014, 0.012), (0.02, 0.042), (0.03, 0.066), (0.04, 0.078), (0.046, 0.086), (0.05, 0.086), (0.046, 0.078), (0.034, 0.064), (0.024, 0.04), (0.018, 0.01), (0.012, 0), (0, 0)], 16, close=True), BRASS, 'in', Mb, bevel=0, gloss=0.7, jit=0.02)
    rod(h + DOWN * 0.04, h + DOWN * 0.115, 0.0022, STEEL, 4, gloss=0.6)
    part(ball(0.011, 8, 6), IRON, 'in', T(h.x, h.y, h.z - 0.115), bevel=0, gloss=0.4)
    rod(h + DOWN * 0.125, h + DOWN * 0.25, 0.0016, ROPE, 4)
    part(ball(0.01, 8, 6, s=(1, 1, 1.3)), REDB, 'in', T(h.x, h.y, h.z - 0.26), bevel=0, mat='enamel', gloss=0.3)
    # garlic, plaited
    h = hang(290, 0.04)
    rod(h, h + DOWN * 0.24, 0.006, '#cdbf98', 5, mat='rope', jit=0.05)
    for j in range(8):
        a = j * 2.2 + 0.4; p = h + Vector((0.024 * cos(a), 0.024 * sin(a), -0.045 - 0.026 * j))
        part(ball(0.027, 9, 7, s=(1, 1, 0.86)), ('#e6dcc4', '#d9cdb0', '#e9e0cc')[j % 3], 'in', T(*p) @ R(a, 'Z') @ R(0.5, 'Y'), bevel=0, mat='paper', jit=0.04, rough=0.003, grit=40)
        part(tube([p + UP * 0.02, p + Vector((-0.01 * cos(a), -0.01 * sin(a), 0.04))], 0.003, 4, 1), '#cdbf98', 'in', bevel=0, mat='rope')
    # a mug
    h = hang(335, 0.04)
    Mg = by_handle(h, rad(335) - pi / 2, 0.066, 0.045)
    part(lathe([(0, 0), (0.036, 0), (0.04, 0.08), (0.034, 0.08), (0.03, 0.01), (0, 0.01)], 12, close=True), CREAMW, 'in', Mg, bevel=0, mat='enamel', gloss=0.3, jit=0.04)
    part(slab(0.0345, 0.0405, 0.074, 0.081, 0, 2 * pi, 12), REDB, 'in', Mg, bevel=0.001, mat='enamel', gloss=0.3)
    part(tube([(0, 0.038, 0.015), (0, 0.065, 0.03), (0, 0.065, 0.055), (0, 0.039, 0.068)], 0.005, 5, 3), CREAMW, 'in', Mg, bevel=0, mat='enamel')


def bunting():
    """Small flags on a line, looped from rafter to rafter round the middle of the room (not over the pilot)."""
    cols = (REDB, CREAMW, TEALE, MUSTARD, SAGEE, CREAMW)
    r0 = 0.95
    pin = lambda th: P(rad(th), r0, zc(r0) - 0.127)
    pins = (75, 105, 135, 165, 195, 225, 255, 285); k = 0
    for t0, t1 in zip(pins, pins[1:]):
        A, B = pin(t0), pin(t1)
        line = lambda u, A=A, B=B: lerp(A, B, u) + Vector((0, 0, -0.075 * sin(pi * u)))
        part(tube([line(i / 10) for i in range(11)], 0.0022, 4, 1), ROPE, 'in', bevel=0)
        for j in range(4):
            u = (j + 0.5) / 4
            c = line(u); t = (line(u + 0.03) - line(u - 0.03)).normalized(); nn = Vector((-t.y, t.x, 0)).normalized()
            w, L = random.uniform(0.094, 0.106), random.uniform(0.122, 0.142); ph = random.uniform(0, 6)
            dn = (DOWN + t * random.uniform(-0.12, 0.12)).normalized()
            f = lambda a, b, c=c, t=t, nn=nn, dn=dn, ph=ph, w=w, L=L: c + t * (a - 0.5) * w * (1 - 0.94 * b) + dn * (0.002 + b * L) + nn * 0.009 * sin(b * 3 + ph) * (0.3 + b)
            part(sheet(2, 4, f, 0.0016), cols[k % len(cols)], 'in', bevel=0, mat='cloth', jit=0.06, sharp=80); k += 1
    for th in pins:
        p = pin(th)
        part(tube([p + UP * 0.006, p + DOWN * 0.004, p + Vector((0.004, 0, -0.008))], 0.002, 4, 2), BRASS, 'in', bevel=0, gloss=0.6)


def kite():
    """A kite, slung flat under the rafters to the left of the window, its tail let hang."""
    rc = 1.42
    K = at(rad(-60), rc, zc(rc) - 0.152) @ R(-BC, 'X')        # its +Y down the slope, its -Z into the room
    Tt, Bb, Ll, Rr, Cc = Vector((0, -0.47, 0)), Vector((0, 0.47, 0)), Vector((-0.36, -0.14, 0)), Vector((0.36, -0.14, 0)), Vector((0, -0.14, 0))
    for (a, b), col in (((Tt, Ll), REDB), ((Tt, Rr), CREAMW), ((Bb, Ll), CREAMW), ((Bb, Rr), REDB)):
        def f(u, v, a=a, b=b):
            s, t = u * (1 - 0.985 * v), 0.985 * v
            return Cc + (a - Cc) * s + (b - Cc) * t + Vector((0, 0, 0.55 * s * t * (1 - s - t) + 0.0015))
        part(sheet(5, 5, f, 0.0014), col, 'in', K, bevel=0, mat='cloth', jit=0.05, sharp=80)
    part(tube([Tt, Bb], 0.005, 6, 1), '#b89a6a', 'in', K @ T(0, 0, -0.005), bevel=0, mat='wood', jit=0.05)
    part(tube([Ll, Vector((0, -0.14, -0.012)), Rr], 0.0042, 6, 5), '#b89a6a', 'in', K @ T(0, 0, -0.0045), bevel=0, mat='wood', jit=0.05)
    part(tube([Tt, Ll, Bb, Rr], 0.0016, 4, 1, cyclic=True), ROPE, 'in', K, bevel=0)
    hoop(K @ (Cc + Vector((0, 0, -0.006))), K.to_3x3() @ Vector((1, 1, 0)), 0.009, 0.0016, 8, ROPE)
    # (a patch on it, of another cloth)
    part(sheet(2, 2, lambda u, v: Vector((0.07 + 0.09 * u, 0.02 + 0.08 * v + 0.03 * u, -0.0012)), 0.001), TEALE, 'in', K, bevel=0, mat='cloth', jit=0.05, sharp=80)
    # what holds it: a cord at each corner, to a nail
    for c in (Ll, Rr):
        w = K @ c
        rod(w, w + UP * 0.024, 0.0016, ROPE, 4)
        hoop(w + DOWN * 0.003, K.to_3x3() @ Vector((1, 0, 0)), 0.008, 0.0016, 8, ROPE)
    for c in (Tt, Bb):
        w = K @ c; top = K @ (c + Vector((0, 0, 0.137)))
        rod(w, top, 0.0016, ROPE, 4)
        part(ball(0.005, 6, 4), BRASS, 'in', T(*top), bevel=0, gloss=0.6)
    # its tail, with bows of rag along it
    b0 = K @ Bb
    tail = [b0, b0 + Vector((0.01, 0.0, -0.1)), b0 + Vector((-0.016, 0.012, -0.21)), b0 + Vector((0.014, -0.01, -0.32)), b0 + Vector((0.0, 0.004, -0.43))]
    part(tube(tail, 0.0016, 4, 4), ROPE, 'in', bevel=0)
    for k, p in enumerate(path(tail, 4)[3::3][:5]):
        a = k * 1.9 + 0.5; t = Vector((cos(a), sin(a), 0))
        f = lambda u, v, p=p, t=t: p + t * (u - 0.5) * 0.078 + Vector((0, 0, (v - 0.5) * 0.036 * (abs(u - 0.5) * 1.8 + 0.1) + 0.006 * (u - 0.5)))
        part(sheet(2, 1, f, 0.0014), (TEALE, MUSTARD, REDB, CREAMW, TEALE)[k], 'in', bevel=0, mat='cloth', jit=0.06, sharp=80)
    # (and its line, wound on a stick, tucked behind a rafter)
    wd = P(rad(-45.6), 1.62, zc(1.62) - 0.175)
    Mw = aim(wd, wd + Vector((sin(rad(-45)), cos(rad(-45)), -0.42)))
    part(box(0.02, 0.012, 0.16), WOOD, 'in', Mw, bevel=0.003, jit=0.05)
    for z in (-0.07, 0.07): part(box(0.07, 0.012, 0.016), WOOD, 'in', Mw @ T(0, 0, z), bevel=0.003, jit=0.05)
    part(box(0.05, 0.03, 0.11), '#cfc3a2', 'in', Mw, bevel=0.012, seg=2, mat='rope', jit=0.04)
    hoop(wd + UP * 0.06, (sin(rad(-45)), cos(rad(-45)), -0.42), 0.05, 0.002, 10, ROPE)


def floats():
    """Glass floats off a fishing net, in their own netting, hung in a bunch from a rafter to the right of the window."""
    p0 = P(rad(75), 1.45, zc(1.45) - 0.126)
    knot = p0 + DOWN * 0.2
    rod(p0 + UP * 0.004, knot, 0.004, ROPE, 5, jit=0.05)
    part(tube([p0 + Vector((0.012, 0, 0.004)), p0 + Vector((0, 0, -0.014)), p0 + Vector((-0.012, 0, 0.004))], 0.003, 5, 3), IRON, 'in', bevel=0, gloss=0.4)
    part(ball(0.011, 8, 6), ROPE, 'in', T(*knot), bevel=0, jit=0.05)
    for (dx, dy, z), r, col in (((0.06, 0.0, 3.27), 0.1, '#3f8a80'), ((-0.07, 0.05, 3.14), 0.085, '#5a9a6a'), ((-0.02, -0.13, 3.37), 0.075, '#c99a3a')):
        c = Vector((p0.x + dx, p0.y + dy, z))
        part(ball(r, 16, 12), col, 'in', T(*c), bevel=0, mat='glassy', gloss=0.7, jit=0.03)
        part(ball(0.016, 8, 5, s=(1, 1, 0.5)), col, 'in', T(c.x, c.y, c.z - r + 0.002), bevel=0, mat='glassy', gloss=0.7, jit=0.03)
        net_bag(c, r + 0.003, r + 0.003, knot, 6, 0.0022)


def fruit():
    """Three baskets of wire one under another, hung from a rafter by the stove: lemons, oranges, apples."""
    p0 = P(rad(-165), 1.3, zc(1.3) - 0.126)
    part(tube([p0 + Vector((0.012, 0, 0.004)), p0 + Vector((0, 0, -0.014)), p0 + Vector((-0.012, 0, 0.004))], 0.003, 5, 3), IRON, 'in', bevel=0, gloss=0.4)
    tiers = ((3.42, 0.085, 3, '#d9b83a', 0.028), (3.265, 0.115, 5, ORANGE, 0.036), (3.105, 0.14, 6, REDB, 0.034))
    prev = p0 + DOWN * 0.014
    for z, r, n, col, fr in tiers:
        c = Vector((p0.x, p0.y, z))
        for k in range(3):
            a = k * 2 * pi / 3 + z * 7
            rod(prev, c + Vector((r * cos(a), r * sin(a), 0)), 0.0016, STEEL, 4, gloss=0.6)
        part(tube([c + Vector((r * cos(i * pi / 10), r * sin(i * pi / 10), 0)) for i in range(20)], 0.0026, 5, 1, cyclic=True), STEEL, 'in', bevel=0, gloss=0.6)
        part(tube([c + Vector((r * 0.45 * cos(i * pi / 6), r * 0.45 * sin(i * pi / 6), -0.05)) for i in range(12)], 0.002, 4, 1, cyclic=True), STEEL, 'in', bevel=0, gloss=0.6)
        for k in range(8):
            a = k * pi / 4
            part(tube([c + Vector((r * cos(a), r * sin(a), 0)), c + Vector((r * 0.82 * cos(a), r * 0.82 * sin(a), -0.034)), c + Vector((r * 0.45 * cos(a), r * 0.45 * sin(a), -0.05))], 0.0016, 4, 3), STEEL, 'in', bevel=0, gloss=0.6)
        for k in range(n):
            a = k * 2 * pi / n + z * 3; rr = r * 0.56 if n > 3 else r * 0.42
            q = c + Vector((rr * cos(a), rr * sin(a), -0.05 + fr * 0.86)) if k < 5 else c + Vector((0, 0, -0.05 + fr * 0.9))
            fc = col if (k + int(z * 10)) % 3 else {'#d9b83a': '#c9b040', ORANGE: '#e08a34', REDB: '#7f9a4a'}[col]
            part(ball(fr, 10, 8, s=(1.25, 1, 1) if n == 3 else (1, 1, 0.94)), fc, 'in', T(*q) @ R(a, 'Z'), bevel=0, mat='glaze', gloss=0.25, jit=0.05, rough=0.002, grit=30)
            if n != 3: part(tube([q + UP * fr * 0.8, q + Vector((0.004, 0.002, fr + 0.012))], 0.0018, 4, 1), '#5a4a2a', 'in', bevel=0, mat='paint')
        prev = c + Vector((0, 0, -0.05))


def bottle(M, r, h, col, stop=None, mat='glassy'):
    """A small bottle standing at a place, with its stopper."""
    part(lathe([(0, 0), (r, 0), (r, h * 0.62), (r * 0.42, h * 0.8), (r * 0.42, h), (0, h)], 10), col, 'in', M, bevel=0, mat=mat, gloss=0.6 if mat == 'glassy' else 0.3, jit=0.04)
    part(cyl(r * 0.5, h * 0.12, 8), stop or '#b89a6a', 'in', M @ T(0, 0, h * 1.04), bevel=0.001, mat='wood' if stop is None else 'enamel', jit=0.04)


def locker():
    """
    By the padding to the right of the pilot: a small locker of white enamel on four feet, its door standing open:
    what mends people is kept in it. A flask and a folded cloth on top.
    """
    M = at(rad(66.0), 2.235, ZF)                # its -Y looks into the room
    w, d, h, z0, t = 0.26, 0.2, 0.58, 0.045, 0.012
    for sx in (-1, 1):
        for sy in (-1, 1): part(cyl(0.013, z0, 8, r2=0.009), DARK, 'in', M @ T(sx * (w / 2 - 0.03), sy * (d / 2 - 0.03), z0 / 2), bevel=0, mat='rubber')
        part(box(t, d, h), ENAMEL, 'in', M @ T(sx * (w / 2 - t / 2), 0, z0 + h / 2), bevel=0.004, gloss=0.28, jit=0.02)
    for z in (z0 + t / 2, z0 + h - t / 2): part(box(w - 2 * t, d, t), ENAMEL, 'in', M @ T(0, 0, z), bevel=0.004, gloss=0.28, jit=0.02)
    part(box(w - 2 * t, t, h - 2 * t), ENAMEL, 'in', M @ T(0, d / 2 - t / 2, z0 + h / 2), bevel=0.002, gloss=0.28, jit=0.02)
    zs = (z0 + 0.2, z0 + 0.39)
    for z in zs: part(box(w - 2 * t - 0.002, d - t - 0.022, 0.008), '#bdb59c', 'in', M @ T(0, 0.006, z), bevel=0.002, mat='enamel', gloss=0.28)
    # what is in it
    part(box(0.2, 0.14, 0.085), SAGEE, 'in', M @ T(0, 0.0, z0 + t + 0.043), bevel=0.02, seg=3, mat='knit', jit=0.05, rough=0.006, grit=9, sub=1)
    part(box(0.19, 0.13, 0.03), '#c9c0a8', 'in', M @ T(0.004, -0.004, z0 + t + 0.1), bevel=0.012, seg=2, mat='cloth', jit=0.05, rough=0.004, grit=10, sub=1)
    s1 = zs[0] + 0.004
    part(box(0.095, 0.03, 0.135), REDB, 'in', M @ T(-0.055, 0.045, s1 + 0.0675) @ R(-0.12, 'X'), bevel=0.013, seg=3, mat='rubber', jit=0.03)
    part(cyl(0.012, 0.03, 8), DARK, 'in', M @ T(-0.055, 0.052, s1 + 0.145) @ R(-0.12, 'X'), bevel=0.002, mat='rubber')
    part(box(0.075, 0.06, 0.05), MUSTARD, 'in', M @ T(0.06, 0.02, s1 + 0.025) @ R(0.2, 'Z'), bevel=0.006, seg=2, mat='tin', gloss=0.4, jit=0.04)
    for k in range(2):
        Mr = M @ T(0.01 + 0.058 * k, -0.045 - 0.008 * k, s1 + 0.024) @ R(0.3 - 0.9 * k, 'Z') @ R(pi / 2, 'X')
        part(cyl(0.024, 0.05, 12), '#e6dec8', 'in', Mr, bevel=0.004, mat='knit', jit=0.03)
        part(cyl(0.007, 0.052, 6), '#8a7a5a', 'in', Mr, bevel=0, mat='paper')
    s2 = zs[1] + 0.004
    bottle(M @ T(-0.078, 0.03, s2), 0.022, 0.11, '#6a4426')
    bottle(M @ T(-0.022, 0.045, s2), 0.026, 0.13, '#3f7a78')
    bottle(M @ T(0.035, 0.03, s2), 0.02, 0.095, '#7a4a2a')
    part(lathe([(0, 0), (0.03, 0), (0.032, 0.07), (0, 0.07)], 12), CREAMW, 'in', M @ T(0.085, 0.028, s2), bevel=0.003, mat='enamel', gloss=0.3, jit=0.03)
    part(cyl(0.033, 0.014, 12), REDB, 'in', M @ T(0.085, 0.028, s2 + 0.077), bevel=0.003, mat='enamel', gloss=0.3)
    part(box(0.05, 0.035, 0.022), '#cfc3a2', 'in', M @ T(-0.04, -0.045, s2 + 0.011) @ R(0.4, 'Z'), bevel=0.003, mat='paper', jit=0.04)
    # its door, open: the mark on its face; a band inside it with small bottles and a pair of scissors behind
    D = M @ T(w / 2, -d / 2, z0) @ R(rad(80), 'Z')
    part(box(w - 0.004, t, h - 0.004), ENAMEL, 'in', D @ T(-w / 2, -t / 2 - 0.0015, h / 2), bevel=0.004, gloss=0.28, jit=0.02)
    label('r3_cross', D @ T(-w / 2, -t - 0.003, h * 0.6), 0.125)
    part(box(w - 0.03, 0.0015, 0.011), REDB, 'in', D @ T(-w / 2, -t - 0.00225, h - 0.05), bevel=0, mat='enamel', gloss=0.3)
    part(box(0.018, 0.012, 0.05), BRASS, 'in', D @ T(-w + 0.026, -t - 0.006, h * 0.5), bevel=0.003, gloss=0.6)
    part(tube([(-w + 0.026, -t - 0.01, h * 0.5), (-w + 0.004, -t - 0.016, h * 0.5)], 0.004, 5, 1), BRASS, 'in', D, bevel=0, gloss=0.6)
    for z in (0.09, h - 0.09): part(cyl(0.006, 0.05, 8), BRASS, 'in', D @ T(0.003, -0.005, z), bevel=0.001, gloss=0.6)
    for z, off in ((0.215, 0.0255), (0.4, 0.014)):
        part(box(0.2, 0.004, 0.022), '#5a3a26', 'in', D @ T(-w / 2, off, z), bevel=0.001, mat='leather')
        for sx in (-1, 1):
            part(box(0.004, off, 0.022), '#5a3a26', 'in', D @ T(-w / 2 + sx * 0.098, off / 2 + 0.001, z), bevel=0.001, mat='leather')
            part(ball(0.004, 6, 4), BRASS, 'in', D @ T(-w / 2 + sx * 0.098, off + 0.002, z), bevel=0, gloss=0.6)
    part(box(0.2, 0.03, 0.006), ENAMEL, 'in', D @ T(-w / 2, 0.0135, 0.172), bevel=0.002, gloss=0.28)
    for k, col in enumerate(('#6a4426', '#3f7a78', '#cfc8b2')):
        part(cyl(0.011, 0.075, 8), col, 'in', D @ T(-w / 2 - 0.06 + 0.045 * k, 0.0125, 0.215), bevel=0.002, mat='glassy' if k < 2 else 'enamel', gloss=0.6, jit=0.04)
        part(cyl(0.006, 0.012, 6), '#b89a6a', 'in', D @ T(-w / 2 - 0.06 + 0.045 * k, 0.0125, 0.258), bevel=0, mat='wood')
    for sgn in (-1, 1):
        part(box(0.007, 0.002, 0.1), STEEL, 'in', D @ T(-w / 2 + 0.05, 0.0105, 0.42) @ R(sgn * 0.09, 'Y') @ T(0, 0, 0.03), bevel=0, gloss=0.6)
        hoop(D @ Vector((-w / 2 + 0.05 + sgn * 0.014, 0.011, 0.365)), D.to_3x3() @ Vector((0, 1, 0)), 0.012, 0.0028, 10, STEEL, gloss=0.6)
    # on top of it
    zt = z0 + h
    Mf = M @ T(-0.06, 0.02, zt)
    part(lathe([(0, 0), (0.04, 0), (0.042, 0.012), (0.042, 0.19), (0.03, 0.215), (0, 0.215)], 14), REDB, 'in', Mf, bevel=0, mat='enamel', gloss=0.35, jit=0.03)
    part(lathe([(0, 0.212), (0.034, 0.212), (0.036, 0.27), (0, 0.272)], 14), CREAMW, 'in', Mf, bevel=0.003, mat='enamel', gloss=0.35)
    for z in (0.03, 0.17): part(slab(0.0415, 0.0445, z, z + 0.012, 0, 2 * pi, 14), STEEL, 'in', Mf, bevel=0.001, gloss=0.6)
    part(box(0.13, 0.11, 0.045), TEALE, 'in', M @ T(0.055, 0.0, zt + 0.0225) @ R(0.25, 'Z'), bevel=0.014, seg=3, mat='knit', jit=0.05, rough=0.005, grit=9, sub=1)
    part(box(0.125, 0.105, 0.012), CREAMW, 'in', M @ T(0.055, 0.0, zt + 0.049) @ R(0.32, 'Z'), bevel=0.005, seg=2, mat='knit', jit=0.05, rough=0.003, grit=9, sub=1)


def by_the_door():
    """On the stove's side of the door, under the ramp's lever: a bucket of sand, hung up against a fire."""
    Mb = at(rad(-161.2), 2.24, 0)
    zt = 1.745
    part(lathe([(0, zt - 0.262), (0.09, zt - 0.262), (0.094, zt - 0.25), (0.122, zt - 0.006), (0.127, zt), (0.122, zt + 0.004), (0.117, zt - 0.004), (0.089, zt - 0.25), (0, zt - 0.25)], 18, close=True), REDB, 'in', Mb, bevel=0, mat='enamel', gloss=0.35, jit=0.03)
    part(cyl(0.117, 0.006, 18), '#c9b68a', 'in', Mb @ T(0, 0, zt - 0.03), bevel=0, mat='paint', jit=0.04, rough=0.004, grit=30)
    for z in (zt - 0.19, zt - 0.06): part(slab(0.094 + (z - zt + 0.25) * 0.1148 - 0.001, 0.094 + (z - zt + 0.25) * 0.1148 + 0.0035, z - 0.006, z + 0.006, 0, 2 * pi, 18), DARK, 'in', Mb, bevel=0.001, gloss=0.4)
    label('FIRE', Mb @ T(0, -0.1105, zt - 0.125), 0.062)
    # (its bail, over a hook in the rail)
    part(tube([(0.122 * cos(a) * 1.0, 0.0, zt - 0.004 + 0.15 * sin(a)) for a in [i * pi / 12 for i in range(13)]], 0.0035, 5, 1), STEEL, 'in', Mb, bevel=0, gloss=0.6)
    for sx in (-1, 1): part(box(0.012, 0.02, 0.03), DARK, 'in', Mb @ T(sx * 0.124, 0, zt - 0.006), bevel=0.003, gloss=0.4)
    part(tube([(0, 0.13, zt + 0.16), (0, 0.06, zt + 0.15), (0, 0.0, zt + 0.136), (0, -0.016, zt + 0.142), (0, -0.022, zt + 0.158)], 0.006, 6, 3), IRON, 'in', Mb, bevel=0, gloss=0.4)
    part(box(0.03, 0.008, 0.06), IRON, 'in', Mb @ T(0, 0.127, zt + 0.15), bevel=0.002, gloss=0.4)
    for z in (0.13, 0.17): nail(Mb @ T(0, 0.123, zt + z) @ INTO, 0.004, 0.003, STEEL)


def flag_stand():
    """Between the chart table and the pilot's desk: a stand of enamel with what is long and thin in it."""
    M = at(rad(-65.5), 2.2, ZF)
    part(lathe([(0, 0), (0.1, 0), (0.105, 0.02), (0.095, 0.42), (0.105, 0.44), (0.098, 0.44), (0.088, 0.42), (0.097, 0.03), (0, 0.03)], 18, close=True), TEALE, 'in', M, bevel=0, mat='enamel', gloss=0.35, jit=0.03)
    part(slab(0.0965, 0.0995, 0.3, 0.36, 0, 2 * pi, 18), CREAMW, 'in', M, bevel=0.001, mat='enamel', gloss=0.35)
    for z in (0.022, 0.438): part(slab(0.094, 0.108, z - 0.006, z + 0.006, 0, 2 * pi, 18), BRASS, 'in', M, bevel=0.002, gloss=0.6)
    def pole(a, lean, L, r=0.009, col=WOOD):
        b = Vector((0.05 * cos(a), 0.05 * sin(a), 0.035)); top = b + Vector((lean[0], lean[1], L))
        part(tube([M @ b, M @ top], r, 7, 1), col, 'in', bevel=0, jit=0.05, mat='wood')
        return M @ b, M @ top
    # two flags rolled on their staffs: red, and yellow with a white edge
    for a, lean, L, c1, c2 in ((0.6, (0.03, 0.09), 1.18, REDB, None), (2.7, (-0.05, 0.1), 1.08, MUSTARD, CREAMW)):
        b, top = pole(a, lean, L)
        ax = (top - b).normalized()
        part(tube([top - ax * 0.44, top - ax * 0.05], 0.028, 10, 1), c1, 'in', bevel=0, mat='cloth', jit=0.04, rough=0.004, grit=14)
        if c2: part(tube([top - ax * 0.46, top - ax * 0.4], 0.0295, 10, 1), c2, 'in', bevel=0, mat='cloth', jit=0.04, rough=0.003, grit=14)
        for u in (0.12, 0.36): hoop(top - ax * u, ax, 0.03, 0.003, 10, ROPE)
        part(ball(0.014, 8, 6), BRASS, 'in', T(*top), bevel=0, gloss=0.6)
    # a net for catching what flies
    b, top = pole(4.3, (-0.02, 0.11), 1.06, 0.007)
    ax = (top - b).normalized(); inn = -(M.to_3x3() @ Vector((0.5, 1, 0))); bag = (inn - ax * inn.dot(ax)).normalized(); e1 = ax.cross(bag)
    hc = top + ax * 0.1
    part(tube([hc + (e1 * cos(i * pi / 9) + ax * sin(i * pi / 9)) * 0.1 for i in range(18)], 0.003, 5, 1, cyclic=True), STEEL, 'in', bevel=0, gloss=0.6)
    part(sheet(12, 5, lambda u, v: hc + (e1 * cos(u * 2 * pi) + ax * sin(u * 2 * pi)) * 0.1 * (1 - 0.86 * v) * (1 + 0.05 * sin(u * 19)) + bag * (0.2 * v + 0.012 * sin(u * 6.28 + 1) * v) + DOWN * 0.1 * v * v, 0.001), '#d8d2bc', 'in', bevel=0, mat='cloth', jit=0.05, sharp=80)
    # an umbrella, a stick
    b, top = pole(5.5, (0.06, 0.05), 0.86, 0.006, '#3a3a40')
    ax = (top - b).normalized()
    part(tube([b + ax * (0.12 + 0.062 * i) for i in range(11)], lambda u: 0.011 + 0.019 * max(0.0, sin(pi * min(1.0, u * 1.25))) ** 0.7, 10, 1), '#2f4a52', 'in', bevel=0, mat='cloth', jit=0.04, rough=0.003, grit=18)
    hoop(b + ax * 0.5, ax, 0.027, 0.003, 10, '#2f4a52', mat='cloth')
    part(tube([top, top + ax * 0.03, top + ax * 0.06 + Vector((0.03, 0.0, 0)), top + ax * 0.03 + Vector((0.055, 0, 0))], 0.009, 7, 4), '#8a5a34', 'in', bevel=0, mat='wood', jit=0.05)
    b, top = pole(1.7, (0.0, 0.07), 0.93, 0.0095, '#6a4a2a')
    part(ball(0.022, 8, 6, s=(1, 1, 0.8)), BRASS, 'in', T(*top), bevel=0, gloss=0.6)


def someone_lives_here():
    """Supper before the stove's door; a clock in pieces on the stool by the chart table."""
    sp = Vector((-0.925, -1.60, ZF)); phi = atan2(-sp.x, -0.3 - sp.y); F = T(*sp) @ R(-phi, 'Z')
    Fp = F @ T(0.03, 0.385, 0.022) @ R(0.5, 'Z')
    # a trivet, a small pan on it, three sausages in the pan, a fork across it
    part(tube([(0.052 * cos(i * pi / 8), 0.052 * sin(i * pi / 8), 0.062) for i in range(16)], 0.004, 5, 1, cyclic=True), DARK, 'in', Fp, bevel=0, gloss=0.3)
    for k in range(3):
        a = k * 2 * pi / 3 + 0.3
        part(tube([(0.052 * cos(a), 0.052 * sin(a), 0.062), (0.06 * cos(a), 0.06 * sin(a), 0.03), (0.066 * cos(a), 0.066 * sin(a), 0.0)], 0.004, 5, 2), DARK, 'in', Fp, bevel=0, gloss=0.3)
    part(lathe([(0, 0.066), (0.062, 0.066), (0.076, 0.09), (0.079, 0.09), (0.066, 0.07), (0.062, 0.062), (0, 0.062)], 16, close=True), DARK, 'in', Fp, bevel=0, gloss=0.35, mat='iron')
    part(tube([(0.07, 0, 0.084), (0.13, 0, 0.094), (0.22, 0, 0.098)], lambda u: 0.007 - 0.002 * u, 6, 3), DARK, 'in', Fp, bevel=0, gloss=0.35, mat='iron')
    hoop(Fp @ Vector((0.228, 0, 0.098)), Fp.to_3x3() @ Vector((0, 0, 1)), 0.009, 0.003, 8, DARK, gloss=0.35, mat='iron')
    for k, (y, turn) in enumerate(((-0.03, 0.1), (0.002, -0.08), (0.033, 0.16))):
        Ms = Fp @ T(0.0, y, 0.0795) @ R(turn, 'Z')
        part(tube([(-0.04, 0.004, 0), (-0.02, -0.002, 0.001), (0.02, -0.003, 0.001), (0.042, 0.003, 0)], lambda u: 0.0125 - 0.004 * abs(u - 0.5) ** 2 * 4, 8, 3), ('#8a4a2e', '#7a3f26', '#96553a')[k], 'in', Ms, bevel=0, mat='glaze', gloss=0.3, jit=0.05, rough=0.0015, grit=40)
    part(tube([(-0.06, -0.05, 0.094), (0.11, 0.07, 0.1)], 0.0022, 5, 1), STEEL, 'in', Fp, bevel=0, gloss=0.6)
    part(tube([(0.11, 0.07, 0.1), (0.17, 0.112, 0.1)], 0.006, 6, 1), '#6a4a2a', 'in', Fp, bevel=0, mat='wood', jit=0.05)
    # the clock: on a cloth, its back off, its wheels out, the driver beside them
    st = P(rad(-99), 1.98, ZF); Mc = T(st.x, st.y, ZF + 0.482) @ R(rad(99) + 0.4, 'Z')
    part(box(0.2, 0.17, 0.004), '#c9c0a8', 'in', Mc @ T(0, 0, 0.002) @ R(0.12, 'Z'), bevel=0.001, mat='cloth', jit=0.05, rough=0.002, grit=20, sub=2)
    part(lathe([(0, 0), (0.046, 0), (0.05, 0.006), (0.05, 0.03), (0.044, 0.036), (0.04, 0.03), (0.04, 0.008), (0, 0.008)], 16, close=True), BRASS, 'in', Mc @ T(-0.03, 0.02, 0.004), bevel=0, gloss=0.6, jit=0.03)
    part(cyl(0.038, 0.003, 14), '#3a3026', 'in', Mc @ T(-0.03, 0.02, 0.0135), bevel=0, mat='iron', gloss=0.3)
    for k, (x, y, r) in enumerate(((-0.04, 0.03, 0.014), (-0.018, 0.012, 0.01), (0.045, -0.04, 0.016), (0.07, -0.01, 0.009), (0.03, -0.055, 0.007))):
        z = 0.016 if k < 2 else 0.0045
        part(lathe([(0.002, 0), (r, 0), (r, 0.002), (0.002, 0.002)], 10, close=True), BRASS, 'in', Mc @ T(x, y, z), bevel=0, gloss=0.6)
        for j in range(5): part(box(0.003, 0.0022, 0.002), BRASS, 'in', Mc @ T(x, y, z + 0.001) @ R(j * 2 * pi / 5, 'Z') @ T(r + 0.001, 0, 0), bevel=0, gloss=0.6)
    part(cyl(0.047, 0.003, 16), BRASS, 'in', Mc @ T(0.055, 0.045, 0.0055) @ R(0.06, 'X'), bevel=0.001, gloss=0.6, jit=0.03)
    part(tube([(-0.09, -0.06, 0.008), (0.0, -0.068, 0.008)], 0.0022, 5, 1), STEEL, 'in', Mc, bevel=0, gloss=0.6)
    part(tube([(0.0, -0.068, 0.0105), (0.07, -0.074, 0.0105)], lambda u: 0.007 + 0.002 * sin(pi * u), 8, 1), REDB, 'in', Mc, bevel=0, mat='enamel', gloss=0.3)
    for k in range(4): part(cyl(0.002, 0.004, 5), STEEL, 'in', Mc @ T(-0.075 + 0.012 * k, 0.065 - 0.006 * (k % 2), 0.006), bevel=0, gloss=0.6)


def edges():
    """A striped edge where a head would meet the helmet's shelf."""
    part(slab(2.0715, 2.081, ZF + 1.9515, ZF + 1.9735, rad(145.4), rad(164.6), 6), RED, 'in', bevel=0.0008, mat='stripe')


def build():
    door_panel()
    suit_more()
    under_roof()
    on_walls()
    on_floor()
    small_things()
    visor()
    count = lambda: sum(len(o.data.polygons) for g in ('in', 'visor') for o in COL[g].objects)
    n0 = count()
    centre(); bunting(); kite(); floats(); fruit()
    locker(); by_the_door(); flag_stand(); someone_lives_here(); edges()
    print('room2 third pass faces', count() - n0, 'visor faces', sum(len(o.data.polygons) for o in COL['visor'].objects))
