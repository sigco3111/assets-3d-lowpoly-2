# The ship, built in Blender from this script: a round wooden hut that flies.
#
#   blender -b --factory-startup -P tools/ship/build.py -- [preview] [bake] [export]
#
# Barrel staves bound in copper hoops (tarred below, a red stripe, cream above), a copper cone roof, a lantern
# window round the front, four sprung legs, a ramp at the back that is also the door. Inside: one round room with
# the pilot's seat and desk at the window, a chart table, a hammock, a stove with its kettle, a suit by the door.
#
# preview: pictures of it into tools/ship/out. bake: works out the light of the sky and of its own lamps on every
# surface, into two pictures each for outside and inside. export: public/ship/ship.glb for the game.
import bpy, sys, os, random
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
ARGS = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
bpy.ops.wm.read_factory_settings(use_empty=True)
from lib import *
from math import asin, hypot, floor
random.seed(11)
OUT = os.path.join(HERE, 'out')
PUBLIC = os.path.normpath(os.path.join(HERE, '..', '..', 'public', 'ship'))
collections(['out', 'in', 'ramp', 'glass', 'face', 'aux', 'visor'])

from dims import *


# =============================================================================================== the outside
def hull():
    hullcol = lambda p: TAR if p.z < 1.66 else RED if p.z < 1.90 else CREAM
    # staves of uneven widths, no two alike (but the edges of the window and of the door still fall between two);
    # here and there one is pieced from two lengths; each stands a hair proud of its neighbours or shy of them
    nail = lambda th, r, z: part(cyl(0.0075, 0.006, 5), DARK, 'out', at(th, r + 0.002, z) @ R(-pi / 2, 'X'), bevel=0, gloss=0.3, jit=0.1)
    for a0, a1, n in ((-180, -165, 4), (-165, -60, 28), (-60, 60, 32), (60, 165, 28), (165, 180, 4)):
        ws = [random.uniform(0.62, 1.45) for _ in range(n)]; tot = sum(ws); a = a0
        for w in ws:
            b = a + (a1 - a0) * w / tot
            th = rad((a + b) / 2); wid = RO * rad(b - a); proud = random.uniform(-0.004, 0.003)
            # (tar in the seam between this one and the last)
            for s, e in spans(rad(a), RO, ZB, ZW):
                part(box(0.018, 0.012, e - s), '#17120f', 'out', at(rad(a), RO - 0.016, (s + e) / 2), bevel=0, mat='soot', jit=0.02)
            for s, e in spans(th, RO, ZB, ZW):
                runs = [(s, e)]
                if e - s > 1.3 and random.random() < 0.24:
                    zj = random.choice([z for z in (1.18, 1.36, 2.12, 2.4, 2.72, 2.96) if s + 0.3 < z < e - 0.3] or [0])
                    if zj: runs = [(s, zj - 0.003), (zj + 0.003, e)]; [nail(th + d, RO + proud, zj + dz) for d in (-0.3 * wid / RO, 0.3 * wid / RO) for dz in (-0.035, 0.035)]
                for s2, e2 in runs:
                    part(box(wid - 0.007, TS, e2 - s2), hullcol, 'out', at(th, RO - TS / 2 + proud, (s2 + e2) / 2), bevel=0.006, jit=0.085, cuts=[z for z in (1.66, 1.90) if s2 < z < e2])
                # (a nail above each hoop and one below it)
                for zh in (0.99, 1.66, 3.22):
                    for dz in (-0.062, 0.062):
                        if s < zh + dz - 0.02 and zh + dz + 0.02 < e: nail(th + random.uniform(-0.2, 0.2) * wid / RO, RO + proud, zh + dz + random.uniform(-0.006, 0.006))
            a = b
    # hoops, and their bolts
    for z, whole in ((0.99, False), (1.66, False), (3.22, True)):
        a = pi if whole else pi - DA - 0.03
        part(slab(RO - 0.002, RO + 0.014, z - 0.04, z + 0.04, -a, a, 96), COPPER, 'out', bevel=0.003, gloss=0.6, jit=0.03)
        for k in range(24):
            th = -pi + (k + 0.5) * pi / 12
            if not whole and abs(abs(th) - pi) < DA + 0.05: continue
            part(cyl(0.018, 0.014, 8), BRASS, 'out', at(th, RO + 0.018, z) @ R(-pi / 2, 'X'), bevel=0.003, gloss=0.6)
    # the window round the front: posts of dark wood, a sill and a head, panes between. The three panes in the
    # middle have no post between them (the pilot looks out through them): glass meets glass there, and nothing
    # else, so that from the seat it is one sheet
    for k in range(6):
        if k in (2, 3): continue
        part(box(0.08 if k in (0, 5) else 0.05, 0.17, HEAD - SILL + 0.16), WOOD_D, 'out', at(rad(-60 + 24 * k), RO - 0.085, (SILL + HEAD) / 2), bevel=0.012)
    for k in range(5):
        th, c, rm = rad(-48 + 24 * k), 2 * (RO - 0.085) * sin(rad(12)), (RO - 0.085) * cos(rad(12))
        for z in (SILL - 0.03, HEAD + 0.03): part(box(c + 0.02, 0.19, 0.10), WOOD_D, 'out', at(th, rm, z), bevel=0.012)
        part(plane(c, HEAD - SILL), '#9fc0c8', 'glass', at(th, rm - 0.01, (SILL + HEAD) / 2), bevel=0)
    # portholes
    for tp, zp, rp in PORTS:
        M = at(tp, 0, zp) @ R(-pi / 2, 'X')
        part(lathe([(rp - 0.03, RI - 0.03), (rp + 0.03, RI - 0.03), (rp + 0.03, RO + 0.04), (rp - 0.03, RO + 0.04)], 28, close=True), BRASS, 'out', M, bevel=0.006, gloss=0.6)
        part(lathe([(rp + 0.02, RO - 0.05), (rp + 0.17, RO - 0.05), (rp + 0.17, RO + 0.03), (rp + 0.02, RO + 0.03)], 28, close=True), BRASS, 'out', M, bevel=0.008, gloss=0.6)
        part(lathe([(rp + 0.02, RI + 0.02), (rp + 0.17, RI + 0.02), (rp + 0.17, RI - 0.035), (rp + 0.02, RI - 0.035)], 28, close=True), BRASS, 'in', M, bevel=0.008, gloss=0.6)
        for k in range(8):
            a = k * pi / 4 + 0.2
            part(cyl(0.016, 0.012, 8), IRON, 'out', M @ T((rp + 0.1) * cos(a), (rp + 0.1) * sin(a), RO + 0.035), bevel=0.003, gloss=0.5)
        part(cyl(rp - 0.03, 0.01, 28), '#9fc0c8', 'glass', M @ T(0, 0, RO - 0.06), bevel=0)
    # the door's frame
    for sgn in (-1, 1):
        part(box(0.12, 0.24, DOOR_TOP - ZB), WOOD_D, 'out', at(pi - sgn * asin(0.60 / 2.47), 2.47, (DOOR_TOP + ZB) / 2), bevel=0.012)
    part(box(1.34, 0.24, 0.12), WOOD_D, 'out', at(pi, 2.44, DOOR_TOP + 0.04), bevel=0.012)
    part(box(1.2, 0.3, 0.05), BRASS, 'out', at(pi, 2.47, ZF - 0.012), bevel=0.01, gloss=0.5)
    # the belly, its ribs, and the engine
    belly = [(RO + 0.02, 0.95), (RO + 0.03, 0.88), (2.3, 0.76), (1.6, 0.6), (0.8, 0.5), (0.0, 0.48)]
    part(lathe(belly + [(0.0, 0.9), (RO - 0.1, 0.95)], 64, close=True), IRON, 'out', bevel=0, gloss=0.3)
    for k in range(16):
        th = k * pi / 8 + pi / 16
        part(tube([P(th, r, z - 0.012) for r, z in belly[1:5]], 0.026, 6, 3), DARK, 'out', bevel=0, gloss=0.3)
    part(lathe([(0.26, 0.60), (0.30, 0.46), (0.44, 0.30), (0.60, 0.15), (0.56, 0.15), (0.41, 0.30), (0.27, 0.46), (0.20, 0.60)], 32, close=True), DARK, 'out', bevel=0, gloss=0.5)
    part(cyl(0.27, 0.02, 24), '#5a2a1a', 'out', T(0, 0, 0.47), bevel=0)
    part(slab(0.3, 0.52, 0.5, 0.56, 0, 2 * pi, 32), COPPER, 'out', bevel=0.008, gloss=0.6)
    for k in range(4):
        part(lathe([(0.09, 0.72), (0.1, 0.62), (0.17, 0.5), (0.22, 0.42), (0.2, 0.42), (0.15, 0.5), (0.08, 0.62), (0.05, 0.72)], 16, close=True), DARK, 'out', T(*P(k * pi / 2, 1.55, 0)), bevel=0, gloss=0.5)
        th = pi / 4 + k * pi / 2
        part(tube([P(th, 0.45, 0.47), P(th, 1.2, 0.46), P(th, 2.0, 0.6), P(th, 2.45, 0.8)], 0.03, 8, 4), COPPER, 'out', bevel=0, gloss=0.6)
    # lamps in front, and one by the door
    for sgn in (-1, 1):
        M = at(sgn * rad(20), RO + 0.07, 1.46) @ R(-pi / 2, 'X')
        part(cyl(0.17, 0.2, 20), BRASS, 'out', M, bevel=0.012, gloss=0.6)
        part(cyl(0.135, 0.02, 20), '#ffe2a8', 'out', M @ T(0, 0, 0.1), bevel=0, glow=2.2)
    a = pi - rad(21)
    part(tube([P(a, RO, 3.02), P(a, RO + 0.2, 3.06), P(a, RO + 0.3, 2.98)], 0.012, 6, 4), IRON, 'out', bevel=0)
    lantern('out', P(a, RO + 0.3, 2.82), 1.2, 7, 45)


def legs():
    """Four sprung legs: each a cylinder hung by a pin from an iron shoe on the wall, a rod out of it in a gaiter, a spring, a pad on a ball."""
    for k, th in enumerate((rad(45), rad(135), rad(-135), rad(-45))):
        top, foot = P(th, RO + 0.02, 1.78), P(th, 3.62, 0.17)
        L = (foot - top).length; ax = (foot - top) / L
        A = aim(top, foot)                       # its own +Z runs down the leg, its +X along the wall
        hoop = lambda s, r, w, t, col, gloss=0.4, n=14: part(slab(r - 0.001, r + t, s - w / 2, s + w / 2, 0, 2 * pi, n), col, 'out', A, bevel=0, gloss=gloss)
        # where it is hung: a pad of timber on the wall, an iron shoe on that, two cheeks and a pin through the leg's eye
        part(box(0.44, 0.06, 0.44), WOOD_D, 'out', at(th, RO + 0.004, 1.78), bevel=0.012, jit=0.05)
        part(box(0.3, 0.12, 0.3), IRON, 'out', at(th, RO + 0.03, 1.78), bevel=0.02, gloss=0.4)
        for sx in (-1, 1):
            for sz in (-1, 1): part(cyl(0.014, 0.012, 6), STEEL, 'out', at(th, RO + 0.04, 1.78) @ T(sx * 0.185, 0, sz * 0.185) @ R(-pi / 2, 'X'), bevel=0, gloss=0.6)
            part(box(0.022, 0.15, 0.26), IRON, 'out', A @ T(sx * 0.105, 0, 0.09), bevel=0.008, gloss=0.4)
            part(cyl(0.036, 0.02, 6), STEEL, 'out', A @ T(sx * 0.128, 0, 0.135) @ R(pi / 2, 'Y'), bevel=0, gloss=0.6)
        part(cyl(0.022, 0.29, 10), STEEL, 'out', A @ T(0, 0, 0.135) @ R(pi / 2, 'Y'), bevel=0.003, gloss=0.6)
        part(ball(0.095, 12, 8, s=(0.8, 1, 1)), IRON, 'out', A @ T(0, 0, 0.135), bevel=0, gloss=0.4)
        Mn = at(th, RO + 0.034, 1.965) @ R(pi, 'Z')
        part(box(0.15, 0.004, 0.052), ENAMEL, 'out', Mn @ T(0, -0.002, 0), bevel=0.0015, gloss=0.3)
        label('No. %d' % (k + 1), Mn @ T(0, -0.005, 0), 0.13, 'out')
        # the cylinder: a neck, a cap, two bands bolted round it, a gland of copper where the rod comes out
        s0, s1 = 0.21, 0.585 * L
        part(tube([top + ax * 0.135, top + ax * s0], 0.05, 10, 1), IRON, 'out', bevel=0, gloss=0.4)
        part(cyl(0.093, 0.05, 14), IRON, 'out', A @ T(0, 0, s0 + 0.012), bevel=0.012, gloss=0.4)
        part(tube([top + ax * s0, top + ax * s1], 0.085, 14, 1), IRON, 'out', bevel=0, gloss=0.4, jit=0.05)
        for s in (0.44, 0.86):
            hoop(s, 0.085, 0.045, 0.008, DARK)
            for j in range(6): part(cyl(0.009, 0.008, 5), STEEL, 'out', A @ R(j * pi / 3 + s, 'Z') @ T(0.094, 0, s) @ R(pi / 2, 'Y'), bevel=0, gloss=0.6)
        part(cyl(0.012, 0.03, 6), BRASS, 'out', A @ R(2.2, 'Z') @ T(0.092, 0, 0.62) @ R(pi / 2, 'Y'), bevel=0, gloss=0.6)
        part(lathe([(0.052, s1 - 0.07), (0.088, s1 - 0.07), (0.104, s1 - 0.055), (0.104, s1 + 0.015), (0.08, s1 + 0.045), (0.052, s1 + 0.05)], 14, close=True), COPPER, 'out', A, bevel=0, gloss=0.6)
        for j in range(8): part(cyl(0.008, 0.008, 5), BRASS, 'out', A @ R(j * pi / 4, 'Z') @ T(0.105, 0, s1 - 0.02) @ R(pi / 2, 'Y'), bevel=0, gloss=0.6)
        part(tube([top + ax * (s1 - 0.02), foot], 0.05, 10, 1), BRASS, 'out', bevel=0, gloss=0.7)
        # a gaiter of cloth over the rod, clamped at both ends
        g0 = s1 + 0.055; g1 = g0 + 0.2
        prof = [(0.088 if i % 2 else 0.062, g0 + (g1 - g0) * i / 10) for i in range(11)] + [(0.052, g1), (0.052, g0)]
        part(lathe(prof, 14, close=True), '#857a5e', 'out', A, bevel=0, mat='canvas', rough=0.004, grit=30, jit=0.05)
        for s in (g0 + 0.003, g1 - 0.003): hoop(s, 0.061, 0.016, 0.005, STEEL, 0.6, 12)
        # the spring, between two seats
        p0 = g1 + 0.04; p1 = L - 0.27; n = int((p1 - p0) / 0.045 * 12)
        part(tube([A @ Vector((0.074 * cos(i * pi / 6), 0.074 * sin(i * pi / 6), p0 + (p1 - p0) * i / n)) for i in range(n + 1)], 0.012, 5, 1), STEEL, 'out', bevel=0, gloss=0.6)
        for s in (p0 - 0.014, p1 + 0.014): part(cyl(0.095, 0.014, 14), STEEL, 'out', A @ T(0, 0, s), bevel=0.003, gloss=0.6)
        # a skirt of tin over the joint, to keep the mud out of it
        a0, b0 = L - 0.245, L - 0.115
        cone = [(0.066 + 0.129 * t, a0 - 0.012 + (b0 - a0 + 0.012) * t) for t in (0, 0.34, 0.67, 1)]
        part(lathe([(0.052, a0 - 0.012)] + cone + [(r - 0.006, z + 0.004) for r, z in reversed(cone)], 16, close=True), '#8f948f', 'out', A, bevel=0, gloss=0.4, mat='tin', jit=0.05, rough=0.004, grit=11)
        hoop(a0 - 0.006, 0.064, 0.014, 0.005, STEEL, 0.6, 12)
        # (its edge rolled over a wire; a lapped seam down it, riveted; three dabs of solder where it was holed)
        part(tube([(0.196 * cos(i * pi / 9), 0.196 * sin(i * pi / 9), b0) for i in range(18)], 0.006, 5, 1, cyclic=True), '#8f948f', 'out', A, bevel=0, gloss=0.4, mat='tin')
        for t in (0.15, 0.4, 0.65, 0.9): part(ball(0.006, 6, 4), STEEL, 'out', A @ R(0.6, 'Z') @ T(0.068 + 0.129 * t, 0, a0 - 0.012 + (b0 - a0 + 0.012) * t), bevel=0, gloss=0.6)
        part(tube([(0.064, 0.012, a0 - 0.01), (0.196, 0.012, b0)], 0.004, 4, 1), '#8f948f', 'out', A @ R(0.6, 'Z'), bevel=0, gloss=0.4, mat='tin')
        for an, t in ((2.4, 0.5), (4.0, 0.75), (5.1, 0.35)): part(ball(0.012, 6, 4, s=(1, 1, 0.4)), '#aab0b0', 'out', A @ R(an, 'Z') @ T(0.069 + 0.129 * t, 0, a0 - 0.012 + (b0 - a0 + 0.012) * t) @ R(0.78, 'Y'), bevel=0, gloss=0.6)
        # the braces, each bolted to a plate on the wall and clamped round the cylinder
        part(tube([P(th, 2.45, 0.9), lerp(top, foot, 0.5)], 0.04, 8, 1), IRON, 'out', bevel=0, gloss=0.4)
        hoop(0.5 * L, 0.085, 0.07, 0.01, IRON)
        hoop(0.56 * L - 0.01, 0.085, 0.06, 0.01, IRON)
        for d in (-1, 1):
            part(tube([P(th + d * rad(15), 2.52, 1.05), lerp(top, foot, 0.56)], 0.03, 8, 1), IRON, 'out', bevel=0, gloss=0.4)
            Mp = at(th + d * rad(15), RO + 0.006, 1.09)
            part(box(0.15, 0.014, 0.11), IRON, 'out', Mp, bevel=0.004, gloss=0.4)
            part(box(0.07, 0.05, 0.06), IRON, 'out', Mp @ T(0, 0.02, -0.03), bevel=0.01, gloss=0.4)
            for sx in (-1, 1):
                for sz in (-1, 1): part(cyl(0.009, 0.008, 6), STEEL, 'out', Mp @ T(sx * 0.055, 0.011, sz * 0.035) @ R(-pi / 2, 'X'), bevel=0, gloss=0.6)
        # the foot: a ball in a collar, a broad pad with ribs on it and bolts round its rim
        F = T(foot.x, foot.y, 0)
        part(lathe([(0, 0.17), (0.12, 0.17), (0.3, 0.09), (0.33, 0.03), (0.3, 0.0), (0, 0.0)], 20, close=True), IRON, 'out', F, bevel=0, gloss=0.4)
        part(ball(0.085, 12, 8), BRASS, 'out', T(*foot), bevel=0, gloss=0.7)
        part(lathe([(0.086, 0.168), (0.128, 0.168), (0.128, 0.192), (0.112, 0.208), (0.086, 0.208)], 16, close=True), DARK, 'out', F, bevel=0, gloss=0.4)
        for j in range(8):
            Mj = F @ R(j * pi / 4 + 0.39, 'Z')
            part(cyl(0.008, 0.008, 5), STEEL, 'out', Mj @ T(0, 0.1, 0.212), bevel=0, gloss=0.6)
            part(box(0.022, 0.15, 0.016), DARK, 'out', Mj @ T(0, 0.214, 0.135) @ R(-0.418, 'X'), bevel=0.004, gloss=0.4)
            part(ball(0.013, 6, 4), STEEL, 'out', F @ R(j * pi / 4, 'Z') @ T(0, 0.317, 0.062), bevel=0, gloss=0.6)


def tanks():
    # (each a little out of true, as a thing beaten from sheet is; a lapped seam where each end is welded on)
    cap = [(0, -0.95), (0.2, -0.92), (0.36, -0.8), (0.42, -0.62), (0.42, -0.2), (0.42, 0.2), (0.42, 0.62), (0.36, 0.8), (0.2, 0.92), (0, 0.95)]
    for sgn in (-1, 1):
        c = Vector((sgn * 3.03, -0.1, 1.60))
        M = T(*c) @ R(-pi / 2, 'X')
        col = RED if sgn < 0 else (lambda p: RED if abs(p.y + 0.1) < 0.62 else CREAM)
        part(lathe(cap, 44), col, 'out', M, bevel=0, gloss=0.25, jit=0.04, mat='enamel', rough=0.005, grit=2.6)
        for z in (-0.62, 0.62): part(slab(0.418, 0.4275, z - 0.032, z + 0.032, 0, 2 * pi, 44), RED, 'out', M, bevel=0, gloss=0.25, jit=0.05, mat='enamel')
        for z in (-0.45, 0.45):
            y = c.y + z
            part(slab(0.415, 0.44, z - 0.04, z + 0.04, 0, 2 * pi, 24), IRON, 'out', M, bevel=0.004, gloss=0.4)
            # (the strap is drawn tight by a bolt through two lugs, up on its shoulder)
            Mt = M @ R(-pi / 2 + sgn * 0.75, 'Z') @ T(0.44, 0, z)
            for d in (-1, 1): part(box(0.035, 0.022, 0.07), IRON, 'out', Mt @ T(0.012, d * 0.035, 0), bevel=0.004, gloss=0.4)
            part(cyl(0.008, 0.13, 6), STEEL, 'out', Mt @ T(0.018, 0, 0) @ R(pi / 2, 'X'), bevel=0, gloss=0.6)
            for d in (-1, 1): part(cyl(0.014, 0.014, 6), STEEL, 'out', Mt @ T(0.018, d * 0.055, 0) @ R(pi / 2, 'X'), bevel=0, gloss=0.6)
            # an arm of iron out from the wall under it, a knee below the arm, two chocks of wood on the arm, a tie above
            part(box(0.92, 0.07, 0.07), IRON, 'out', T(sgn * 2.95, y, 1.135), bevel=0.012, gloss=0.4)
            part(tube([(sgn * 3.34, y, 1.105), (sgn * 2.53, y, 0.98)], 0.026, 8, 1), IRON, 'out', bevel=0, gloss=0.4)
            part(box(0.06, 0.1, 0.1), IRON, 'out', T(sgn * 2.552, y, 0.985), bevel=0.01, gloss=0.4)
            part(box(0.05, 0.12, 0.13), IRON, 'out', T(sgn * 2.55, y, 1.135), bevel=0.01, gloss=0.4)
            for s2 in (-1, 1):
                part(box(0.16, 0.1, 0.085), WOOD, 'out', T(c.x + s2 * 0.244, y, 1.21) @ R(-s2 * rad(32), 'Y'), bevel=0.01, jit=0.06)
                part(cyl(0.011, 0.012, 6), STEEL, 'out', T(c.x + s2 * 0.33, y + 0.02, 1.176), bevel=0, gloss=0.6)
            part(box(0.16, 0.1, 0.1), IRON, 'out', T(sgn * 2.575, y, 1.5), bevel=0.015, gloss=0.4)
        part(cyl(0.105, 0.03, 12), BRASS, 'out', M @ T(0, 0, 0.935), bevel=0.006, gloss=0.6)
        part(cyl(0.08, 0.14, 12), BRASS, 'out', M @ T(0, 0, 0.98), bevel=0.01, gloss=0.6)
        part(tube([(0.11 * cos(i * pi / 8), 0.11 * sin(i * pi / 8), 1.06) for i in range(16)], 0.013, 6, 1, cyclic=True), RED, 'out', M, bevel=0)
        part(tube([(c.x, 0.3, 2.0), (c.x - sgn * 0.02, 0.3, 2.3), (sgn * 2.74, 0.3, 2.42), (sgn * 2.5, 0.3, 2.42)], 0.035, 8, 5), COPPER, 'out', bevel=0, gloss=0.6)


def roof():
    NR, RA, ZA, RE, ZE = 20, 0.30, 4.52, 2.86, 3.37
    sl = (ZA - ZE) / (RE - RA); beta = atan2(ZA - ZE, RE - RA)
    zr = lambda r: ZA - (r - RA) * sl
    sky = Vector((0, 1.30, 0)); cutme = []
    for i in range(NR):
        a0 = (i - 0.5) * 2 * pi / NR; a1 = a0 + 2 * pi / NR
        ob = part(lathe([(RA, ZA), (RE, ZE), (RE, ZE - 0.035), (RA, ZA - 0.035)], 3, a0 + 0.004, a1 - 0.004, close=True), COPPER, 'out', bevel=0.004, gloss=0.55, jit=0.1)
        if abs(ang((a0 + a1) / 2)) < 0.5: cutme.append(ob)
        # the standing seam between two sheets (it stops either side of the skylight)
        runs = [(RA, RE + 0.01)]
        d = abs(1.30 * sin(ang(a0)))
        if abs(ang(a0)) < 0.5 and d < 0.47: h = sqrt(0.47 ** 2 - d * d) / cos(beta); runs = [(RA, 1.30 - h), (1.30 + h, RE + 0.01)]
        for r0, r1 in runs:
            part(box(0.035, (r1 - r0) / cos(beta), 0.05), COPPER, 'out', at(a0, (r0 + r1) / 2, zr((r0 + r1) / 2) + 0.012) @ R(-beta, 'X'), bevel=0.008, gloss=0.55, jit=0.05)
    part(tube([P(i * pi / 32, RE + 0.01, ZE - 0.02) for i in range(64)], 0.035, 8, 1, cyclic=True), COPPER, 'out', bevel=0, gloss=0.55)
    part(slab(RO - 0.1, RE - 0.02, 3.30, 3.345, 0, 2 * pi, 64), WOOD_D, 'out', bevel=0.006)
    # the ceiling inside: painted boards, rafters, a ring at the top
    for i in range(24):
        a0 = i * pi / 12; a1 = a0 + pi / 12
        ob = part(lathe([(0.34, 4.31), (2.46, 3.37), (2.46, 3.345), (0.34, 4.285)], 2, a0 + 0.003, a1 - 0.003, close=True), CEIL, 'in', bevel=0.003, jit=0.05)
        if abs(ang((a0 + a1) / 2)) < 0.5: cutme.append(ob)
    zc = lambda r: 4.285 - (r - 0.34) * 0.4434; bc = atan2(0.94, 2.12)
    for k in range(12):
        th = rad(15 + 30 * k)
        part(box(0.06, 1.96 / cos(bc), 0.11), WOOD_D, 'in', at(th, 1.38, zc(1.38) - 0.058) @ R(-bc, 'X'), bevel=0.008)
    part(slab(0.28, 0.42, 4.10, 4.24, 0, 2 * pi, 24), IRON, 'in', bevel=0.012, gloss=0.4)
    part(cyl(0.36, 0.03, 20), DARK, 'in', T(0, 0, 4.29), bevel=0)
    part(slab(RI - 0.07, RI + 0.01, 3.28, 3.38, 0, 2 * pi, 72), WOOD_D, 'in', bevel=0.008)
    # the skylight over the pilot: a brass collar through the roof, glass on top
    Ms = T(0, 1.30, zr(1.30)) @ R(-beta, 'X')
    part(lathe([(0.34, -0.3), (0.40, -0.3), (0.40, 0.05), (0.45, 0.05), (0.45, 0.1), (0.34, 0.1)], 28, close=True), BRASS, 'out', Ms, bevel=0.006, gloss=0.6)
    part(ball(0.345, 28, 8, s=(1, 1, 0.3), o=(0, 0, 0.07)), '#9fc0c8', 'glass', Ms, bevel=0)
    for a in (0, pi / 2): part(tube([(0.345 * cos(t), 0, 0.07 + 0.1035 * sin(t)) for t in [i * pi / 10 for i in range(11)]], 0.011, 5, 1), BRASS, 'out', Ms @ R(a, 'Z'), bevel=0, gloss=0.6)
    # on top: a cap, a mast with its lamp, stays
    part(lathe([(0, 4.70), (0.12, 4.68), (0.3, 4.58), (0.36, 4.5), (0.36, 4.46), (0, 4.46)], 24, close=True), COPPER, 'out', bevel=0, gloss=0.55)
    part(tube([(0, 0, 4.68), (0, 0, 6.1)], lambda u: 0.03 - 0.012 * u, 8, 1), IRON, 'out', bevel=0, gloss=0.4)
    part(tube([(-0.35, 0, 5.55), (0.35, 0, 5.55)], 0.012, 6, 1), IRON, 'out', bevel=0)
    part(ball(0.065, 12, 8), '#ffb060', 'out', T(0, 0, 6.15), bevel=0, glow=6)
    for a in (rad(60), rad(180), rad(300)): part(tube([(0, 0, 5.5), P(a, 1.2, zr(1.2))], 0.005, 4, 1), DARK, 'out', bevel=0)
    # the stovepipe, with its hat
    sp = Vector((-0.925, -1.60, 0))
    part(tube([sp + Vector((0, 0, 3.6)), sp + Vector((0, 0, 4.47))], 0.075, 14, 1), DARK, 'out', bevel=0, gloss=0.3)
    part(lathe([(0.085, 4.0), (0.2, 3.80), (0.2, 3.74), (0.085, 3.74)], 16, close=True), COPPER, 'out', T(sp.x, sp.y, 0), bevel=0.004, gloss=0.55)
    part(lathe([(0, 4.64), (0.17, 4.52), (0.17, 4.5), (0, 4.55)], 16, close=True), COPPER, 'out', T(sp.x, sp.y, 0), bevel=0, gloss=0.55)
    for k in range(3): part(box(0.012, 0.012, 0.1), DARK, 'out', T(sp.x + 0.07 * cos(k * 2.1), sp.y + 0.07 * sin(k * 2.1), 4.5), bevel=0)
    # a dish
    base = P(rad(140), 1.9, zr(1.9)); top = base + Vector((0, 0, 0.55))
    part(tube([base, top], 0.022, 8, 1), IRON, 'out', bevel=0, gloss=0.4)
    for a in (0, 2.1, 4.2): part(tube([base + Vector((0.25 * cos(a), 0.25 * sin(a), -0.06 * cos(a + 0.9))), lerp(base, top, 0.6)], 0.01, 5, 1), IRON, 'out', bevel=0)
    Md = aim(top, top + Vector((sin(rad(140)) * 0.6, cos(rad(140)) * 0.6, 0.7)))
    part(lathe([(0, 0), (0.15, 0.012), (0.3, 0.05), (0.45, 0.115), (0.46, 0.115), (0.3, 0.04), (0.15, 0.0), (0, -0.012)], 24, close=True), CREAM, 'out', Md, bevel=0, jit=0.03, mat='enamel')
    part(tube([(0, 0, 0), (0, 0, 0.3)], 0.01, 6, 1), BRASS, 'out', Md, bevel=0, gloss=0.6)
    part(ball(0.03, 8, 6), BRASS, 'out', Md @ T(0, 0, 0.31), bevel=0, gloss=0.6)
    # a pennant at the masthead, and rungs up the back to the roof
    part(sheet(8, 3, lambda u, v: (0.0, -0.03 - u * 0.5, 5.98 - 0.2 * v * (1 - u) - 0.06 * u + 0.025 * sin(u * 7)), 0.004), RED, 'out', bevel=0, sharp=80)
    # (the ladder's rails, and its way out round the eave and onto the roof, are in outside2.py)
    for k in range(8):
        part(tube([(-0.17, -0.02, 0), (-0.17, 0.09, 0), (0.17, 0.09, 0), (0.17, -0.02, 0)], 0.014, 6, 3), BRASS, 'out', at(rad(-152), RO, 1.2 + 0.25 * k), bevel=0, gloss=0.6)
    return cutme, Ms


def ramp():
    L, W = RAMP_L, RAMP_W
    for sgn in (-1, 1): part(box(0.07, L, 0.12), WOOD_D, 'ramp', HINGE @ T(sgn * (W / 2 - 0.035), -L / 2, -0.035), bevel=0.01)
    n = 15
    for i in range(n):
        part(box(W - 0.15, L / n - 0.008, 0.04), FLOOR, 'ramp', HINGE @ T(0, -(i + 0.5) * L / n, -0.02), bevel=0.005, jit=0.09)
        if i % 2 == 1: part(box(W - 0.24, 0.03, 0.018), WOOD_D, 'ramp', HINGE @ T(0, -(i + 0.5) * L / n, 0.008), bevel=0.004)
    # its other face is the door's outside: painted as the wall is, so that shut it carries the stripe across
    for s0, s1, col in ((0, 0.61, TAR), (0.61, 0.85, RED), (0.85, L, CREAM)):
        part(box(W, s1 - s0 - 0.004, 0.025), col, 'ramp', HINGE @ T(0, -(s0 + s1) / 2, -0.095), bevel=0.005, jit=0.04)
    for sgn in (-1, 1): part(cyl(0.035, 0.16, 10), BRASS, 'ramp', HINGE @ T(sgn * 0.36, 0, -0.03) @ R(pi / 2, 'Y'), bevel=0.006, gloss=0.6)
    part(box(W, 0.06, 0.06), IRON, 'ramp', HINGE @ T(0, -L - 0.01, -0.04), bevel=0.012, gloss=0.4)
    scr = lambda M, r=0.007: part(cyl(r, 0.004, 6), STEEL, 'ramp', M, bevel=0, gloss=0.6)
    for sgn in (-1, 1):
        x = sgn * (W / 2 - 0.035)
        # a low rail of brass along each edge, to keep a boot or a barrow on it
        part(tube([(x, -0.1, 0.02), (x, -0.17, 0.1), (x, -L / 2, 0.1), (x, -(L - 0.17), 0.1), (x, -(L - 0.1), 0.02)], 0.012, 7, 3), BRASS, 'ramp', HINGE, bevel=0, gloss=0.6)
        for k in range(4):
            y = -(0.36 + k * (L - 0.72) / 3)
            part(cyl(0.009, 0.08, 6), BRASS, 'ramp', HINGE @ T(x, y, 0.062), bevel=0, gloss=0.6)
            part(cyl(0.02, 0.006, 8), BRASS, 'ramp', HINGE @ T(x, y, 0.028), bevel=0, gloss=0.6)
        # the leaf of each hinge, let into the first board; a dog at the far end that catches under the door's head
        part(box(0.15, 0.1, 0.005), BRASS, 'ramp', HINGE @ T(sgn * 0.36, -0.065, 0.0035), bevel=0.0015, gloss=0.6)
        for dx in (-0.05, 0, 0.05): scr(HINGE @ T(sgn * 0.36 + dx, -0.075, 0.0075))
        part(box(0.06, 0.1, 0.03), IRON, 'ramp', HINGE @ T(sgn * 0.3, -L - 0.05, -0.04), bevel=0.008, gloss=0.4)
        part(cyl(0.02, 0.07, 8), STEEL, 'ramp', HINGE @ T(sgn * 0.3, -L - 0.095, -0.04) @ R(pi / 2, 'Y'), bevel=0.003, gloss=0.6)
        # (and on its other face, the long iron straps a door hangs by)
        part(box(0.06, 0.78, 0.008), IRON, 'ramp', HINGE @ T(sgn * 0.36, -0.4, -0.1115), bevel=0.002, gloss=0.4)
        for k in range(5): part(ball(0.011, 6, 4, s=(1, 1, 0.6)), IRON, 'ramp', HINGE @ T(sgn * 0.36, -0.08 - 0.165 * k, -0.116), bevel=0, gloss=0.5)
    # a plate of brass where feet first meet it, worn bright; ledges across the back of the door
    part(box(W - 0.2, 0.135, 0.005), BRASS, 'ramp', HINGE @ T(0, -(L - 0.083), 0.0035), bevel=0.0015, gloss=0.6)
    for k in range(6): scr(HINGE @ T(-0.36 + 0.144 * k, -(L - 0.083) + (0.045 if k % 2 else -0.045), 0.0075))
    for y in (0.3, 1.25, 2.15): part(box(W - 0.06, 0.08, 0.014), WOOD_D, 'ramp', HINGE @ T(0, -y, -0.1145), bevel=0.004, jit=0.05)


# ================================================================================================ the inside
def room():
    # (the room's builders are in room2.py, with everything else that is in the room)
    import room2; room2.room()


def table():
    import room2; room2.table()


def hammock():
    import room2; room2.hammock()


def stove():
    import room2; room2.stove()


def suit():
    import room2; room2.suit()


def lights_and_pipes():
    import room2; room2.lights_and_pipes()


# ============================================================================================== put together
hull(); legs(); tanks()
cutme, Ms = roof()
ramp(); room(); table(); hammock(); stove(); suit(); lights_and_pipes()
import cockpit, detail
cockpit.build(); detail.build()
# (more of each, where there is more: each is a file of its own with a build() in it)
for extra in ('cockpit2', 'room2', 'outside2'):
    if os.path.exists(os.path.join(HERE, extra + '.py')): __import__(extra).build()
print('parts', {k: len(c.objects) for k, c in COL.items()})

# the skylight's hole, through the roof and the ceiling
bpy.context.view_layer.update()
cutter = part(cyl(0.38, 1.2, 32), DARK, 'aux', Ms, bevel=0)
for ob in cutme:
    m = ob.modifiers.new('cut', 'BOOLEAN'); m.object = cutter; m.operation = 'DIFFERENCE'; m.solver = 'EXACT'
dg = bpy.context.evaluated_depsgraph_get()
for ob in cutme:
    me = bpy.data.meshes.new_from_object(ob.evaluated_get(dg))
    ob.modifiers.clear(); ob.data = me
bpy.data.objects.remove(cutter)

hull_ob = join('out', 'hull'); room_ob = join('in', 'room'); ramp_ob = join('ramp', 'ramp', HINGE); glass_ob = join('glass', 'glass')
# (what is seen of a helmet from inside it: a thing of its own, built round the eye at the origin, never lit beforehand)
visor_ob = join('visor', 'visor')
for o in (hull_ob, room_ob, ramp_ob, glass_ob):
    o.data.uv_layers['UVMap'].active = True; o.data.uv_layers['UVMap'].active_render = True
faces = list(COL['face'].objects)
for o in faces: o.name = o.data.name
# (the landing glass is built standing, as it is when it is up: SHIP_SCREEN=down shows it, in a preview, laid on the
# desk as it rests. cockpit.SCREEN_HINGE is a place on its hinge, cockpit.SCREEN_SWING how far round +X lays it down)
SCREEN_HINGE = getattr(cockpit, 'SCREEN_HINGE', None)
if 'preview' in ARGS and os.environ.get('SHIP_SCREEN') == 'down' and SCREEN_HINGE is not None:
    Ms = T(*SCREEN_HINGE) @ R(cockpit.SCREEN_SWING, 'X') @ T(*(-Vector(SCREEN_HINGE)))
    if 'screen' in room_ob.vertex_groups:
        gi = room_ob.vertex_groups['screen'].index
        for v in room_ob.data.vertices:
            if any(g.group == gi for g in v.groups): v.co = Ms @ v.co
    for o in faces:
        if o.name == 'face_main': o.matrix_world = Ms @ o.matrix_world
eye = bpy.data.objects.new('seat_eye', None); eye.matrix_world = T(*EYE); COL['aux'].objects.link(eye)
RAMP_OPEN = asin(ZF / RAMP_L)
ramp_ob.matrix_world = HINGE @ R(RAMP_OPEN, 'X')
print('faces', {o.name: len(o.data.polygons) for o in (hull_ob, room_ob, ramp_ob, glass_ob)})

# ------------------------------------------------------------------------------------------------ materials
def paint(name):
    m = bpy.data.materials.new(name); m.use_nodes = True
    nt = m.node_tree; nt.nodes.clear()
    N = lambda t, **kw: [n := nt.nodes.new(t), [setattr(n, k, v) for k, v in kw.items()]][0]
    out, bsdf = N('ShaderNodeOutputMaterial'), N('ShaderNodeBsdfPrincipled')
    attr = N('ShaderNodeAttribute', attribute_name='Col')
    glowing = N('ShaderNodeMath', operation='GREATER_THAN'); glowing.inputs[1].default_value = 0.895
    nt.links.new(attr.outputs['Alpha'], glowing.inputs[0])
    notglow = N('ShaderNodeMath', operation='SUBTRACT'); notglow.inputs[0].default_value = 1.0
    nt.links.new(glowing.outputs[0], notglow.inputs[1])
    gl = N('ShaderNodeMath', operation='MULTIPLY'); nt.links.new(attr.outputs['Alpha'], gl.inputs[0]); nt.links.new(notglow.outputs[0], gl.inputs[1])
    rough = N('ShaderNodeMath', operation='MULTIPLY_ADD'); rough.inputs[1].default_value = -0.8; rough.inputs[2].default_value = 0.95
    nt.links.new(gl.outputs[0], rough.inputs[0])
    metal = N('ShaderNodeMath', operation='MULTIPLY'); metal.name = 'Metal'; metal.inputs[1].default_value = 1.0
    isMetal = N('ShaderNodeMath', operation='GREATER_THAN'); isMetal.inputs[1].default_value = 0.45
    nt.links.new(gl.outputs[0], isMetal.inputs[0]); nt.links.new(isMetal.outputs[0], metal.inputs[0])
    st = N('ShaderNodeMath', operation='MULTIPLY_ADD'); st.inputs[1].default_value = 100.0; st.inputs[2].default_value = -90.0
    nt.links.new(attr.outputs['Alpha'], st.inputs[0])
    st2 = N('ShaderNodeMath', operation='MULTIPLY'); nt.links.new(st.outputs[0], st2.inputs[0]); nt.links.new(glowing.outputs[0], st2.inputs[1])
    lamps = N('ShaderNodeMath', operation='MULTIPLY'); lamps.name = 'Lamps'; lamps.inputs[1].default_value = 1.0
    nt.links.new(st2.outputs[0], lamps.inputs[0])
    nt.links.new(attr.outputs['Color'], bsdf.inputs['Base Color']); nt.links.new(attr.outputs['Color'], bsdf.inputs['Emission Color'])
    nt.links.new(rough.outputs[0], bsdf.inputs['Roughness']); nt.links.new(metal.outputs[0], bsdf.inputs['Metallic']); nt.links.new(lamps.outputs[0], bsdf.inputs['Emission Strength'])
    nt.links.new(bsdf.outputs[0], out.inputs[0])
    img = N('ShaderNodeTexImage'); img.name = 'Bake'; nt.nodes.active = img
    return m

mats = {o.name: paint('paint_' + o.name) for o in (hull_ob, room_ob, ramp_ob)}
for o in (hull_ob, room_ob, ramp_ob): o.data.materials.clear(); o.data.materials.append(mats[o.name])
gm = bpy.data.materials.new('glass'); gm.use_nodes = True
nt = gm.node_tree; nt.nodes.clear()
o_, mix, tr, gs = nt.nodes.new('ShaderNodeOutputMaterial'), nt.nodes.new('ShaderNodeMixShader'), nt.nodes.new('ShaderNodeBsdfTransparent'), nt.nodes.new('ShaderNodeBsdfGlossy')
mix.inputs[0].default_value = 0.1; gs.inputs['Roughness'].default_value = 0.02
nt.links.new(tr.outputs[0], mix.inputs[1]); nt.links.new(gs.outputs[0], mix.inputs[2]); nt.links.new(mix.outputs[0], o_.inputs[0])
glass_ob.data.materials.append(gm)
fm = bpy.data.materials.new('face'); fm.use_nodes = True
em = fm.node_tree.nodes.new('ShaderNodeEmission'); em.inputs['Color'].default_value = (0.45, 0.9, 0.7, 1); em.inputs['Strength'].default_value = 1.6
fm.node_tree.links.new(em.outputs[0], fm.node_tree.nodes['Material Output'].inputs[0])
for o in faces: o.data.materials.append(fm)

scene = bpy.context.scene
scene.render.engine = 'CYCLES'
try:
    prefs = bpy.context.preferences.addons['cycles'].preferences
    prefs.compute_device_type = 'OPTIX'; prefs.get_devices()
    for d in prefs.devices: d.use = d.type != 'CPU'
    scene.cycles.device = 'GPU'
except Exception as e: print('no gpu:', e)
world = bpy.data.worlds.new('w'); world.use_nodes = True; scene.world = world
bg = world.node_tree.nodes['Background']
lamps = []
for pos, colour, watts in LIGHTS:
    ld = bpy.data.lights.new('lamp', 'POINT'); ld.energy = watts; ld.color = lin(colour); ld.shadow_soft_size = 0.05
    lo = bpy.data.objects.new('lamp', ld); lo.location = pos; COL['aux'].objects.link(lo); lamps.append(lo)

def switches(lampsOn, metal):
    for m in mats.values():
        m.node_tree.nodes['Lamps'].inputs[1].default_value = 1.0 if lampsOn else 0.0
        m.node_tree.nodes['Metal'].inputs[1].default_value = 0.9 if metal else 0.0
    for lo in lamps: lo.hide_render = not lampsOn
    em.inputs['Strength'].default_value = 1.6 if lampsOn else 0.0

# ------------------------------------------------------------------------------------------------- pictures
if 'preview' in ARGS:
    switches(True, True)
    bg.inputs['Color'].default_value = (0.16, 0.24, 0.48, 1); bg.inputs['Strength'].default_value = 0.55
    sd = bpy.data.lights.new('sun', 'SUN'); sd.energy = 3.2; sd.color = (1.0, 0.72, 0.5); sd.angle = rad(3)
    so = bpy.data.objects.new('sun', sd); so.matrix_world = aim((0, 0, 0), (-0.75, -0.6, -0.2)).inverted().transposed().to_3x3().to_4x4() if False else aim((0, 0, 0), (0.75, 0.6, 0.22)); COL['aux'].objects.link(so)
    gd = bpy.data.meshes.new('ground'); gb = bmesh.new(); bmesh.ops.create_circle(gb, cap_ends=True, segments=48, radius=40); gb.to_mesh(gd); gb.free()
    go = bpy.data.objects.new('ground', gd); COL['aux'].objects.link(go)
    gmat = bpy.data.materials.new('ground'); gmat.use_nodes = True; gmat.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value = (0.12, 0.2, 0.06, 1); gd.materials.append(gmat)
    cd = bpy.data.cameras.new('cam'); cam = bpy.data.objects.new('cam', cd); COL['aux'].objects.link(cam); scene.camera = cam
    scene.cycles.samples = 96; scene.cycles.use_denoising = True
    scene.render.resolution_x, scene.render.resolution_y = 1280, 800
    scene.view_settings.view_transform = 'AgX'; scene.view_settings.exposure = 0.6
    scene.render.image_settings.file_format = 'JPEG'; scene.render.image_settings.quality = 88
    PTAG = os.environ.get('SHIP_TAG', '')
    views = {
        'front': ((6.2, 9.0, 2.5), (0, 0, 2.5), 32), 'back': ((-6.0, -9.5, 2.4), (0, -0.5, 2.3), 32), 'side': ((11, 0.5, 1.7), (0, 0, 2.7), 36),
        'door': ((0, -2.25, 2.72), (0, 1.2, 2.3), 15), 'seat': (tuple(EYE), (0, 3, 2.2), 18), 'aft': ((0, 1.3, 2.72), (0.2, -2, 2.2), 15),
        'left': ((0.9, -0.3, 2.72), (-2.3, -0.4, 2.3), 15), 'right': ((-0.9, -0.3, 2.72), (2.3, -0.4, 2.1), 15),
    }
    # (more views, asked for from outside: SHIP_VIEWS="name=x,y,z>tx,ty,tz@lens;...", in the builder's own directions)
    extra = []
    for spec in filter(None, os.environ.get('SHIP_VIEWS', '').split(';')):
        nm, rest = spec.split('='); frm, rest = rest.split('>'); to, lens = (rest.split('@') + ['20'])[:2]
        views[nm.strip()] = (tuple(map(float, frm.split(','))), tuple(map(float, to.split(','))), float(lens)); extra.append(nm.strip())
    want = [a for a in ARGS if a in views] + extra or list(views)
    for name in want:
        pos, to, lens = views[name]
        cam.matrix_world = aim(pos, Vector(pos) * 2 - Vector(to)); cd.lens = lens; cd.clip_start = 0.03
        scene.render.filepath = os.path.join(OUT, 'prev-' + (PTAG + '-' if PTAG else '') + name + '.jpg')
        bpy.ops.render.render(write_still=True)
    bpy.data.objects.remove(go); bpy.data.objects.remove(so)

W = 2048
if 'bake' in ARGS:
    import numpy as np

    def fatten(o, least=2.4):
        """
        No patch of the unwrapping may be narrower than a few dots of the picture: a name plate or a wire that falls
        between the dots is given no light at all, and comes out black. Each patch too small is widened about its
        own middle (the room left between patches is more than they grow by).
        """
        me = o.data; n = len(me.loops)
        uv = np.empty(n * 2, np.float32); me.uv_layers['UVMap'].data.foreach_get('uv', uv); uv = uv.reshape(n, 2)
        lv = np.empty(n, np.int32); me.loops.foreach_get('vertex_index', lv)
        # (corners at the same point of the thing and the same place in the picture are one; a face joins its corners)
        ids = {}; node = np.empty(n, np.int64)
        q = np.round(uv * 65536).astype(np.int64)
        for i in range(n):
            node[i] = ids.setdefault((int(lv[i]), int(q[i, 0]), int(q[i, 1])), len(ids))
        parent = list(range(len(ids)))
        def find(a):
            while parent[a] != a: parent[a] = parent[parent[a]]; a = parent[a]
            return a
        for pl in me.polygons:
            r0 = find(int(node[pl.loop_start]))
            for k in range(pl.loop_start + 1, pl.loop_start + pl.loop_total):
                r1 = find(int(node[k]))
                if r1 != r0: parent[r1] = r0
        root = np.array([find(int(a)) for a in node], np.int64)
        _, isl = np.unique(root, return_inverse=True); m = isl.max() + 1
        lo = np.full((m, 2), 9.0, np.float32); hi = np.full((m, 2), -9.0, np.float32)
        np.minimum.at(lo, isl, uv); np.maximum.at(hi, isl, uv)
        mid = (lo + hi) / 2; ext = hi - lo; want = least / W
        grow = np.where(ext < want, want / np.maximum(ext, 1e-7), 1.0)
        flat = ext < 1e-7                                    # (a patch with no width at all is spread a little by hand)
        out = mid[isl] + (uv - mid[isl]) * grow[isl]
        if flat.any():
            jit = (np.arange(n) % 3 - 1).astype(np.float32)[:, None] * (want / 2)
            out = np.where(flat[isl], mid[isl] + jit, out)
        out = np.clip(out, 0.0, 1.0)
        me.uv_layers['UVMap'].data.foreach_set('uv', out.astype(np.float32).ravel())
        print('patches', o.name, int(m), 'widened', int(((ext < want).any(axis=1)).sum()))
    for o in (hull_ob, room_ob):
        for x in bpy.context.view_layer.objects: x.select_set(x is o)
        bpy.context.view_layer.objects.active = o
        bpy.ops.object.mode_set(mode='EDIT'); bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.uv.smart_project(angle_limit=rad(66), island_margin=0.0015, area_weight=0.0, correct_aspect=True, scale_to_bounds=False)
        bpy.ops.object.mode_set(mode='OBJECT')
        fatten(o)
    glass_ob.hide_render = True
    if visor_ob: visor_ob.hide_render = True      # (it stands at the origin, under the engine: it is no part of the ship's light)
    ramp_ob.matrix_world = HINGE @ R(-pi / 2, 'X')
    scene.cycles.samples = int(os.environ.get('BAKE_SAMPLES', 1024)); scene.cycles.use_denoising = True
    scene.render.bake.margin = 6
    world.light_settings.distance = 0.3
    def px(img):
        a = np.empty(W * W * 4, np.float32); img.pixels.foreach_get(a); return a.reshape(W, W, 4)
    def soften(a):
        # (what a bake leaves is grainy: each place is evened with its neighbours)
        k = np.array([1, 4, 6, 4, 1], np.float32) / 16
        for ax in (0, 1):
            p_ = np.pad(a, [(2, 2) if i == ax else (0, 0) for i in range(a.ndim)], mode='edge')
            a = sum(k[i] * np.take(p_, range(i, i + a.shape[ax]), axis=ax) for i in range(5))
        return a
    def save(arr, path):
        out = bpy.data.images.new('o', W, W, alpha=False); out.colorspace_settings.name = 'Non-Color'
        full = np.ones((W, W, 4), np.float32); full[..., :3] = arr
        out.pixels.foreach_set(full.ravel()); out.filepath_raw = path; out.file_format = 'PNG'; out.save(); bpy.data.images.remove(out)
        # (kept as WebP, an eighth the size; ffmpeg does it)
        import subprocess
        if subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', path, '-c:v', 'libwebp', '-quality', '94', '-compression_level', '6', path[:-4] + '.webp']).returncode == 0: os.remove(path)
    for o in (hull_ob, room_ob):
        for x in bpy.context.view_layer.objects: x.select_set(x is o)
        bpy.context.view_layer.objects.active = o
        got = {}
        for kind in ('sky', 'lamp', 'ao'):
            img = bpy.data.images.new(o.name + '_' + kind, W, W, alpha=False, float_buffer=True)
            mats[o.name].node_tree.nodes['Bake'].image = img
            switches(kind == 'lamp', False)
            bg.inputs['Color'].default_value = (1, 1, 1, 1); bg.inputs['Strength'].default_value = 1.0 if kind == 'sky' else 0.0
            if kind == 'ao': bpy.ops.object.bake(type='AO', margin=6, use_clear=True)
            else: bpy.ops.object.bake(type='DIFFUSE', pass_filter={'DIRECT', 'INDIRECT'}, margin=6, use_clear=True)
            got[kind] = soften(soften(px(img)[..., :3])); print('baked', o.name, kind, float(got[kind][..., :3].mean()), float(got[kind][..., :3].max()))
            bpy.data.images.remove(img)
        save(np.sqrt(np.clip(got['lamp'][..., :3] / 4.0, 0, 1)), os.path.join(PUBLIC, o.name + '-lamp.png'))
        sky_l = got['sky'][..., :3].mean(axis=2)
        save(np.stack([np.sqrt(np.clip(sky_l, 0, 1)), np.clip(got['ao'][..., 0], 0, 1), np.zeros_like(sky_l)], axis=2), os.path.join(PUBLIC, o.name + '-sky.png'))
    glass_ob.hide_render = False
    if visor_ob: visor_ob.hide_render = False
    bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, 'ship.blend'))

if 'export' in ARGS:
    ramp_ob.matrix_world = HINGE
    moving = [take(room_ob, 'stick', 'stick', T(*cockpit.STICK)), take(room_ob, 'lever_lift', 'lever_lift', T(*cockpit.QUAD)), take(room_ob, 'lever_push', 'lever_push', T(*cockpit.QUAD))]
    # (the suit and its helmet, which are not there when they are being worn; and what is seen from inside the helmet)
    moving += [x for x in (take(room_ob, 'suit', 'suit'), visor_ob) if x]
    if SCREEN_HINGE is not None: moving.append(take(room_ob, 'screen', 'screen', T(*SCREEN_HINGE)))
    moving = [x for x in moving if x]
    # (where each thing that moves is hung: packing the file moves a piece's own origin, so the game is told)
    for name, M in (('pivot_ramp', HINGE), ('pivot_stick', T(*cockpit.STICK)), ('pivot_lever_lift', T(*cockpit.QUAD)), ('pivot_lever_push', T(*cockpit.QUAD))) + ((('pivot_screen', T(*SCREEN_HINGE)),) if SCREEN_HINGE is not None else ()):
        e = bpy.data.objects.new(name, None); e.matrix_world = M; COL['aux'].objects.link(e); moving.append(e)
    # (and how far round the landing glass swings to lie down: told as a place, which packing leaves alone)
    if SCREEN_HINGE is not None:
        e = bpy.data.objects.new('screen_swing', None); e.matrix_world = T(cockpit.SCREEN_SWING, 0, 0); COL['aux'].objects.link(e); moving.append(e)
    for x in bpy.context.view_layer.objects: x.select_set(x in (hull_ob, room_ob, ramp_ob, glass_ob, eye) or x in faces or x in moving)
    for o in (hull_ob, room_ob, ramp_ob, glass_ob, *faces, *moving):
        if o.data: o.data.materials.clear()
    bpy.ops.export_scene.gltf(filepath=os.path.join(PUBLIC, 'ship.glb'), export_format='GLB', use_selection=True, export_yup=True, export_apply=False,
                              export_materials='NONE', export_vertex_color='ACTIVE', export_active_vertex_color_when_no_material=True, export_all_vertex_colors=False, export_normals=True, export_extras=False)
    print('exported', os.path.getsize(os.path.join(PUBLIC, 'ship.glb')))
    # packed small (a quarter the size), if the tool for it can be had: https://gltf-transform.dev (MIT)
    import subprocess, shutil
    out = os.path.join(PUBLIC, 'ship.glb'); raw = os.path.join(OUT, 'ship.raw.glb'); shutil.move(out, raw)
    r = subprocess.run('npx --yes @gltf-transform/cli@4 meshopt "%s" "%s" --level medium --quantize-position 14 --quantize-normal 10 --quantize-texcoord 16 --quantize-color 12' % (raw, out), shell=True, capture_output=True, text=True)
    if r.returncode == 0 and os.path.exists(out): print('packed', os.path.getsize(out))
    else: shutil.copy(raw, out); print('not packed:', (r.stderr or r.stdout)[-300:])
