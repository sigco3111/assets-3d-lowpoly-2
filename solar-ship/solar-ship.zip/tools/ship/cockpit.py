# The pilot's place: the desk under the window and everything on it, the seat, what hangs over the window.
#
# Everything on the desk is a thing of its own with a job, turned to face whoever sits in the seat. In the middle
# lies the landing glass, face down, its back a part of the desk: it stands up on its hinge only when the ship is
# coming down (the game swings it), so the middle pane is clear to the sill the rest of the time. The six small
# lamps that say how things stand are on the two posts either side of that pane, where nothing ever hides them.
# The round chart glass is to the left; the dials to the right, with needles that really move; the push glass, a
# cage of beads with a small thruster on the end of each arm, which light as that thruster burns; a stick under
# the left hand and two levers under the right, which move as the ship is flown; switches, a wireless, a lamp, a mug.
from dims import *
from math import degrees

zd = lambda r: 1.70 + (r - 1.84) * 0.357                       # the height of the desk's top, by how far out


def desk(th, r, lift=0.0):
    """A frame lying on the desk's top: +Z out of it, +Y up its slope toward the window."""
    return at(th, r, zd(r)) @ R(rad(19.6), 'X') @ T(0, 0, lift)


def case(M, w, h, d, col=None, bevel=0.022, back=0.0):
    """The box of an instrument behind its face: w wide, h tall, d deep."""
    part(box(w, d, h), col or ENAMEL, 'in', M @ T(0, d / 2 + 0.002 + back, 0), bevel=bevel, seg=3, gloss=0.28, jit=0.02)


def frame(M, w, h, t=0.03, d=0.014, col=None, mat=None):
    """Four bars round a face w by h."""
    for x, z, sx, sz in ((0, h / 2 + t / 2, w + 2 * t, t), (0, -h / 2 - t / 2, w + 2 * t, t), (-w / 2 - t / 2, 0, t, h), (w / 2 + t / 2, 0, t, h)):
        part(box(sx, d, sz), col or RUBBER, 'in', M @ T(x, -d / 2 + 0.002, z), bevel=0.005, mat=mat, gloss=0.3)


def build():
    count = lambda: sum(len(o.data.polygons) for o in COL['in'].objects)
    n0 = count(); each = {}
    for make in (desk_body, landing_glass, post_lamps, chart_unit, dials_unit, push_glass, stick, levers, switches, wireless, odds, seat, overhead):
        n1 = count(); make(); each[make.__name__] = count() - n1
    print('cockpit faces', count() - n0, each)


# ------------------------------------------------------------------------------------------------------ the desk
def desk_body():
    part(lathe([(1.84, 1.70), (2.40, 1.90), (2.40, ZF), (2.10, ZF), (1.84, 1.56)], 24, rad(-59), rad(59), close=True), WOOD, 'in', bevel=0.012)
    # its top: a mat of dark leather let into it, a brass rail along the front, a lip
    part(lathe([(1.90, zd(1.90) + 0.004), (2.28, zd(2.28) + 0.004), (2.28, zd(2.28) - 0.004), (1.90, zd(1.90) - 0.004)], 30, rad(-56), rad(56), close=True), GREEN_D, 'in', bevel=0.002, jit=0.02)
    part(tube([P(rad(a), 1.832, 1.712) for a in range(-58, 59, 4)], 0.014, 8, 1), BRASS, 'in', bevel=0, gloss=0.6)
    for a in range(-56, 57, 16):
        part(cyl(0.009, 0.03, 8), BRASS, 'in', T(*P(rad(a), 1.842, 1.698)), bevel=0, gloss=0.6)
    # the front of it: three doors with their hinges and pulls, a bar for the feet
    for a in (-44, -22, 0, 22, 44):
        Mh = at(rad(a), 1.97, 1.305) @ R(rad(27), 'X')
        part(box(0.62, 0.016, 0.46), WOOD, 'in', Mh @ T(0, -0.004, 0), bevel=0.006, jit=0.05)
        part(box(0.5, 0.012, 0.34), WOOD_D, 'in', Mh @ T(0, -0.013, 0), bevel=0.01)
        part(tube([(-0.05, -0.02, 0.12), (-0.05, -0.05, 0.12), (0.05, -0.05, 0.12), (0.05, -0.02, 0.12)], 0.006, 6, 3), BRASS, 'in', Mh, bevel=0, gloss=0.6)
        for sx in (-1, 1):
            for z in (-0.15, 0.15): part(box(0.05, 0.008, 0.025), BRASS, 'in', Mh @ T(sx * 0.28, -0.014, z), bevel=0.003, gloss=0.6)
    part(tube([P(rad(a), 1.86, ZF + 0.16) for a in range(-22, 23, 4)], 0.018, 8, 1), BRASS, 'in', bevel=0, gloss=0.6)
    for a in (-22, 22): part(tube([P(rad(a), 1.86, ZF + 0.16), P(rad(a), 2.0, ZF + 0.16)], 0.014, 6, 1), IRON, 'in', bevel=0, gloss=0.4)
    # a shoe of brass at the foot of every window post, screwed down
    for k in (0, 1, 4, 5):
        Ms = at(rad(-60 + 24 * k), RO - 0.19, SILL - 0.075)
        part(box(0.12, 0.05, 0.03), BRASS, 'in', Ms, bevel=0.006, gloss=0.6)
        for sx in (-1, 1): part(cyl(0.006, 0.006, 6), STEEL, 'in', Ms @ T(sx * 0.04, -0.01, 0.017), bevel=0, gloss=0.6)
    # cables along the sill, in their clips
    part(tube([P(rad(a), 2.300, zd(2.300) + 0.0072) for a in range(-57, 58, 3)], 0.007, 6, 1), RUBBER, 'in', bevel=0)
    part(tube([P(rad(a), 2.2885, zd(2.2885) + 0.0086) for a in range(-57, 58, 3)], 0.0045, 5, 1), '#7a2f22', 'in', bevel=0, mat='rubber')
    for a in range(-54, 55, 12):
        if a % 24 == 0: continue
        part(tube([P(rad(a), 2.276, zd(2.276) + 0.004), P(rad(a), 2.283, zd(2.283) + 0.013), P(rad(a), 2.297, zd(2.297) + 0.0165), P(rad(a), 2.311, zd(2.311) + 0.011), P(rad(a), 2.318, zd(2.318) + 0.001)], 0.0024, 5, 1), STEEL, 'in', bevel=0, gloss=0.6)


# ------------------------------------------------------------------------------ the landing glass, which folds away
# It is built standing, as it is when it is up, leaning back to meet the pilot's eye squarely. Everything that
# moves with it is tagged 'screen'; the game lays it face down on the desk (SCREEN_SWING round +X through
# SCREEN_HINGE) whenever nobody is landing, and build.py shows that in a preview with SHIP_SCREEN=down.
GLASS_R = 2.262                                                 # how far out its hinge stands on the desk
GLASS_TILT = rad(6.0)                                           # how far it leans back when it is up
SCREEN_HINGE = Vector((0, GLASS_R, zd(GLASS_R))) + Vector((0, -sin(rad(19.6)), cos(rad(19.6)))) * 0.040
SCREEN_SWING = rad(109.6) + GLASS_TILT                          # from standing to lying, top edge toward the pilot
BOW_X = 0.345                                                   # the two brass bows it swings between


class moving:
    """Everything made inside is a part of a thing that moves (part's tag), whoever makes it."""
    def __init__(self, tag): self.tag = tag

    def __enter__(self):
        import dims
        self.old = dims.part
        def tagged(*a, **k): k.setdefault('tag', self.tag); return self.old(*a, **k)
        dims.part = tagged; globals()['part'] = tagged

    def __exit__(self, *e):
        import dims
        dims.part = self.old; globals()['part'] = self.old


def landing_glass():
    ML = T(*SCREEN_HINGE) @ R(-GLASS_TILT, 'X')                 # the lid's own frame: +Z up it, -Y out of its glass
    BACK = R(pi, 'X')                                           # turns a print to lie on its back, to be read from the seat when it is down
    W, Hh, Z0 = 0.60, 0.41, 0.012
    zc, zp, top = Z0 + Hh / 2, Z0 + 0.052 + 0.165, Z0 + Hh
    part(plane(0.52, 0.33), '#000000', 'face', ML @ T(0, -0.0222, zp), bevel=0, name='face_main')
    with moving('screen'):
        # ---- the case, of cream enamel; round the glass four bars of dark rubber; brass at its corners
        part(box(W, 0.046, Hh), ENAMEL, 'in', ML @ T(0, 0.002, zc), bevel=0.009, seg=3, gloss=0.28, jit=0.02)
        t = 0.018
        for x, z, sx, sz in ((0, zp + 0.165 + t / 2, 0.52 + 2 * t, t), (0, zp - 0.165 - t / 2, 0.52 + 2 * t, t), (-0.26 - t / 2, zp, t, 0.33), (0.26 + t / 2, zp, t, 0.33)):
            part(box(sx, 0.005, sz), RUBBER, 'in', ML @ T(x, -0.0225, z), bevel=0.002, gloss=0.3)
        for sx in (-1, 1):
            for z in (Z0 + 0.01, top - 0.01):
                part(box(0.024, 0.05, 0.024), BRASS, 'in', ML @ T(sx * (W / 2 - 0.01), 0.002, z), bevel=0.003, seg=1, gloss=0.6)
                part(cyl(0.0035, 0.0012, 6), STEEL, 'in', ML @ T(sx * (W / 2 - 0.01), -0.0232, z) @ YA, bevel=0, gloss=0.6)
            for z in (zp - 0.09, zp + 0.09): screw(ML @ T(sx * 0.289, -0.021, z), 0.004)
        # (under the glass, on its chin: a band of stripes and the two names of what it shows)
        part(box(0.2, 0.002, 0.012), RED, 'in', ML @ T(-0.13, -0.0216, Z0 + 0.016), bevel=0, mat='stripe')
        label('BELOW', ML @ T(0.085, -0.0226, Z0 + 0.016), 0.058)
        label('AHEAD', ML @ T(0.165, -0.0226, Z0 + 0.016), 0.058)
        # ---- its right side: two knobs; its left: slots for its heat; a pin each side, which rides in a bow
        for z, col, turn in ((0.2, RUBBER, 0.6), (0.26, RED, -0.8)):
            knob(ML @ T(W / 2, 0.004, z) @ R(pi / 2, 'Z'), 0.013, 0.014, col, turn=turn)
        for k in range(6): part(box(0.003, 0.03, 0.007), DARK, 'in', ML @ T(-W / 2 - 0.0002, 0.003, 0.15 + 0.02 * k), bevel=0, mat='rubber')
        for sx in (-1, 1):
            part(tube([(sx * (W / 2 - 0.004), 0, 0.13), (sx * (BOW_X + 0.011), 0, 0.13)], 0.0036, 6, 1), STEEL, 'in', ML, bevel=0, gloss=0.6)
            part(cyl(0.011, 0.007, 10), BRASS, 'in', ML @ T(sx * (BOW_X + 0.0085), 0, 0.13) @ R(pi / 2, 'Y'), bevel=0.002, seg=1, gloss=0.6)
            part(box(0.004, 0.026, 0.006), BRASS, 'in', ML @ T(sx * (BOW_X + 0.013), 0, 0.13) @ R(0.6, 'X'), bevel=0.001, seg=1, gloss=0.6)
            part(cyl(0.0085, 0.003, 10), BRASS, 'in', ML @ T(sx * (W / 2 + 0.0012), 0, 0.13) @ R(pi / 2, 'Y'), bevel=0, gloss=0.6)
        # ---- its back, which is what is seen of it nearly all the time: a panel let into it, ribbed where the heat
        # comes out; a maker's plate; a bail to lift it by; a round vent; a band of stripes along its free edge
        part(box(0.52, 0.004, 0.335), '#55635a', 'in', ML @ T(0, 0.0265, zc + 0.002), bevel=0.003, seg=1, mat='enamel', gloss=0.28, jit=0.02)
        for k in range(7): part(box(0.2, 0.0055, 0.011), '#55635a', 'in', ML @ T(-0.13, 0.0302, 0.066 + 0.026 * k), bevel=0.0025, seg=1, mat='enamel', gloss=0.28, jit=0.02)
        for sx in (-1, 1):
            for z in (zc - 0.155, zc + 0.16): part(ball(0.0045, 6, 4, s=(1, 0.5, 1)), BRASS, 'in', ML @ T(sx * 0.248, 0.0285, z), bevel=0, gloss=0.6)
        for i in range(9):
            for z in (zc - 0.155, zc + 0.16):
                if 0 < i < 8: part(ball(0.0036, 6, 4, s=(1, 0.5, 1)), BRASS, 'in', ML @ T(-0.248 + 0.062 * i, 0.0285, z), bevel=0, gloss=0.6)
        for i in range(1, 5):
            for sx in (-1, 1): part(ball(0.0036, 6, 4, s=(1, 0.5, 1)), BRASS, 'in', ML @ T(sx * 0.248, 0.0285, zc - 0.155 + 0.063 * i), bevel=0, gloss=0.6)
        label('No. 2', ML @ T(-0.185, 0.0298, 0.293) @ BACK, 0.055)
        part(box(0.212, 0.003, 0.061), BRASS, 'in', ML @ T(0.02, 0.0296, 0.293), bevel=0.0012, seg=1, gloss=0.5)
        label('c3_glass', ML @ T(0.02, 0.0322, 0.293) @ BACK, 0.2)
        for sx in (-1, 1): part(cyl(0.0035, 0.0015, 6), STEEL, 'in', ML @ T(0.02 + sx * 0.1, 0.0318, 0.293) @ YA, bevel=0, gloss=0.6)
        part(box(0.54, 0.003, 0.014), RED, 'in', ML @ T(0, 0.0262, top - 0.022), bevel=0, mat='stripe')
        # (the bail, folded down flat, in two lugs; leather round its middle)
        for sx in (-1, 1):
            part(box(0.022, 0.012, 0.022), BRASS, 'in', ML @ T(sx * 0.1, 0.0335, 0.372), bevel=0.003, seg=1, gloss=0.6)
            part(cyl(0.004, 0.028, 6), STEEL, 'in', ML @ T(sx * 0.1, 0.0345, 0.372) @ R(pi / 2, 'Y'), bevel=0, gloss=0.6)
        part(tube([(-0.086, 0.0345, 0.372), (-0.086, 0.0355, 0.345), (-0.07, 0.0355, 0.334), (0.07, 0.0355, 0.334), (0.086, 0.0355, 0.345), (0.086, 0.0345, 0.372)], 0.0048, 6, 1), BRASS, 'in', ML, bevel=0, gloss=0.6)
        part(tube([(-0.05, 0.0355, 0.334), (0.05, 0.0355, 0.334)], 0.0072, 8, 1), LEATHER, 'in', ML, bevel=0, jit=0.03)
        # (the vent: a ring of brass, bars across the dark of it)
        Mv = ML @ T(0.15, 0.0285, 0.135) @ R(-pi / 2, 'X')
        part(lathe([(0.046, 0), (0.058, 0), (0.058, 0.004), (0.05, 0.0065), (0.046, 0.004)], 24, close=True), BRASS, 'in', Mv, bevel=0, gloss=0.6)
        part(cyl(0.047, 0.002, 20), '#141418', 'in', Mv @ T(0, 0, 0.0005), bevel=0, mat='rubber')
        for k in range(5):
            x = -0.03 + 0.015 * k
            part(box(0.0045, 2 * sqrt(0.046 ** 2 - x * x), 0.003), BRASS, 'in', Mv @ T(x, 0, 0.003), bevel=0, gloss=0.6)
        for k in range(4): part(cyl(0.0032, 0.002, 6), STEEL, 'in', Mv @ R(pi / 4 + k * pi / 2, 'Z') @ T(0.052, 0, 0.0052), bevel=0, gloss=0.6)
        # (what its two knobs are for, by them; a lead from the hinge up to a small box under the vent)
        label('BRIGHT', ML @ T(0.232, 0.0298, 0.26) @ BACK, 0.05)
        label('SCOPE', ML @ T(0.232, 0.0298, 0.2) @ BACK, 0.05)
        part(box(0.07, 0.014, 0.04), ENAMEL, 'in', ML @ T(0.04, 0.0335, 0.05), bevel=0.004, seg=2, gloss=0.28, jit=0.02)
        part(tube([(0.04, 0.034, 0.032), (0.04, 0.032, 0.0145)], 0.0055, 6, 1), STEEL, 'in', ML, bevel=0, gloss=0.5)
        part(tube([(0.073, 0.0345, 0.05), (0.098, 0.0345, 0.06), (0.11, 0.0335, 0.093)], 0.0045, 6, 3), STEEL, 'in', ML, bevel=0, gloss=0.5)
        for sx in (-1, 1): part(cyl(0.003, 0.002, 6), STEEL, 'in', ML @ T(0.04 + sx * 0.026, 0.0412, 0.05) @ YA, bevel=0, gloss=0.6)
        # (a strike on its free edge, where the catch on the desk takes it)
        part(box(0.05, 0.03, 0.003), BRASS, 'in', ML @ T(0, 0.002, top + 0.001), bevel=0.001, seg=1, gloss=0.6)
        # ---- its half of the hinge: two knuckles, each on a lug from its foot
        for sx in (-1, 1):
            part(tube([(sx * 0.115, 0, 0), (sx * 0.208, 0, 0)], 0.0108, 10, 1), BRASS, 'in', ML, bevel=0, gloss=0.6)
            part(box(0.093, 0.028, 0.009), BRASS, 'in', ML @ T(sx * 0.1615, 0.013, 0.0085), bevel=0.002, seg=1, gloss=0.6)
            part(box(0.093, 0.004, 0.04), BRASS, 'in', ML @ T(sx * 0.1615, 0.027, 0.032), bevel=0.0015, seg=1, gloss=0.6)
            for dx in (-0.03, 0.03): part(cyl(0.0038, 0.002, 6), STEEL, 'in', ML @ T(sx * 0.1615 + dx, 0.0298, 0.04) @ YA, bevel=0, gloss=0.6)

    # ---- what does not move: the hinge's pin and the knuckles it stands in, each on a foot screwed to the desk
    Mh = T(*SCREEN_HINGE); Mw = desk(0, GLASS_R, 0)             # (Mw: lying on the desk under the hinge, +Y up the slope)
    part(tube([(-0.268, 0, 0), (0.268, 0, 0)], 0.0045, 8, 1), STEEL, 'in', Mh, bevel=0, gloss=0.6)
    for x0, x1 in ((-0.262, -0.214), (0.214, 0.262), (-0.05, 0.05)):
        xm, w = (x0 + x1) / 2, x1 - x0
        part(tube([(x0, 0, 0), (x1, 0, 0)], 0.0108, 10, 1), BRASS, 'in', Mh, bevel=0, gloss=0.6)
        part(box(w, 0.021, 0.044), BRASS, 'in', Mw @ T(xm, 0, 0.019), bevel=0.003, seg=1, gloss=0.6)
        Mfoot = desk(atan2(xm, GLASS_R), hypot(xm, GLASS_R), 0.006)
        part(box(w + 0.03, 0.04, 0.004), BRASS, 'in', Mfoot, bevel=0.0015, seg=1, gloss=0.6)
        for sx in (-1, 1): part(cyl(0.0035, 0.002, 6), STEEL, 'in', Mfoot @ T(sx * (w / 2 + 0.007), 0, 0.0028), bevel=0, gloss=0.6)
    for sx in (-1, 1): part(ball(0.0075, 8, 6), BRASS, 'in', Mh @ T(sx * 0.27, 0, 0), bevel=0, gloss=0.6)
    # ---- the two bows it swings between: each a slotted hoop of brass from the desk over to the sill, with a stop
    # where the glass stands and one where it lies
    Hy, Hz = SCREEN_HINGE.y, SCREEN_HINGE.z
    bow = lambda deg, r=0.13: Vector((0, Hy + r * cos(rad(deg)), Hz + r * sin(rad(deg))))
    up, lie = 90 - degrees(GLASS_TILT), 199.6
    for sx in (-1, 1):
        Mq = T(sx * BOW_X, Hy, Hz) @ R(pi / 2, 'Y')
        for r0, r1 in ((0.1205, 0.1262), (0.1338, 0.1395)):
            part(lathe([(r0, -0.002), (r1, -0.002), (r1, 0.002), (r0, 0.002)], 44, rad(-(lie + 9)), rad(-38), close=True), BRASS, 'in', Mq, bevel=0, gloss=0.6, sharp=30)
        for deg in (lie + 9, lie + 5.5, up - 5.5, 38):
            p = bow(deg); p.x = sx * BOW_X
            part(box(0.006, 0.008, 0.021), BRASS, 'in', T(*p) @ R(rad(deg - 90), 'X'), bevel=0.001, seg=1, gloss=0.6)
        # (its fore foot on the desk, its after foot on the sill)
        p = bow(lie + 9); p.x = sx * BOW_X
        part(tube([p, Vector((p.x, p.y - 0.004, zd(hypot(p.x, p.y - 0.004)) + 0.004))], 0.0065, 8, 1), BRASS, 'in', bevel=0, gloss=0.6)
        part(cyl(0.017, 0.004, 10), BRASS, 'in', desk(atan2(p.x, p.y - 0.004), hypot(p.x, p.y - 0.004), 0.006), bevel=0.001, seg=1, gloss=0.6)
        p = bow(38); p.x = sx * BOW_X
        part(tube([p, Vector((p.x, p.y + 0.006, SILL + 0.021))], 0.0065, 8, 1), BRASS, 'in', bevel=0, gloss=0.6)
        part(cyl(0.017, 0.004, 10), BRASS, 'in', T(p.x, p.y + 0.006, SILL + 0.0215), bevel=0.001, seg=1, gloss=0.6)
        # (marks along it, cut and filled: every ten degrees of the way up)
        for k in range(1, 11):
            deg = lie - k * (lie - up) / 11; p = bow(deg, 0.1301); p.x = sx * (BOW_X - 0.0021)
            part(box(0.0006, 0.0016, 0.0075), DARK, 'in', T(*p) @ R(rad(deg - 90), 'X'), bevel=0, mat='paint')
    # ---- where it lies: two stops of rubber under its free corners, a catch on the rail for its strike
    for sx in (-1, 1):
        q = Mw @ Vector((sx * 0.262, -0.404, 0)); rq = hypot(q.x, q.y)
        dn = (Mw.inverted() @ Vector((q.x, q.y, zd(rq)))).z        # how far the desk stands over the flat of its middle, here
        Ms = desk(atan2(q.x, q.y), rq, 0)
        part(cyl(0.015, 0.002, 12), BRASS, 'in', Ms @ T(0, 0, 0.005), bevel=0, gloss=0.6)
        part(cyl(0.0115, 0.0055, 12), RUBBER, 'in', Ms @ T(0, 0, 0.0148 - dn - 0.00275), bevel=0.001, seg=1)
    part(box(0.04, 0.012, 0.034), BRASS, 'in', Mw @ T(0, -0.4335, 0.019), bevel=0.003, seg=1, gloss=0.6)
    part(cyl(0.006, 0.006, 8), BRASS, 'in', Mw @ T(0, -0.4335, 0.039), bevel=0.001, seg=1, gloss=0.6)
    part(box(0.036, 0.007, 0.004), BRASS, 'in', Mw @ T(0, -0.4335, 0.0435) @ R(0.12, 'Z'), bevel=0.001, seg=1, gloss=0.6)
    # ---- and under it, seen only when it is up: a shallow tray it shuts on, lined with red baize, with what the
    # pilot keeps there
    part(box(0.5, 0.3, 0.0012), '#7a2f22', 'in', Mw @ T(0, -zp, 0.0109), bevel=0, mat='cloth', jit=0.03)
    for x, y, wx, wy in ((0, -zp - 0.156, 0.524, 0.012), (0, -zp + 0.156, 0.524, 0.012), (-0.256, -zp, 0.012, 0.3), (0.256, -zp, 0.012, 0.3)):
        part(box(wx, wy, 0.0128), WOOD_D, 'in', Mw @ T(x, y, 0.0074), bevel=0.0015, seg=1)
    for sx in (-1, 1):
        for sy in (-1, 1): part(box(0.02, 0.02, 0.0012), BRASS, 'in', Mw @ T(sx * 0.256, -zp + sy * 0.156, 0.0136), bevel=0, gloss=0.6)
    Mc = Mw @ T(-0.1, -zp - 0.01, 0) @ R(0.05, 'Z')
    part(box(0.246, 0.126, 0.0012), '#e3d8ba', 'in', Mc @ T(0, 0, 0.0121), bevel=0, mat='paper')
    label('c3_card', Mc @ T(0, 0, 0.0139) @ FLAT, 0.24)
    for sx in (-1, 1): part(box(0.016, 0.016, 0.001), BRASS, 'in', Mc @ T(sx * 0.118, 0.058, 0.0144) @ R(pi / 4, 'Z'), bevel=0, gloss=0.6)
    Mp = Mw @ T(0.145, -zp + 0.045, 0) @ R(-0.18, 'Z')
    part(box(0.1, 0.077, 0.001), '#efe6c8', 'in', Mp @ T(0, 0, 0.012), bevel=0, mat='paper')
    label('photo_a', Mp @ T(0, 0, 0.0137) @ FLAT, 0.092)
    Mp = Mw @ T(0.155, -zp - 0.075, 0) @ R(0.12, 'Z')
    part(box(0.094, 0.05, 0.001), '#e6d9b4', 'in', Mp @ T(0, 0, 0.012), bevel=0, mat='paper')
    label('tag_c', Mp @ T(0, 0, 0.0137) @ FLAT, 0.09)
    # ---- its lead: out of the end of the hinge, back to a small box on the cables along the sill
    jx = 0.336; Mj = at(atan2(jx, 2.276), 2.296, zd(2.296) + 0.022)
    part(box(0.05, 0.036, 0.046), '#55635a', 'in', Mj, bevel=0.005, seg=2, mat='enamel', gloss=0.28)
    part(box(0.038, 0.004, 0.032), BRASS, 'in', Mj @ T(0, -0.019, 0), bevel=0.0015, seg=1, gloss=0.5)
    for sz in (-1, 1): screw(Mj @ T(0, -0.021, sz * 0.01), 0.003)
    a = Mh @ Vector((0.277, 0, 0)); b = Mj @ Vector((-0.01, -0.019, 0.004))
    # (it keeps to the line of the hinge until it is clear of the glass's corner, which turns about it)
    a2 = Mh @ Vector((0.3085, 0, 0))
    part(tube([a, a2], 0.0055, 8, 1), STEEL, 'in', bevel=0, gloss=0.5)
    part(ball(0.0062, 8, 6), STEEL, 'in', T(*a2), bevel=0, gloss=0.5)
    part(tube([a2, a2 + Vector((0.006, 0.006, 0.008)), b + Vector((0.0, -0.016, 0.01)), b], 0.0055, 8, 4), STEEL, 'in', bevel=0, gloss=0.5)
    part(tube([b + Vector((0, -0.008, 0.002)), b + Vector((0, 0.003, 0))], 0.0082, 8, 1), BRASS, 'in', bevel=0, gloss=0.6)


# --------------------------------------------- the six lamps, low on the desk to the left of the landing glass
LAMPS_X, LAMPS_R = -0.525, 2.32


def post_lamps():
    """
    The lamps that say how things stand: six on one board of cream enamel that stands low on the far edge of the
    desk, leaning back, to the left of the landing glass (the thrusters' cage stands to its right): under the
    window, never in it. Two rows of three, each lamp with its name on a plate under it, and along the foot of the
    board the keys that go with them.
    """
    rows = ((('lit2', '#bfe6ff', 'LOCKED'), ('lit3', '#7dff8a', 'MATCH'), ('lit4', '#ff5a3c', 'TOO FAST')),
            (('lit0', '#7dff8a', 'RAMP'), ('lit1', '#ffc860', 'GROUND'), ('lit5', '#ffc860', 'LANDING')))
    c = Vector((LAMPS_X, sqrt(LAMPS_R ** 2 - LAMPS_X ** 2), zd(LAMPS_R) + 0.118))
    M = facing(c.x, c.y, c.z, 38)
    part(box(0.345, 0.018, 0.268), ENAMEL, 'in', M @ T(0, 0, -0.012), bevel=0.006, seg=2, gloss=0.28, jit=0.02)
    for z in (0.113, -0.138): part(box(0.345, 0.004, 0.009), RED, 'in', M @ T(0, -0.0078, z), bevel=0.001, seg=1, mat='stripe')
    for sx in (-1, 1):
        for z in (0.1, -0.124): screw(M @ T(sx * 0.163, -0.009, z), 0.0035)
    for r, row in enumerate(rows):
        z = 0.072 - 0.097 * r
        for k, (kind, col, name) in enumerate(row):
            x = (k - 1) * 0.108
            part(cyl(0.03, 0.003, 20), BRASS, 'in', M @ T(x, -0.0102, z) @ YA, bevel=0.001, seg=1, gloss=0.6)
            bead(M @ T(x, -0.0115, z), kind, col, 0.018)
            label(name, M @ T(x, -0.0102, z - 0.045), 0.096)
    for k, name in enumerate(('V  VIEW', 'R  LOCK', 'X  MATCH')): label(name, M @ T((k - 1) * 0.108, -0.0102, -0.108), 0.088)
    # (two feet of brass under it, and its lead away over the desk's edge)
    for sx in (-1, 1): part(box(0.03, 0.04, 0.012), BRASS, 'in', M @ T(sx * 0.13, 0.016, -0.145), bevel=0.003, gloss=0.6)
    part(tube([M @ Vector((-0.1, 0.012, -0.08)), M @ Vector((-0.13, 0.06, -0.12)), M @ Vector((-0.2, 0.1, -0.14))], 0.0035, 5, 3), RUBBER, 'in', bevel=0, mat='rubber')


# ------------------------------------------------------------------------------------ the chart glass, to the left
def chart_unit():
    c = P(rad(-22.5), 1.93, 1.925)
    Mc = facing(c.x, c.y, c.z, 27)
    part(plane(0.25, 0.25), '#000000', 'face', Mc, bevel=0, name='face_chart')
    part(cyl(0.178, 0.13, 36), BRASS, 'in', Mc @ T(0, 0.07, 0) @ YA, bevel=0.012, gloss=0.6)
    part(lathe([(0.119, 0), (0.186, 0), (0.19, 0.012), (0.175, 0.026), (0.124, 0.03), (0.119, 0.02)], 40, close=True), BRASS, 'in', Mc @ T(0, 0.006, 0) @ YA, bevel=0, gloss=0.6)
    # the hours marked round its rim, and four screws
    for k in range(24):
        a = k * pi / 12
        part(box(0.004, 0.003, 0.02 if k % 6 == 0 else 0.011), DARK, 'in', Mc @ R(a, 'Y') @ T(0, -0.0247, 0.156), bevel=0, mat='paint')
    part(lathe([(0.134, 0.0297), (0.1715, 0.0268), (0.1715, 0.0282), (0.134, 0.0311)], 40, close=True), ENAMEL, 'in', Mc @ T(0, 0.006, 0) @ YA, bevel=0, gloss=0.28, jit=0.02)
    part(box(0.012, 0.004, 0.012), '#a33a26', 'in', Mc @ T(0, -0.0214, 0.1805) @ R(pi / 4, 'Y'), bevel=0.001, seg=1, mat='enamel', gloss=0.4)
    for k in range(4): screw(Mc @ R(pi / 4 + k * pi / 2, 'Y') @ T(0, -0.021, 0.178), 0.005)
    # it swings in a fork, on a post
    for sx in (-1, 1):
        part(cyl(0.022, 0.03, 10), IRON, 'in', Mc @ T(sx * 0.192, 0.07, 0) @ R(pi / 2, 'Y'), bevel=0.004, gloss=0.4)
        part(tube([Mc @ Vector((sx * 0.205, 0.07, 0)), Mc @ Vector((sx * 0.205, 0.09, -0.12)), Mc @ Vector((sx * 0.1, 0.1, -0.2)), Mc @ Vector((0, 0.1, -0.215))], 0.014, 8, 3), IRON, 'in', bevel=0, gloss=0.4)
    base = Mc @ Vector((0, 0.1, -0.215))
    part(tube([base, Vector((base.x, base.y, zd(hypot(base.x, base.y))))], 0.02, 8, 1), IRON, 'in', bevel=0, gloss=0.4)
    part(cyl(0.05, 0.016, 14), BRASS, 'in', T(base.x, base.y, zd(hypot(base.x, base.y)) + 0.008), bevel=0.004, gloss=0.6)
    for k, col in enumerate((RUBBER, CREAM, RUBBER)): knob(Mc @ T(-0.06 + 0.06 * k, 0.012, -0.212) @ R(rad(20), 'X'), 0.014, 0.018, col, turn=k * 1.1)


# ------------------------------------------------------------------------------------------ the dials, to the right
DIALS_AT = 23.5


def dials_unit():
    c = P(rad(DIALS_AT), 1.93, 1.905)
    Md = facing(c.x, c.y, c.z, 27)
    case(Md, 0.36, 0.34, 0.12)
    part(box(0.33, 0.006, 0.31), '#3a4a44', 'in', Md @ T(0, -0.001, 0), bevel=0.003, mat='enamel', gloss=0.3)
    for k, name in enumerate(('speed', 'height', 'climb', 'clock')):
        x, z = (-0.084 if k % 2 == 0 else 0.084), (0.08 if k < 2 else -0.08)
        gauge(Md @ T(x, -0.004, z), 0.06, name)
    for sx in (-1, 1):
        for sz in (-1, 1): screw(Md @ T(sx * 0.165, 0, sz * 0.155), 0.006)
    foot = Md @ Vector((0, 0.07, -0.17))
    part(tube([foot, Vector((foot.x, foot.y, zd(hypot(foot.x, foot.y))))], 0.03, 10, 1), IRON, 'in', bevel=0, gloss=0.4)
    # further round, four smaller ones on a board
    c2 = P(rad(40.5), 2.02, 1.905)
    Mb = facing(c2.x, c2.y, c2.z, 30)
    part(box(0.46, 0.03, 0.15), WOOD, 'in', Mb @ T(0, 0.018, 0), bevel=0.008)
    part(box(0.43, 0.004, 0.12), BRASS, 'in', Mb @ T(0, 0.001, 0), bevel=0.002, gloss=0.5)
    for k, name in enumerate(('heat', 'air', 'pull', 'lean')):
        gauge(Mb @ T(-0.156 + 0.104 * k, -0.002, 0.0), 0.042, name)
    for sx in (-1, 1):
        foot = Mb @ Vector((sx * 0.18, 0.03, -0.075))
        part(tube([foot, Vector((foot.x, foot.y, zd(hypot(foot.x, foot.y))))], 0.012, 6, 1), BRASS, 'in', bevel=0, gloss=0.6)


# ------------------------------------------------------------------------------------------------- the push glass
PUSH_C = Vector((0.585, 2.08, 2.15))
PUSH_K = 1.15                                                   # how much larger than it was first made


def push_glass():
    """
    A cage of three brass rings with a hub in it and six arms, each a rod of beads ending in a small thruster: the
    ship's six thrusters, as they stand in the ship. As one burns (the game says which, and how hard) its throat and
    the drop of glass at its mouth light first, and then the beads of its arm, one by one, in toward the hub.
    """
    c = PUSH_C; M = T(*c); k = PUSH_K; Rr = 0.12 * k
    for Mr in (I4, R(pi / 2, 'X'), R(pi / 2, 'Y')):
        part(tube([(Rr * cos(i * pi / 28), Rr * sin(i * pi / 28), 0) for i in range(56)], 0.0036 * k, 6, 1, cyclic=True), BRASS, 'in', M @ Mr, bevel=0, gloss=0.7)
        # (a finer ring inside each, and four small studs where a hand would turn it)
        part(tube([(0.052 * k * cos(i * pi / 14), 0.052 * k * sin(i * pi / 14), 0) for i in range(28)], 0.0018 * k, 5, 1, cyclic=True), BRASS, 'in', M @ Mr, bevel=0, gloss=0.7)
        for j in range(4):
            a = pi / 4 + j * pi / 2
            part(ball(0.0055 * k, 8, 6), BRASS, 'in', M @ Mr @ T(Rr * cos(a), Rr * sin(a), 0), bevel=0, gloss=0.7)
    part(ball(0.019 * k, 14, 10), BRASS, 'in', M, bevel=0, gloss=0.7)
    for Mr in (I4, R(pi / 2, 'X')):
        part(lathe([(0.0205 * k, -0.004), (0.0228 * k, -0.004), (0.0228 * k, 0.004), (0.0205 * k, 0.004)], 16, close=True), COPPER, 'in', M @ Mr, bevel=0, gloss=0.6)
    n = 6
    # (a thruster, mouth outward along +Z: a chamber, a waist, a bell with a rolled lip and two hoops round it)
    bell = [(0.0052, 0.0), (0.0096, 0.002), (0.0102, 0.009), (0.0072, 0.0125), (0.0058, 0.016), (0.0082, 0.022), (0.0128, 0.03), (0.0182, 0.04), (0.0215, 0.0475),
            (0.0222, 0.049), (0.0205, 0.0492), (0.017, 0.041), (0.0116, 0.0305), (0.0068, 0.0222), (0.0044, 0.016), (0.0044, 0.0)]
    for kind, d in (('push_right', (1, 0, 0)), ('push_left', (-1, 0, 0)), ('push_fwd', (0, 1, 0)), ('push_back', (0, -1, 0)), ('push_up', (0, 0, 1)), ('push_down', (0, 0, -1))):
        d = Vector(d)
        part(tube([d * 0.016 * k, d * 0.121 * k], 0.0022 * k, 5, 1), STEEL, 'in', M, bevel=0, gloss=0.6)
        for i in range(n):
            part(ball((0.0078 - 0.0003 * i) * k, 10, 8), '#ff9a40', 'in', M @ T(*(d * (0.034 + 0.0145 * i) * k)), bevel=0, mat=kind, val=1 - i / n, jit=0, gloss=0.6)
        # where the arm goes through the rings: a collar, and beyond it the thruster
        Ma = aim(c + d * 0.1125 * k, c + d * 0.3)
        part(lathe([(0.0, 0.0), (0.0075 * k, 0.0), (0.0085 * k, 0.004 * k), (0.0085 * k, 0.009 * k), (0.0065 * k, 0.013 * k), (0.0, 0.013 * k)], 10), BRASS, 'in', Ma, bevel=0, gloss=0.7)
        Mb = Ma @ T(0, 0, 0.0125 * k)
        part(lathe(bell, 16, close=True), COPPER, 'in', Mb, bevel=0, gloss=0.6, jit=0.02)
        for z, r in ((0.031, 0.0138), (0.0405, 0.0188)):
            part(lathe([(r - 0.0004, z - 0.0012), (r + 0.0014, z - 0.0012), (r + 0.0014, z + 0.0012), (r - 0.0004, z + 0.0012)], 16, close=True), BRASS, 'in', Mb, bevel=0, gloss=0.7)
        # (a fine feed pipe round to its chamber, with a nut on it)
        part(tube([(0.0078 * k, 0, -0.006), (0.0145, 0, -0.002), (0.0165, 0, 0.006), (0.0118, 0, 0.0085)], 0.0011, 5, 3), STEEL, 'in', Mb @ R(0.9, 'Z'), bevel=0, gloss=0.6)
        part(cyl(0.0022, 0.003, 6), BRASS, 'in', Mb @ R(0.9, 'Z') @ T(0.0165, 0, 0.005), bevel=0, gloss=0.6)
        # (what lights first: the fire in its throat, and a drop of glass standing just off its mouth)
        part(cyl(0.0056, 0.0012, 12), '#ff9a40', 'in', Mb @ T(0, 0, 0.0165), bevel=0, mat=kind, val=0.05, jit=0, gloss=0.6)
        part(lathe([(0.0, 0.0), (0.0046, 0.0012), (0.0086, 0.0062), (0.0102, 0.0125), (0.009, 0.0195), (0.0056, 0.0275), (0.0022, 0.0335), (0.0, 0.0365)], 12), '#ffb050', 'in', Mb @ T(0, 0, 0.0445), bevel=0, mat=kind, val=0.05, jit=0, gloss=0.6)
    # held from behind and below, between two arms, on a bent neck out of a brass foot on the desk: every thruster is free
    grip = c + Vector((0, Rr * 0.7071, -Rr * 0.7071))
    fx, fy = 0.63, 2.14
    foot = Vector((fx, fy, zd(hypot(fx, fy))))
    part(tube([grip, grip + Vector((0.004, 0.03, -0.045)), foot + Vector((-0.012, 0.004, 0.09)), foot + Vector((0, 0, 0.022)), foot], 0.0082, 8, 4), BRASS, 'in', bevel=0, gloss=0.6)
    part(ball(0.0135, 10, 8), BRASS, 'in', T(*grip), bevel=0, gloss=0.7)
    part(cyl(0.0042, 0.038, 6), STEEL, 'in', T(*grip) @ R(pi / 2, 'Y'), bevel=0, gloss=0.6)
    for sx in (-1, 1): part(ball(0.006, 8, 6), BRASS, 'in', T(*(grip + Vector((sx * 0.02, 0, 0)))), bevel=0, gloss=0.7)
    Mfoot = T(*foot) @ R(rad(19.6), 'X') @ T(0, 0, 0.004)
    part(lathe([(0, 0.0), (0.044, 0.0), (0.044, 0.005), (0.036, 0.008), (0.022, 0.012), (0.013, 0.024), (0, 0.024)], 18), BRASS, 'in', Mfoot, bevel=0, gloss=0.6)
    for j in range(3): part(cyl(0.0042, 0.004, 6), STEEL, 'in', Mfoot @ T(0.036 * cos(j * 2.094 + 0.5), 0.036 * sin(j * 2.094 + 0.5), 0.008), bevel=0, gloss=0.6)
    label('JETS', desk(atan2(foot.x, foot.y), hypot(foot.x, foot.y) - 0.08, 0.0055) @ FLAT, 0.06)


# -------------------------------------------------------------------------------- the stick, and the two levers
STICK = Vector((-0.44, 1.69, 1.715))
QUAD = Vector((0.45, 1.70, 1.70))


def stick():
    """Under the left hand: it leans as the ship is turned. (Taken out afterward as 'stick', to be moved in the game.)"""
    M = T(*STICK)
    # what it stands in: a cup on an iron arm from the front of the desk
    part(tube([STICK + Vector((0, 0.17, -0.07)), STICK + Vector((0, 0.08, -0.08)), STICK + Vector((0, 0, -0.05))], 0.018, 8, 3), IRON, 'in', bevel=0, gloss=0.4)
    part(lathe([(0, -0.05), (0.04, -0.05), (0.05, -0.02), (0.045, 0.005), (0.03, 0.01), (0, 0.01)], 16), BRASS, 'in', M, bevel=0, gloss=0.6)
    part(lathe([(0.012, 0.085), (0.02, 0.05), (0.034, 0.02), (0.04, 0.005), (0, 0.005), (0, 0.085)], 14, close=True), RUBBER, 'in', M, bevel=0, tag='stick')
    part(tube([(0, 0, 0.02), (0, 0, 0.19)], 0.0085, 8, 1), STEEL, 'in', M, bevel=0, gloss=0.6, tag='stick')
    part(lathe([(0, 0.17), (0.017, 0.172), (0.021, 0.2), (0.019, 0.25), (0.022, 0.275), (0.016, 0.292), (0, 0.296)], 14), '#4a3226', 'in', M, bevel=0, tag='stick', jit=0.02, mat='leather')
    for z in (0.178, 0.268): part(lathe([(0.0185, z), (0.0235, z), (0.0235, z + 0.008), (0.0185, z + 0.008)], 14, close=True), BRASS, 'in', M, bevel=0, gloss=0.6, tag='stick')
    part(ball(0.0085, 8, 6), RED, 'in', M @ T(0, 0.004, 0.298), bevel=0, mat='enamel', gloss=0.4, tag='stick')
    part(box(0.012, 0.008, 0.02), BRASS, 'in', M @ T(0, -0.0225, 0.238), bevel=0.002, seg=1, gloss=0.6, tag='stick')
    part(cyl(0.0035, 0.006, 6), DARK, 'in', M @ T(0, -0.028, 0.241) @ YA, bevel=0, mat='rubber', tag='stick')
    part(lathe([(0.0195, 0.207), (0.0222, 0.207), (0.0222, 0.222), (0.0195, 0.222)], 14, close=True), '#d9cfb4', 'in', M, bevel=0, mat='cloth', tag='stick')
    label('TURN', desk(rad(-13.2), 1.9, 0.0055) @ FLAT, 0.05)


def levers():
    """Under the right hand: one for lift, one for push. (Taken out afterward as 'lever_lift' and 'lever_push'.)"""
    M = T(*QUAD)
    part(tube([QUAD + Vector((0, 0.16, -0.06)), QUAD + Vector((0, 0.07, -0.07)), QUAD + Vector((0, 0, -0.04))], 0.018, 8, 3), IRON, 'in', bevel=0, gloss=0.4)
    # the quadrant: two cheeks and a top plate with two slots
    for x in (-0.062, 0, 0.062):
        part(lathe([(0.0, 0), (0.085, 0), (0.085, 0.006), (0.0, 0.006)], 20, rad(-90), rad(90), close=True), IRON, 'in', M @ T(x - 0.003, 0, -0.01) @ R(pi / 2, 'Y') @ R(pi / 2, 'Z'), bevel=0.001, gloss=0.4)
    part(box(0.13, 0.17, 0.02), IRON, 'in', M @ T(0, 0, -0.018), bevel=0.006, gloss=0.4)
    part(tube([(-0.075, 0, 0), (0.075, 0, 0)], 0.008, 8, 1), STEEL, 'in', M, bevel=0, gloss=0.6)
    for x, tag, col, name in ((-0.031, 'lever_lift', RED, 'LIFT'), (0.031, 'lever_push', CREAM, 'PUSH')):
        part(box(0.007, 0.018, 0.2), STEEL, 'in', M @ T(x, 0, 0.1), bevel=0.002, gloss=0.6, tag=tag)
        part(lathe([(0, 0.185), (0.013, 0.187), (0.02, 0.2), (0.021, 0.225), (0.015, 0.243), (0, 0.247)], 14), col, 'in', M @ T(x, 0, 0), bevel=0, mat='enamel', gloss=0.4, tag=tag, jit=0.02)
        label(name, M @ T(x, -0.088, -0.02) @ R(rad(8), 'X'), 0.05)
    for k in range(7):
        part(box(0.016, 0.003, 0.003), CREAM, 'in', M @ R(rad(-45 + 15 * k), 'X') @ T(0, 0, 0.087), bevel=0, mat='paint')


# ------------------------------------------------------------------------------------------------------ switches
def switches():
    c = P(rad(-39.5), 2.0, 1.9)
    M = facing(c.x, c.y, c.z, 34)
    case(M, 0.4, 0.2, 0.1)
    part(box(0.37, 0.005, 0.17), BRASS, 'in', M @ T(0, 0, 0), bevel=0.002, gloss=0.5)
    names = ('LAMPS', 'STOVE', 'PUMP', 'AIR', 'SPARE')
    for k in range(5):
        x = -0.144 + 0.072 * k
        toggle(M @ T(x, -0.003, 0.012), up=k not in (1, 4), tip=RED if k == 4 else STEEL)
        label(names[k], M @ T(x, -0.0038, -0.052), 0.062)
        bead(M @ T(x, -0.003, 0.058), None, ('#8dffa0', '#ffb050', '#8dffa0', '#8dffa0', '#ff6a4a')[k], 0.007, glow=0.0 if k in (1, 4) else 1.1)
    for sx in (-1, 1):
        for sz in (-1, 1): screw(M @ T(sx * 0.185, 0, sz * 0.085), 0.005)
        foot = M @ Vector((sx * 0.14, 0.06, -0.1))
        part(tube([foot, Vector((foot.x, foot.y, zd(hypot(foot.x, foot.y))))], 0.012, 6, 1), IRON, 'in', bevel=0, gloss=0.4)


def wireless():
    """A wireless in a wooden box: a cloth mouth, a lit scale, two knobs, a wire up to the roof."""
    c = P(rad(-52), 2.1, 1.99)
    M = facing(c.x, c.y, c.z, 8)
    part(box(0.34, 0.2, 0.24), WOOD, 'in', M @ T(0, 0.1, 0), bevel=0.02, seg=3, jit=0.04)
    part(cyl(0.085, 0.006, 24), CANVAS, 'in', M @ T(-0.065, -0.003, 0.02) @ YA, bevel=0)
    part(lathe([(0.082, 0), (0.096, 0), (0.096, 0.01), (0.082, 0.006)], 24, close=True), BRASS, 'in', M @ T(-0.065, 0, 0.02) @ YA, bevel=0, gloss=0.6)
    for k in range(5): part(box(0.004, 0.006, 2 * sqrt(max(0.085 ** 2 - (0.03 * (k - 2)) ** 2, 1e-4))), WOOD_D, 'in', M @ T(-0.065 + 0.03 * (k - 2), -0.007, 0.02), bevel=0.001)
    label('radio_scale', M @ T(0.085, -0.002, 0.065), 0.13)
    frame(M @ T(0.085, 0, 0.065), 0.13, 0.0325, 0.008, 0.008, BRASS)
    for k in range(2): knob(M @ T(0.05 + 0.07 * k, -0.001, -0.02), 0.02, 0.022, CREAM if k else RUBBER, turn=1.2 * k - 0.5)
    label('WIRELESS', M @ T(0.085, -0.002, -0.08), 0.07)
    top = M @ Vector((0.14, 0.1, 0.12))
    part(tube([top, top + Vector((0, 0, 0.06))], 0.008, 6, 1), BRASS, 'in', bevel=0, gloss=0.6)
    part(tube([top + Vector((0, 0, 0.06)), top + Vector((-0.02, 0.08, 0.5)), P(rad(-58), RI - 0.05, 3.1), P(rad(-58.5), RI - 0.04, 3.3)], 0.003, 4, 5), '#7a2f22', 'in', bevel=0, mat='rubber')


def odds():
    """What a pilot leaves on a desk: a lamp, a card of what to do, a mug, a pencil, a glass to look through."""
    # two small hooded lamps on the sill, shining down on the desk
    for sgn in (-1, 1):
        b = P(sgn * rad(31), RO - 0.26, SILL - 0.03); Ms = at(sgn * rad(31), RO - 0.26, SILL - 0.03)
        part(tube([(0, 0, 0), (0, -0.05, 0.05), (0, -0.11, 0.05)], 0.007, 6, 3), BRASS, 'in', Ms, bevel=0, gloss=0.6)
        part(lathe([(0.012, 0.03), (0.03, 0.015), (0.05, -0.03), (0.045, -0.03), (0.024, 0.01), (0.008, 0.02)], 14, close=True), BRASS, 'in', Ms @ T(0, -0.13, 0.04), bevel=0, gloss=0.6)
        part(ball(0.014, 8, 6), WARM, 'in', Ms @ T(0, -0.13, 0.03), bevel=0, glow=5)
        LIGHTS.append((Ms @ Vector((0, -0.14, -0.02)), WARM, 7))
    # a lamp with a hood, at the far right
    b = P(rad(53), 2.16, zd(2.16)); head = b + Vector((-0.2, -0.16, 0.27))
    part(cyl(0.05, 0.016, 14), BRASS, 'in', T(*b) @ R(rad(19.6), 'X') @ T(0, 0, 0.008), bevel=0.004, gloss=0.6)
    part(tube([b, b + Vector((0, 0, 0.16)), b + Vector((-0.06, -0.05, 0.3)), head + Vector((0.03, 0.02, 0.03))], 0.008, 8, 4), BRASS, 'in', bevel=0, gloss=0.6)
    Mh = aim(head, head + Vector((-0.25, -0.2, -0.55)))
    part(lathe([(0.016, -0.05), (0.03, -0.03), (0.072, 0.06), (0.066, 0.06), (0.026, -0.02), (0.012, -0.04)], 16, close=True), TEAL, 'in', Mh, bevel=0, gloss=0.3)
    part(ball(0.02, 8, 6), WARM, 'in', Mh @ T(0, 0, 0.02), bevel=0, glow=6)
    LIGHTS.append((head + Vector((-0.03, -0.025, -0.07)), WARM, 9))
    # the card of what to do before lifting, on a board with a clip
    Mc = desk(rad(47.5), 2.08, 0.006) @ R(rad(-14), 'Z')
    part(box(0.2, 0.27, 0.008), WOOD, 'in', Mc, bevel=0.003)
    label('checklist', Mc @ T(0, -0.005, 0.0066) @ FLAT, 0.18)
    part(box(0.08, 0.025, 0.012), STEEL, 'in', Mc @ T(0, 0.125, 0.01), bevel=0.003, gloss=0.6)
    # the keys, on a brass plate at the front edge, where the eye falls
    part(box(0.208, 0.141, 0.004), BRASS, 'in', desk(rad(13.4), 1.925, 0.0036), bevel=0.0015, seg=1, gloss=0.5)
    label('pilot_card', desk(rad(13.4), 1.925, 0.0068) @ FLAT, 0.2, gloss=0.4)
    # a mug, a pencil, a spyglass
    Mm = desk(rad(-31), 2.2) @ R(-rad(19.6), 'X')
    part(lathe([(0, 0), (0.038, 0), (0.042, 0.085), (0.036, 0.085), (0.032, 0.01), (0, 0.01)], 16, close=True), '#3f6b8a', 'in', Mm, bevel=0, mat='glaze', gloss=0.5)
    part(tube([(0.04, 0, 0.02), (0.07, 0, 0.03), (0.07, 0, 0.058), (0.041, 0, 0.07)], 0.006, 6, 3), '#3f6b8a', 'in', Mm, bevel=0, mat='glaze', gloss=0.5)
    part(cyl(0.033, 0.002, 14), '#3a2416', 'in', Mm @ T(0, 0, 0.07), bevel=0, mat='glaze', gloss=0.5)
    part(tube([(0, 0, 0), (0.15, 0, 0)], 0.0035, 6, 1), '#c9a23a', 'in', desk(rad(40), 2.18, 0.004) @ R(0.5, 'Z'), bevel=0, mat='paint')
    Ms = desk(rad(-13.2), 2.235, 0.024) @ R(0.2, 'Z')
    part(tube([(-0.13, 0, 0), (0.0, 0, 0)], 0.022, 12, 1), BRASS, 'in', Ms, bevel=0, gloss=0.7)
    part(tube([(0.0, 0, 0), (0.11, 0, 0)], 0.018, 12, 1), LEATHER, 'in', Ms, bevel=0)
    for x in (-0.13, -0.005, 0.11): part(tube([(x - 0.004, 0, 0), (x + 0.004, 0, 0)], 0.0245 if x < 0.05 else 0.021, 12, 1), BRASS, 'in', Ms, bevel=0, gloss=0.7)
    # a ball compass hung at the window's head, to the right, in its ring (out of the way of the view ahead)
    hc = Vector((0.78, sqrt((RO - 0.3) ** 2 - 0.78 ** 2), HEAD - 0.2))
    part(tube([hc + Vector((0, 0.05, 0.2)), hc + Vector((0, 0, 0.052))], 0.004, 5, 1), BRASS, 'in', bevel=0, gloss=0.6)
    part(tube([(0.052 * cos(i * pi / 12), 0, 0.052 * sin(i * pi / 12)) for i in range(24)], 0.005, 6, 1, cyclic=True), BRASS, 'in', T(*hc), bevel=0, gloss=0.7)
    band = lambda p: '#b3432a' if abs((T(*hc).inverted() @ p).z) < 0.008 else '#d9d2bd'
    part(ball(0.04, 16, 12), band, 'in', T(*hc), bevel=0, mat='glaze', gloss=0.5, jit=0)


# ------------------------------------------------------------------------------------------------------- the seat
def seat():
    sy = SEAT_Y; z0 = ZF
    soft = dict(sub=1, rough=0.004, grit=9)
    # a turning foot bolted to the floor, with a spring round its column and a lever to lock it
    part(cyl(0.25, 0.03, 24), IRON, 'in', T(0, sy, z0 + 0.015), bevel=0.008, gloss=0.4)
    bolts('in', [T(0.2 * cos(k * pi / 3), sy + 0.2 * sin(k * pi / 3), z0 + 0.03) for k in range(6)], 0.014, 0.01, STEEL, 0.6)
    part(lathe([(0.11, 0.03), (0.075, 0.1), (0.055, 0.36), (0.07, 0.4), (0.15, 0.43), (0.15, 0.45), (0, 0.45), (0, 0.03)], 20, close=True), IRON, 'in', T(0, sy, z0), bevel=0, gloss=0.4)
    for k in range(4): part(tube([(0.06, 0, 0.12), (0.2, 0, 0.035)], 0.014, 6, 1), IRON, 'in', T(0, sy, z0) @ R(pi / 4 + k * pi / 2, 'Z'), bevel=0, gloss=0.4)
    part(tube([(0.092 * cos(i * pi / 6), 0.092 * sin(i * pi / 6), 0.125 + 0.265 * i / 72) for i in range(73)], 0.0085, 5, 1), STEEL, 'in', T(0, sy, z0), bevel=0, gloss=0.6)
    for z in (0.118, 0.395): part(lathe([(0.075, z - 0.006), (0.105, z - 0.006), (0.105, z + 0.006), (0.075, z + 0.006)], 16, close=True), BRASS, 'in', T(0, sy, z0), bevel=0, gloss=0.6)
    part(tube([(0.1, sy - 0.06, z0 + 0.43), (0.3, sy - 0.1, z0 + 0.42), (0.37, sy - 0.11, z0 + 0.45)], 0.008, 6, 3), STEEL, 'in', bevel=0, gloss=0.6)
    part(ball(0.02, 10, 8), RED, 'in', T(0.375, sy - 0.11, z0 + 0.455), bevel=0, mat='enamel', gloss=0.4)
    # the pan and back, of bent wood, with their cushions and the piping round them
    part(box(0.54, 0.52, 0.035), WOOD, 'in', T(0, sy, z0 + 0.465), bevel=0.015, seg=3)
    part(box(0.5, 0.48, 0.09), LEATHER, 'in', T(0, sy + 0.005, z0 + 0.525), bevel=0.04, seg=3, jit=0.03, **soft)
    part(tube([(0.235 * sx, 0.225 * sy_, 0) for sx, sy_ in ((1, 1), (-1, 1), (-1, -1), (1, -1))], 0.008, 6, 6, cyclic=True), '#5e2618', 'in', T(0, sy + 0.005, z0 + 0.562), bevel=0, mat='leather')
    for x, y in ((-0.11, -0.08), (0.11, -0.08), (-0.11, 0.1), (0.11, 0.1)): part(ball(0.011, 8, 5, s=(1, 1, 0.5)), '#5e2618', 'in', T(x, sy + y, z0 + 0.566), bevel=0, mat='leather')
    for sx in (-1, 1):
        for y in (-0.2, 0.0, 0.2): part(cyl(0.006, 0.005, 6), BRASS, 'in', T(sx * 0.271, sy + y, z0 + 0.465) @ R(pi / 2, 'Y'), bevel=0, gloss=0.6)
    Mb = T(0, sy - 0.285, z0 + 0.94) @ R(rad(11), 'X')
    part(box(0.56, 0.04, 0.82), WOOD, 'in', Mb @ T(0, -0.05, 0), bevel=0.016, seg=3)
    part(box(0.48, 0.09, 0.44), LEATHER, 'in', Mb @ T(0, 0.012, -0.14), bevel=0.04, seg=3, mat='quilt', jit=0.03, **soft)
    part(box(0.44, 0.08, 0.2), LEATHER, 'in', Mb @ T(0, 0.012, 0.21), bevel=0.04, seg=3, jit=0.03, **soft)
    for x in (-0.13, 0.0, 0.13): part(ball(0.012, 8, 5, s=(1, 0.5, 1)), '#5e2618', 'in', Mb @ T(x, 0.053, 0.21), bevel=0, mat='leather')
    # the rest for the head: a roll of leather in two buckled straps
    part(tube([(-0.115, 0.03, 0.42), (0.115, 0.03, 0.42)], 0.062, 14, 1), LEATHER, 'in', Mb, bevel=0, jit=0.03, sub=1, rough=0.004, grit=10)
    for sx in (-1, 1):
        part(ball(0.062, 14, 8, s=(0.45, 1, 1)), LEATHER, 'in', Mb @ T(sx * 0.115, 0.03, 0.42), bevel=0, jit=0.03)
        part(lathe([(0.0635, -0.011), (0.0665, -0.011), (0.0665, 0.011), (0.0635, 0.011)], 14, close=True), '#56624a', 'in', Mb @ T(sx * 0.07, 0.03, 0.42) @ R(pi / 2, 'Y'), bevel=0, mat='cloth')
        part(box(0.026, 0.006, 0.02), STEEL, 'in', Mb @ T(sx * 0.07, 0.096, 0.42), bevel=0.002, seg=1, gloss=0.6)
        part(box(0.024, 0.05, 0.004), '#56624a', 'in', Mb @ T(sx * 0.07, -0.045, 0.4125), bevel=0, mat='cloth')
    # the back of it: two battens, plates at its corners, a name, and screws
    for z in (-0.365, 0.3): part(box(0.5, 0.014, 0.05), WOOD_D, 'in', Mb @ T(0, -0.077, z), bevel=0.004)
    for sx in (-1, 1):
        for z in (-0.33, 0.0, 0.33): part(cyl(0.011, 0.008, 8), BRASS, 'in', Mb @ T(sx * 0.255, -0.072, z) @ R(pi / 2, 'X') @ R(pi, 'Y'), bevel=0.002, gloss=0.6)
        for sz in (-1, 1): part(box(0.07, 0.004, 0.07), BRASS, 'in', Mb @ T(sx * 0.247, -0.0715, sz * 0.377), bevel=0.002, seg=1, gloss=0.5)
        # arms, each on two iron posts, padded on top, capped with brass
        part(box(0.075, 0.44, 0.04), WOOD, 'in', T(sx * 0.325, sy + 0.03, z0 + 0.72), bevel=0.014, seg=3)
        part(box(0.06, 0.3, 0.025), LEATHER, 'in', T(sx * 0.325, sy + 0.05, z0 + 0.75), bevel=0.011, seg=3, jit=0.03, sub=1, rough=0.0025, grit=12)
        part(box(0.079, 0.02, 0.044), BRASS, 'in', T(sx * 0.325, sy + 0.243, z0 + 0.72), bevel=0.004, seg=1, gloss=0.6)
        for y in (-0.12, 0.16): part(tube([(sx * 0.3, sy + y, z0 + 0.48), (sx * 0.325, sy + y, z0 + 0.7)], 0.014, 8, 1), IRON, 'in', bevel=0, gloss=0.4)
        # the belt: two straps over the shoulders to a buckle, lying where they were left
        sh = Mb @ Vector((sx * 0.13, 0.055, 0.33))
        pts = [Mb @ Vector((sx * 0.13, -0.03, 0.405)), sh, Mb @ Vector((sx * 0.12, 0.07, 0.0)), Vector((sx * 0.1, sy - 0.14, z0 + 0.6)), Vector((sx * 0.05, sy + 0.02, z0 + 0.582))]
        part(strap(pts, 0.042, 0.005), '#56624a', 'in', bevel=0, mat='cloth', jit=0.03)
        Mk = T(*lerp(pts[2], pts[3], 0.5)) @ R(rad(8), 'X')
        part(box(0.054, 0.012, 0.034), STEEL, 'in', Mk, bevel=0.003, gloss=0.6)
        part(box(0.036, 0.016, 0.006), STEEL, 'in', Mk, bevel=0.001, seg=1, gloss=0.6)
        # and one across the lap from each side, its tail hanging
        lap = [Vector((sx * 0.266, sy - 0.125, z0 + 0.38)), Vector((sx * 0.27, sy - 0.14, z0 + 0.5)), Vector((sx * 0.24, sy - 0.11, z0 + 0.585)), Vector((sx * 0.14, sy - 0.02, z0 + 0.583)), Vector((sx * 0.04, sy + 0.04, z0 + 0.586))]
        part(strap(lap, 0.042, 0.005, Vector((0, 1, 0))), '#56624a', 'in', bevel=0, mat='cloth', jit=0.03)
        part(box(0.05, 0.034, 0.008), STEEL, 'in', T(sx * 0.15, sy - 0.03, z0 + 0.59) @ R(sx * 0.55, 'Z'), bevel=0.002, seg=1, gloss=0.6)
    part(box(0.56, 0.006, 0.02), BRASS, 'in', Mb @ T(0, -0.0715, 0.398), bevel=0.002, seg=1, gloss=0.5)
    label('PILOT', Mb @ T(0, -0.0715, 0.352), 0.1)
    part(box(0.07, 0.06, 0.014), STEEL, 'in', T(0, sy + 0.04, z0 + 0.586), bevel=0.004, gloss=0.6)
    part(cyl(0.016, 0.008, 12), RED, 'in', T(0, sy + 0.04, z0 + 0.596), bevel=0.002, mat='enamel', gloss=0.4)
    # a ring for a mug on the right arm
    part(tube([(0.405 + 0.043 * cos(i * pi / 8), sy + 0.16 + 0.043 * sin(i * pi / 8), z0 + 0.725) for i in range(16)], 0.004, 5, 1, cyclic=True), BRASS, 'in', bevel=0, gloss=0.6)
    # a pocket of canvas on the back of it, with rolled charts, a folded one and a pencil in it
    pk = lambda u, v: (-0.19 + 0.38 * u, -0.076 - 0.05 * sin(pi * u) ** 0.5 * (0.6 + 0.4 * (1 - v) ** 0.7), -0.31 + 0.23 * v)
    part(sheet(12, 6, pk, 0.004), '#56624a', 'in', Mb, bevel=0, mat='canvas', jit=0.03, sharp=80, rough=0.002, grit=16)
    part(box(0.4, 0.008, 0.024), LEATHER, 'in', Mb @ T(0, -0.079, -0.313), bevel=0.002, seg=1)
    part(tube([Mb @ Vector(pk(i / 12, 1.0)) for i in range(13)], 0.005, 5, 1), LEATHER, 'in', bevel=0)
    for u in (0.2, 0.5, 0.8): part(ball(0.006, 6, 5), BRASS, 'in', T(*(Mb @ (Vector(pk(u, 0.9)) + Vector((0, -0.003, 0))))), bevel=0, gloss=0.6)
    for sx in (-1, 1): part(cyl(0.006, 0.004, 6), BRASS, 'in', Mb @ T(sx * 0.185, -0.084, -0.313) @ R(pi / 2, 'X') @ R(pi, 'Y'), bevel=0, gloss=0.6)
    part(tube([Mb @ Vector((-0.1, -0.089, -0.22)), Mb @ Vector((0.0, -0.094, 0.12))], 0.016, 10, 1), '#dccfa8', 'in', bevel=0, mat='paper')
    part(tube([Mb @ Vector((-0.01, -0.088, -0.22)), Mb @ Vector((-0.09, -0.093, 0.03))], 0.013, 10, 1), '#cfc09a', 'in', bevel=0, mat='paper')
    part(box(0.11, 0.012, 0.2), '#d9cdaa', 'in', Mb @ T(0.1, -0.087, -0.11) @ R(0.12, 'Y'), bevel=0.002, seg=1, mat='paper')
    part(tube([Mb @ Vector((0.165, -0.085, -0.2)), Mb @ Vector((0.168, -0.087, -0.05))], 0.0036, 6, 1), '#c9a23a', 'in', bevel=0, mat='paint')


def strap(pts, w, t, across=None):
    """A flat band through points, lying across the way it runs (across: which way its width lies, if not sideways)."""
    Pp = crom([Vector(p) for p in pts], 6)
    bm = bmesh.new()
    rows = []
    for i, p in enumerate(Pp):
        d = (Pp[min(i + 1, len(Pp) - 1)] - Pp[max(i - 1, 0)]).normalized()
        side = d.cross(Vector((0, 1, 0)))
        side = side.normalized() if side.length > 0.2 else Vector((1, 0, 0))
        side = Vector((1, 0, 0)) if abs(side.x) > 0.5 else side
        if across is not None: side = (across - d * across.dot(d)).normalized()
        rows.append((bm.verts.new(p - side * w / 2), bm.verts.new(p + side * w / 2)))
    for a, b in zip(rows, rows[1:]): bm.faces.new((a[0], a[1], b[1], b[0]))
    bmesh.ops.solidify(bm, geom=bm.faces[:], thickness=t)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    return bm


# --------------------------------------------------------------------------------------- what is over the window
def overhead():
    # a blind rolled up over each pane, in two straps
    for k in range(5):
        th = rad(-48 + 24 * k); c = 2 * (RO - 0.2) * sin(rad(11))
        M = at(th, RO - 0.24, HEAD + 0.035)
        part(tube([(-c / 2, 0, 0), (c / 2, 0, 0)], 0.034, 12, 1), CANVAS, 'in', M, bevel=0, jit=0.04)
        for sx in (-1, 1):
            part(tube([(sx * c * 0.3 + 0.0, 0.037 * cos(i * pi / 8), 0.037 * sin(i * pi / 8)) for i in range(16)], 0.004, 5, 1, cyclic=True), LEATHER, 'in', M, bevel=0)
            part(cyl(0.008, 0.01, 8), BRASS, 'in', M @ T(sx * c * 0.3, -0.04, 0) @ YA, bevel=0, gloss=0.6)
    # a board of switches over the middle pane, a hand-hold either side
    Mo = at(0, RO - 0.3, HEAD + 0.17) @ R(rad(38), 'X')
    part(box(0.44, 0.03, 0.11), WOOD, 'in', Mo @ T(0, 0.016, 0), bevel=0.008)
    part(box(0.41, 0.004, 0.085), BRASS, 'in', Mo, bevel=0.002, gloss=0.5)
    for sx in (-1, 1): part(box(0.011, 0.003, 0.1), RED, 'in', Mo @ T(sx * 0.2125, -0.0002, 0), bevel=0.0008, seg=1, mat='stripe')
    for k in range(6):
        x = -0.16 + 0.064 * k
        toggle(Mo @ T(x, -0.002, 0.008), up=k % 3 != 1)
        bead(Mo @ T(x, -0.002, -0.028), None, '#ffb050' if k % 2 else '#8dffa0', 0.005, glow=0.9 if k % 3 != 1 else 0.0)
    for sgn in (-1, 1):
        Mh = at(sgn * rad(30), RO - 0.26, HEAD + 0.14)
        part(tube([(-0.09, 0, 0), (-0.09, -0.06, -0.01), (0.09, -0.06, -0.01), (0.09, 0, 0)], 0.011, 8, 4), BRASS, 'in', Mh, bevel=0, gloss=0.6)
        part(tube([(-0.05, -0.06, -0.01), (0.05, -0.06, -0.01)], 0.015, 8, 1), LEATHER, 'in', Mh, bevel=0)
