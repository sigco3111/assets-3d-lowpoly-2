# More of the outside: what makes the ship look built by hand, mended, and worked on every day.
#
# The walls: where each hoop is joined, a vent, boxes where the wires meet and the pipes they run in, a ring to
# moor by, a hose on a hook and its tap, a rolled cloth lashed under the eave, the filler and its cap on a chain,
# plates that say what is what, a can for the herbs. The window: putty, a sill of copper, shutters folded back.
# The roof: a gutter in four lengths and its spout, lapped seams and patches, the stovepipe's bands, the mast's
# rigging, the dish on a proper mount, boards lashed up there, a box that reads the weather, a board to climb by,
# the ladder's rails round the eave. The tanks' pipes, valves and glasses; the engine and the four pods of jets.
from dims import *
from detail import out_at, POD_R, POD_Z

RA, ZA, RE, ZE = 0.30, 4.52, 2.86, 3.37             # the roof's cone (build.py roof() has the same numbers)
SL = (ZA - ZE) / (RE - RA); BETA = atan2(ZA - ZE, RE - RA)
zr = lambda r: ZA - (r - RA) * SL


def on_roof(th, r, lift=0.0):
    """A frame on the roof's copper: its +Z square to the sheet, its +Y down the slope, its +X along the eave."""
    return at(th, r, zr(r)) @ R(-BETA, 'X') @ T(0, 0, lift)


def wall(deg, z, off=0.0):
    """A frame on the outside of the wall (its -Y away from the ship, its +X to the right of someone looking at it)."""
    return out_at(rad(deg), RO + off, z)


# ------------------------------------------------------------------------------------------------- small fittings
def bolt(M, r=0.011, h=0.009, col=None, n=6, gloss=0.5, grp='out'):
    """A bolt's head: M's +Z is the way it sticks out of the face at M's origin."""
    part(cyl(r, h, n), col or IRON, grp, M @ T(0, 0, h / 2), bevel=0, gloss=gloss)


def rivet(M, r=0.009, col=None, grp='out', gloss=0.5):
    part(ball(r, 6, 4, s=(1, 1, 0.6)), col or IRON, grp, M, bevel=0, gloss=gloss)


def ring(M, r, t=0.006, n=16, col=None, gloss=0.5, grp='out', sides=5, mat=None):
    """A hoop of round bar in M's own XY."""
    part(tube([(r * cos(2 * pi * i / n), r * sin(2 * pi * i / n), 0) for i in range(n)], t, sides, 1, cyclic=True), col or IRON, grp, M, bevel=0, gloss=gloss, mat=mat)


def band(M, r, z0, z1, t=0.006, n=16, col=None, gloss=0.4, grp='out', nb=0, mat=None, br=0.007):
    """A flat band round something of radius r about M's own Z, with nb bolts in it."""
    part(slab(r - 0.001, r + t, z0, z1, 0, 2 * pi, n), col or IRON, grp, M, bevel=0, gloss=gloss, mat=mat)
    for k in range(nb): bolt(M @ R((k + 0.5) * 2 * pi / nb, 'Z') @ T(r + t, 0, (z0 + z1) / 2) @ R(pi / 2, 'Y'), br, br * 0.8, STEEL, 5, 0.6, grp)


def flange(M, r, n=6, t=0.014, col=None, gloss=0.5, grp='out', br=None):
    """Where a pipe is bolted to a face or to another: a thick disc at M's origin about its Z, bolts through it."""
    part(cyl(r, t, 12), col or IRON, grp, M, bevel=0.003, gloss=gloss)
    for k in range(n): bolt(M @ R((k + 0.5) * 2 * pi / n, 'Z') @ T(r * 0.76, 0, t / 2), br or r * 0.13, 0.006, STEEL, 6, 0.6, grp)


def basis(p, z, y):
    """A frame at p whose +Z is `z` and whose +Y is as near `y` as that allows."""
    z = Vector(z).normalized(); y = Vector(y); y = (y - z * y.dot(z)).normalized(); x = y.cross(z)
    m = Matrix((x, y, z)).transposed().to_4x4(); m.translation = Vector(p)
    return m


def path(pts, k=4):
    """A way through points, as tube() takes it: returns where(u) -> (place, direction) for u in 0..1, and its length."""
    Pp = [Vector(p) for p in pts]
    if len(Pp) > 2 and k > 1: Pp = crom(Pp, k)
    Ls = [0.0]
    for i in range(1, len(Pp)): Ls.append(Ls[-1] + (Pp[i] - Pp[i - 1]).length)
    def where(u):
        s = max(0.0, min(1.0, u)) * Ls[-1]
        for i in range(1, len(Pp)):
            if Ls[i] >= s or i == len(Pp) - 1:
                return lerp(Pp[i - 1], Pp[i], (s - Ls[i - 1]) / max(Ls[i] - Ls[i - 1], 1e-9)), (Pp[i] - Pp[i - 1]).normalized()
    return where, Ls[-1]


def pipe(pts, r, col=None, grp='out', unions=(), sub=4, gloss=0.6, mat=None, n=8, ucol=None):
    """A pipe through points, with a nut wherever two lengths of it are joined (each a part of its length, 0..1)."""
    part(tube([Vector(p) for p in pts], r, n, sub), col or COPPER, grp, bevel=0, gloss=gloss, mat=mat)
    where, L = path(pts, sub)
    for u in unions:
        p, d = where(u)
        part(cyl(r * 1.7, r * 2.6, 6), ucol or BRASS, grp, aim(p, p + d), bevel=0, gloss=0.6)
    return where, L


def valve(p, d, r, up=(0, 0, 1), col=None, grp='out'):
    """A valve in a pipe at p (the pipe runs along d): its body, a stem toward `up`, a wheel to turn it by."""
    p = Vector(p); d = Vector(d).normalized(); M = aim(p, p + d)
    part(cyl(r * 2.0, r * 3.4, 10), BRASS, grp, M, bevel=r * 0.3, gloss=0.6)
    for s in (-1, 1): part(cyl(r * 2.5, r * 0.8, 6), BRASS, grp, M @ T(0, 0, s * r * 2.0), bevel=0, gloss=0.6)
    u = Vector(up); u = (u - d * u.dot(d)).normalized(); Ms = aim(p, p + u)
    part(cyl(r * 0.9, r * 1.6, 8), BRASS, grp, Ms @ T(0, 0, r * 2.4), bevel=0, gloss=0.6)
    part(cyl(r * 0.45, r * 3.4, 6), STEEL, grp, Ms @ T(0, 0, r * 4.2), bevel=0, gloss=0.6)
    W = Ms @ T(0, 0, r * 5.6)
    ring(W, r * 3.3, r * 0.5, 12, col or RED, 0.3, grp, 5, 'enamel')
    for a in (0, 2.094, 4.189): part(tube([(0, 0, 0), (r * 3.3 * cos(a), r * 3.3 * sin(a), 0)], r * 0.35, 4, 1), col or RED, grp, W, bevel=0, mat='enamel')
    part(cyl(r * 0.8, r * 0.7, 6), STEEL, grp, W @ T(0, 0, r * 0.3), bevel=0, gloss=0.6)


def clip(p, n, d, r, gap=0.008, col=None, grp='out'):
    """A strap that holds a pipe of radius r at p to the face behind it. n: the way out from that face; d: the way the pipe runs."""
    M = basis(p, n, d)
    part(slab(r - 0.001, r + 0.004, -0.011, 0.011, 0, 2 * pi, 8), col or IRON, grp, M @ R(pi / 2, 'X'), bevel=0, gloss=0.4)
    part(box(r * 1.2 + 0.006, 0.02, gap + 0.006), col or IRON, grp, M @ T(0, 0, -(r + gap / 2)), bevel=0, gloss=0.4)
    part(box(r * 4.4 + 0.022, 0.024, 0.004), col or IRON, grp, M @ T(0, 0, -(r + gap) + 0.002), bevel=0, gloss=0.4)
    for s in (-1, 1): bolt(M @ T(s * (r * 1.7 + 0.008), 0, -(r + gap) + 0.004), 0.005, 0.004, STEEL, 5, 0.6, grp)


def clips(where, us, n, r, gap=0.008, grp='out'):
    for u in us:
        p, d = where(u)
        clip(p, n(p) if callable(n) else n, d, r, gap, grp=grp)


radial = lambda p: Vector((p.x, p.y, 0)).normalized()


def lagging(pts, r, grp='out', ties=4, col='#9a8c6a', sub=4):
    """Cloth wound thick round a hot pipe, and tied."""
    part(tube([Vector(p) for p in pts], r, 8, sub), col, grp, bevel=0, mat='canvas', rough=r * 0.16, grit=22, jit=0.07)
    where, L = path(pts, sub)
    for k in range(ties):
        p, d = where((k + 0.5) / ties)
        ring(aim(p, p + d), r * 1.04, 0.0035, 8, ROPE, 0, grp, 4, 'rope')


def eye(M, r=0.022, t=0.005, col=None, grp='out', turn=0.0):
    """A ring bolt: M's +Z is out from the face it is screwed into."""
    bolt(M, 0.012, 0.006, col, 6, 0.5, grp)
    part(cyl(0.005, 0.02, 5), col or IRON, grp, M @ T(0, 0, 0.014), bevel=0, gloss=0.5)
    ring(M @ R(turn, 'Z') @ T(0, 0, 0.022 + r) @ R(pi / 2, 'X'), r, t, 10, col, 0.5, grp, 4)


def plate(name, M, w, grp='out', col=None, pad=0.012, t=0.004, stand=0.0, mat='enamel'):
    """Something printed, on a plate screwed to a face (M as for a label: its -Y is the way it faces). stand: how far the plate stands off on its four screws."""
    c = cell(name); h = w * (c[3] - c[1]) / (c[2] - c[0])
    Mp = M @ T(0, -stand, 0)
    part(box(w + 2 * pad, t, h + 2 * pad), col or ENAMEL, grp, Mp @ T(0, -t / 2, 0), bevel=0.0015, gloss=0.3, mat=mat, jit=0.03)
    label(name, Mp @ T(0, -t - 0.001, 0), w, grp)
    for sx in (-1, 1):
        for sz in (-1, 1):
            Ms = Mp @ T(sx * (w / 2 + pad * 0.42), -t, sz * (h / 2 + pad * 0.42))
            part(cyl(0.0045, 0.003, 6), STEEL, grp, Ms @ T(0, -0.0015, 0) @ YA, bevel=0, gloss=0.6)
            if stand: part(cyl(0.006, stand + 0.02, 6), IRON, grp, Ms @ T(0, t + (stand + 0.02) / 2, 0) @ YA, bevel=0, gloss=0.4)


def jbox(M, w=0.14, h=0.18, d=0.06, col=None, grp='out', glands=(-1, 1)):
    """A box where wires meet, on a face (M as wall()): a lid held by four screws, a hinge, a gland under it for each wire."""
    col = col or ENAMEL
    part(box(w, d, h), col, grp, M @ T(0, -d / 2 + 0.004, 0), bevel=0.008, gloss=0.3, mat='enamel', jit=0.04)
    part(box(w - 0.016, 0.006, h - 0.016), col, grp, M @ T(0, -d + 0.002, 0), bevel=0.002, gloss=0.3, mat='enamel', jit=0.04)
    for sx in (-1, 1):
        for sz in (-1, 1): part(cyl(0.005, 0.004, 6), STEEL, grp, M @ T(sx * (w / 2 - 0.02), -d - 0.002, sz * (h / 2 - 0.02)) @ YA, bevel=0, gloss=0.6)
    for s in glands: part(cyl(0.013, 0.03, 8), BRASS, grp, M @ T(s * w / 4, -d / 2, -h / 2 - 0.01), bevel=0, gloss=0.6)
    for sz in (-1, 1): part(cyl(0.006, 0.03, 6), IRON, grp, M @ T(-w / 2 - 0.004, -d + 0.004, sz * h * 0.28), bevel=0, gloss=0.4)


def soft(r, L, n=12, m=7, wob=0.08, ends=0.72):
    """A roll or a bag, along Z: its girth wanders a little (and `rough` does the rest)."""
    prof = [(0, -L / 2)] + [(r * (ends if j in (0, m) else 1 + random.uniform(-wob, wob)), -L / 2 + L * (0.02 + 0.96 * j / m)) for j in range(m + 1)] + [(0, L / 2)]
    return lathe(prof, n)


def strap(pts, w, side, t=0.005, col=None, grp='out', mat='leather', sub=4, gloss=0.0):
    """A flat strap along a way through points, `w` wide across `side`."""
    Pp = [Vector(p) for p in pts]
    if len(Pp) > 2 and sub > 1: Pp = crom(Pp, sub)
    s = Vector(side).normalized(); m = len(Pp) - 1
    part(sheet(m, 1, lambda u, v: Pp[min(m, int(round(u * m)))] + s * (v - 0.5) * w, t), col or LEATHER, grp, bevel=0, mat=mat, gloss=gloss, sharp=80)


def cable(pts, r=0.006, col=None, grp='out', sub=4):
    part(tube([Vector(p) for p in pts], r, 5, sub), col or RUBBER, grp, bevel=0, mat='rubber')


def build():
    hull_more(); lamps_more(); window_more(); door_more(); mends()
    roof_more(); roof_cargo(); mast_more(); dish_more(); ladder_more()
    tank_more(); engine_more(); belly_more(); pods2()
    more3()
    # (for looking under the ship in a preview: what is seen from inside a helmet is built at the origin, in the way)
    if os.environ.get('SHIP_NO_VISOR'):
        for o in COL['visor'].objects: o.hide_render = True


# =============================================================================================== the walls
def vent(M, w=0.28, h=0.22, n=6):
    """A louvred vent in an iron frame, with a little hood of copper over it."""
    part(box(w, 0.03, h), IRON, 'out', M @ T(0, -0.011, 0), bevel=0.005, gloss=0.4)
    part(box(w - 0.05, 0.006, h - 0.05), '#131214', 'out', M @ T(0, -0.027, 0), bevel=0, mat='soot')
    for k in range(n):
        part(box(w - 0.052, 0.004, (h - 0.05) / n * 1.3), ENAMEL, 'out', M @ T(0, -0.036, -(h - 0.05) / 2 + (k + 0.5) * (h - 0.05) / n) @ R(rad(-38), 'X'), bevel=0, gloss=0.3, mat='enamel', jit=0.04)
    for sx in (-1, 1):
        for sz in (-1, 1): bolt(M @ T(sx * (w / 2 - 0.014), -0.026, sz * (h / 2 - 0.014)) @ YA, 0.007, 0.005, STEEL)
    part(box(w + 0.03, 0.085, 0.006), COPPER, 'out', M @ T(0, -0.036, h / 2 + 0.022) @ R(rad(20), 'X'), bevel=0.002, gloss=0.55)
    for sx in (-1, 1): part(box(0.006, 0.07, 0.04), COPPER, 'out', M @ T(sx * (w / 2 + 0.012), -0.03, h / 2 + 0.004) @ R(rad(20), 'X'), bevel=0, gloss=0.55)


def conduit(pts, clipsAt=(), r=0.008, gap=0.012, col=None):
    """A thin pipe that wires run in, along the wall."""
    where, L = pipe(pts, r, col or STEEL, sub=3, gloss=0.5, n=6, ucol=STEEL)
    clips(where, clipsAt, radial, r, gap)
    return where


def hull_more():
    # where each hoop is joined: a lap, two lugs, and the bolt that draws it tight
    for z, ths in ((0.99, (66, -128)), (1.66, (-38, 127)), (3.22, (84, -128))):
        for th in ths:
            M = wall(th, z, 0.014)
            part(box(0.17, 0.006, 0.082), COPPER, 'out', M @ T(0, -0.003, 0), bevel=0.002, gloss=0.6, jit=0.06)
            for sx in (-1, 1):
                part(box(0.022, 0.034, 0.066), COPPER, 'out', M @ T(sx * 0.036, -0.02, 0), bevel=0.004, gloss=0.6)
                part(cyl(0.012, 0.012, 6), BRASS, 'out', M @ T(sx * 0.054, -0.022, 0) @ R(pi / 2, 'Y'), bevel=0, gloss=0.6)
                for sz in (-1, 1): rivet(M @ T(sx * 0.072, -0.006, sz * 0.025) @ YA, 0.007, COPPER)
            part(cyl(0.006, 0.12, 6), BRASS, 'out', M @ T(0, -0.022, 0) @ R(pi / 2, 'Y'), bevel=0, gloss=0.6)

    # ---- in front, under the window: the ship's number on a plate, a ring to moor by, the lamps' wires, a hose and its tap
    plate('mark_a', wall(-34, 1.38, 0.006), 0.5, pad=0.022, stand=0.012)
    Mr = wall(0, 1.27, 0.002)
    part(box(0.17, 0.014, 0.17), IRON, 'out', Mr @ T(0, -0.005, 0), bevel=0.005, gloss=0.4)
    for sx in (-1, 1):
        for sz in (-1, 1): bolt(Mr @ T(sx * 0.062, -0.012, sz * 0.062) @ YA, 0.011, 0.008, STEEL)
    part(tube([(-0.03, -0.01, 0.02), (-0.03, -0.05, 0.02), (0.03, -0.05, 0.02), (0.03, -0.01, 0.02)], 0.011, 6, 3), IRON, 'out', Mr, bevel=0, gloss=0.4)
    ring(Mr @ T(0, -0.05, -0.052) @ R(pi / 2, 'X') @ R(0.12, 'Y'), 0.075, 0.013, 16, IRON, 0.4, sides=6)
    wh = conduit([P(rad(a), RO + 0.024, 1.588 - (0.03 if abs(a) > 16 else 0)) for a in (-17.5, -16, -12, -8, -4, 0, 4, 8, 12, 16, 17.5)], (0.2, 0.36, 0.64, 0.8))
    jbox(wall(0, 1.588, 0.0), 0.1, 0.085, 0.05, glands=())
    # (the hose: four turns of it on an iron horn, its brass end hanging; the tap it screws to, with what comes out of it on a plate)
    Mh = wall(33.5, 1.4, 0.0)
    part(box(0.07, 0.012, 0.12), IRON, 'out', Mh @ T(0, -0.004, 0.06), bevel=0.004, gloss=0.4)
    for sz in (0.02, 0.1): bolt(Mh @ T(0, -0.01, sz) @ YA, 0.008, 0.006, STEEL)
    part(tube([(0, -0.005, 0.07), (0, -0.07, 0.085), (0, -0.14, 0.075), (0, -0.155, 0.12)], 0.014, 6, 3), IRON, 'out', Mh, bevel=0, gloss=0.4)
    for k in range(4):
        Rk = 0.125 + 0.006 * (k % 2)
        part(tube([(Rk * cos(i * pi / 9 + k), -0.03 - 0.03 * k + 0.006 * sin(i * 0.9 + k), -0.055 + (Rk + 0.004 * k) * sin(i * pi / 9 + k)) for i in range(18)], 0.015, 6, 1, cyclic=True), '#3c4a3e', 'out', Mh, bevel=0, mat='rubber', jit=0.08)
    part(tube([(0.12, -0.12, -0.02), (0.135, -0.13, -0.16), (0.12, -0.125, -0.26)], 0.015, 6, 3), '#3c4a3e', 'out', Mh, bevel=0, mat='rubber')
    part(cyl(0.02, 0.05, 8), BRASS, 'out', Mh @ T(0.12, -0.125, -0.285), bevel=0.003, gloss=0.6)
    part(cyl(0.011, 0.07, 8, r2=0.016), BRASS, 'out', Mh @ T(0.12, -0.125, -0.34), bevel=0, gloss=0.6)
    Mt = wall(26.6, 1.47, 0.0)
    flange(Mt @ T(0, -0.005, 0) @ YA, 0.034, 4, 0.01, BRASS, 0.6)
    part(cyl(0.015, 0.07, 8), BRASS, 'out', Mt @ T(0, -0.04, 0) @ YA, bevel=0, gloss=0.6)
    part(cyl(0.02, 0.04, 8), BRASS, 'out', Mt @ T(0, -0.075, 0), bevel=0.003, gloss=0.6)
    part(cyl(0.012, 0.05, 8), BRASS, 'out', Mt @ T(0, -0.075, -0.04), bevel=0, gloss=0.6)
    part(box(0.07, 0.012, 0.012), RED, 'out', Mt @ T(0, -0.075, 0.03), bevel=0.003, mat='enamel')
    part(tube([Mt @ Vector((0, -0.075, -0.065)), Mt @ Vector((0.02, -0.08, -0.13)), Mh @ Vector((0.11, -0.07, 0.03))], 0.013, 6, 3), '#3c4a3e', 'out', bevel=0, mat='rubber')
    plate('WATER', wall(26.6, 1.56, 0.003), 0.08, pad=0.008)

    # (a rail of brass to hold by, round the front under the window, between the two front legs)
    rz = 1.795
    part(tube([P(rad(a), RO + 0.07, rz) for a in range(-37, 38, 2)], 0.012, 6, 1), BRASS, 'out', bevel=0, gloss=0.6)
    for a in (-37, -27.75, -18.5, -9.25, 0, 9.25, 18.5, 27.75, 37):
        Mb = wall(a, rz, 0.0)
        part(tube([(0, -0.004, -0.03), (0, -0.05, -0.02), (0, -0.07, 0.0)], 0.008, 5, 2), BRASS, 'out', Mb, bevel=0, gloss=0.6)
        part(cyl(0.02, 0.008, 8), BRASS, 'out', Mb @ T(0, -0.004, -0.03) @ YA, bevel=0, gloss=0.6)
    for a in (-37, 37): part(ball(0.018, 8, 6), BRASS, 'out', T(*P(rad(a), RO + 0.07, rz)), bevel=0, gloss=0.6)

    # ---- the right-hand wall: a vent, the lantern's wire, a cloth rolled and lashed, the filler, a can
    vent(wall(79.5, 2.82, 0.0))
    plate('VENT', wall(79.5, 2.655, 0.003), 0.085, pad=0.008)
    conduit([P(rad(74.5), RO + 0.024, 2.08), P(rad(74.5), RO + 0.024, 3.08), P(rad(73), RO + 0.024, 3.152), P(rad(68.5), RO + 0.024, 3.152), P(rad(66), RO + 0.1, 3.2), P(rad(66), RO + 0.2, 3.3)], (0.15, 0.45, 0.72))
    Mw = wall(121.5, 2.78, 0.115)
    part(soft(0.08, 0.76, 14, 8, 0.07), '#7d8466', 'out', Mw @ R(pi / 2, 'Y'), bevel=0, mat='canvas', rough=0.012, grit=9, jit=0.05)
    for x in (-0.26, 0.26):
        part(tube([(x, 0.11, 0.06), (x, 0.092, -0.06), (x, 0.03, -0.102), (x, -0.07, -0.09), (x, -0.1, -0.02)], 0.009, 6, 3), IRON, 'out', Mw, bevel=0, gloss=0.4)
        part(box(0.04, 0.008, 0.09), IRON, 'out', Mw @ T(x, 0.1, 0.045), bevel=0, gloss=0.4)
        bolt(Mw @ T(x, 0.096, 0.07) @ YA, 0.007, 0.005, STEEL)
    for x in (-0.13, 0.11):
        ring(Mw @ T(x, 0, 0) @ R(pi / 2, 'Y'), 0.086, 0.0055, 12, ROPE, 0, mat='rope')
        E = Mw @ T(x, 0.105, 0.15)
        eye(E @ YA, 0.016, 0.004)
        part(tube([Mw @ Vector((x, 0.02, 0.084)), Mw @ Vector((x, 0.06, 0.13)), E @ Vector((0, -0.03, -0.012))], 0.0055, 5, 2), ROPE, 'out', bevel=0, mat='rope')
    Mf = wall(124, 1.5, 0.0)
    flange(Mf @ T(0, -0.006, 0) @ YA, 0.085, 6, 0.012, IRON, 0.4, br=0.009)
    N = Mf @ R(rad(-32), 'X') @ YA
    part(cyl(0.046, 0.1, 12), BRASS, 'out', N @ T(0, 0, 0.045), bevel=0.004, gloss=0.6)
    part(cyl(0.058, 0.03, 12), BRASS, 'out', N @ T(0, 0, 0.108), bevel=0.006, gloss=0.6)
    for a in range(8): part(box(0.008, 0.006, 0.026), BRASS, 'out', N @ R(a * pi / 4, 'Z') @ T(0.059, 0, 0.108), bevel=0, gloss=0.6)
    part(box(0.1, 0.014, 0.012), BRASS, 'out', N @ T(0, 0, 0.13), bevel=0.003, gloss=0.6)
    eye(Mf @ T(0.14, 0, 0.04) @ YA, 0.012, 0.003)
    part(tube([N @ Vector((0.058, 0, 0.108)), Mf @ Vector((0.11, -0.06, -0.07)), Mf @ Vector((0.14, -0.03, 0.01))], 0.003, 4, 4), STEEL, 'out', bevel=0, gloss=0.6)
    plate('FUEL', wall(127.2, 1.47, 0.003), 0.1, pad=0.009)
    # (and the pipe from it, down the wall in two clips and under the belly)
    wf, Lf = pipe([P(rad(124), RO + 0.04, 1.43), P(rad(124), RO + 0.04, 1.2), P(rad(124), RO + 0.04, 1.02), P(rad(124), RO + 0.01, 0.9), P(rad(124), 2.4, 0.82)], 0.022, COPPER, unions=(0.12, 0.62), sub=3)
    clips(wf, (0.3, 0.5), radial, 0.022, 0.016)
    vent(wall(140.9, 1.27, 0.0), 0.19, 0.16, 4)
    plate('mark_b', wall(129.6, 1.3, 0.004), 0.19, pad=0.014, stand=0.006)
    # (a can for the herbs, on a hook)
    Mc = wall(113.2, 1.97, 0.0)
    part(tube([(0, -0.004, 0.02), (0, -0.09, 0.03), (0, -0.12, 0.0), (0, -0.12, -0.03)], 0.007, 6, 3), IRON, 'out', Mc, bevel=0, gloss=0.4)
    bolt(Mc @ T(0, 0, 0.02) @ YA, 0.014, 0.006)
    K = Mc @ T(0, -0.125, -0.33) @ R(0.5, 'Z')
    part(lathe([(0, 0), (0.085, 0), (0.092, 0.012), (0.088, 0.2), (0.07, 0.215), (0.064, 0.215), (0.082, 0.2), (0.086, 0.02), (0, 0.012)], 14, close=True), '#5f7d6a', 'out', K, bevel=0, gloss=0.3, mat='tin', jit=0.05)
    part(tube([(0.085, 0, 0.04), (0.17, 0, 0.13), (0.24, 0, 0.23)], lambda u: 0.018 - 0.007 * u, 6, 3), '#5f7d6a', 'out', K, bevel=0, gloss=0.3, mat='tin')
    part(cyl(0.03, 0.012, 8), BRASS, 'out', K @ T(0.245, 0, 0.237) @ R(rad(45), 'Y'), bevel=0, gloss=0.6)
    part(tube([(0, -0.08, 0.2), (0, -0.05, 0.29), (0, 0.0, 0.31), (0, 0.05, 0.29), (0, 0.08, 0.2)], 0.006, 5, 3), BRASS, 'out', K, bevel=0, gloss=0.6)
    part(tube([(-0.08, 0, 0.19), (-0.14, 0, 0.14), (-0.13, 0, 0.05), (-0.088, 0, 0.03)], 0.007, 5, 3), '#5f7d6a', 'out', K, bevel=0, gloss=0.3, mat='tin')

    # ---- by the door, on the right: a box for the lantern's wire; a plate about the jets
    jbox(wall(155.6, 2.52, 0.0))
    conduit([P(rad(155.6), RO + 0.024, 2.62), P(rad(155.6), RO + 0.024, 2.9), P(rad(157.4), RO + 0.024, 2.99), P(rad(159), RO + 0.03, 3.03)], (0.3,))
    conduit([P(rad(155.2), RO + 0.034, 2.41), P(rad(155.2), RO + 0.034, 1.9), P(rad(155.2), RO + 0.034, 1.3), P(rad(155.2), RO + 0.034, 1.08)], (0.12, 0.5, 0.88), gap=0.022)
    plate('MIND THE JETS', wall(141.2, 2.075, 0.004), 0.27, pad=0.011)

    # ---- the left-hand wall: a box and the wire to the other lantern, a plate by the bell
    jbox(wall(-80.5, 2.78, 0.0))
    conduit([P(rad(-80.5), RO + 0.024, 2.88), P(rad(-80.5), RO + 0.024, 3.07), P(rad(-78.6), RO + 0.024, 3.152), P(rad(-68.5), RO + 0.024, 3.152), P(rad(-66), RO + 0.1, 3.2), P(rad(-66), RO + 0.2, 3.3)], (0.14, 0.5, 0.7))
    conduit([P(rad(-80.9), RO + 0.024, 2.67), P(rad(-80.9), RO + 0.024, 2.3), P(rad(-80.9), RO + 0.024, 2.06)], (0.4,))
    plate('RING', wall(-137.6, 2.47, 0.003), 0.09, pad=0.008)

    # ---- the portholes: a brow of copper to turn the rain, three dogs to screw each down
    for tp, zp, rp in PORTS:
        M = at(tp, 0, zp) @ R(-pi / 2, 'X')
        part(lathe([(rp + 0.178, RO - 0.05), (rp + 0.192, RO - 0.05), (rp + 0.205, RO + 0.075), (rp + 0.196, RO + 0.075)], 14, pi - 1.1, pi + 1.1, close=True), COPPER, 'out', M, bevel=0, gloss=0.55)
        for a in (0.9, 3.0, 5.1):
            D = M @ R(a, 'Z') @ T(rp + 0.148, 0, RO + 0.03)
            part(box(0.05, 0.022, 0.014), BRASS, 'out', D @ T(0, 0, 0.006), bevel=0.003, gloss=0.6)
            part(cyl(0.006, 0.03, 6), STEEL, 'out', D @ T(0.012, 0, 0.02), bevel=0, gloss=0.6)
            part(box(0.012, 0.045, 0.01), BRASS, 'out', D @ T(0.012, 0, 0.036), bevel=0.002, gloss=0.6)


def cage(pos, s=1.0):
    """A cage of wire round a hanging lantern (dims.lantern), to keep it from a knock."""
    M = T(*pos)
    for z in (-0.062 * s, 0.062 * s): ring(M @ T(0, 0, z), 0.1 * s, 0.0035 * s, 12, STEEL, 0.6, sides=4)
    for k in range(6):
        a = k * pi / 3 + 0.3
        part(tube([(0.076 * s * cos(a), 0.076 * s * sin(a), -0.085 * s), (0.1 * s * cos(a), 0.1 * s * sin(a), -0.062 * s), (0.1 * s * cos(a), 0.1 * s * sin(a), 0.062 * s), (0.04 * s * cos(a), 0.04 * s * sin(a), 0.118 * s)], 0.003 * s, 4, 1), STEEL, 'out', M, bevel=0, gloss=0.6)


def lamps_more():
    """The two lamps in front: a rim, bars across the glass, a brow, a gland where the wire comes in."""
    for sgn in (-1, 1): cage(P(sgn * rad(66), RO + 0.2, 3.02))
    cage(P(pi - rad(21), RO + 0.3, 2.82), 1.2)
    for sgn in (-1, 1):
        M = at(sgn * rad(20), RO + 0.07, 1.46) @ R(-pi / 2, 'X')
        ring(M @ T(0, 0, 0.103), 0.153, 0.013, 20, BRASS, 0.6, sides=6)
        for a in (0.5, 0.5 + pi / 2):
            part(tube([(-0.148, 0, 0.106), (-0.07, 0, 0.128), (0.07, 0, 0.128), (0.148, 0, 0.106)], 0.005, 5, 3), STEEL, 'out', M @ R(a, 'Z'), bevel=0, gloss=0.6)
        part(lathe([(0.172, -0.03), (0.192, 0.15), (0.198, 0.15), (0.178, -0.03)], 10, pi - 1.05, pi + 1.05, close=True), COPPER, 'out', M, bevel=0, gloss=0.55, jit=0.06)
        for k in range(8): bolt(M @ R(k * pi / 4 + 0.39, 'Z') @ T(0.171, 0, 0.03) @ R(pi / 2, 'Y'), 0.008, 0.006, BRASS, 6, 0.6)
        part(slab(0.168, 0.176, -0.085, -0.06, 0, 2 * pi, 20), BRASS, 'out', M, bevel=0, gloss=0.6)
        part(cyl(0.016, 0.04, 8), BRASS, 'out', at(sgn * rad(17.3), RO + 0.03, 1.56), bevel=0, gloss=0.6)


def mends():
    """What has been mended, and how: boards nailed over a split, a splint lashed to a brace, bolts round the belly's rim."""
    for th, z, w, h, turn in ((-8, 1.1, 0.42, 0.105, 0.05), (-134, 2.74, 0.12, 0.52, -0.03)):
        M = wall(th, z, 0.002) @ R(turn, 'Y')
        part(box(w, 0.016, h), HONEY, 'out', M @ T(0, -0.008, 0), bevel=0.004, jit=0.12, mat='wood')
        for sx in (-1, 1):
            for sz in (-1, 1): part(cyl(0.0075, 0.006, 5), DARK, 'out', M @ T(sx * (w / 2 - 0.022), -0.018, sz * (h / 2 - 0.022)) @ YA, bevel=0, gloss=0.3)
    # the after left leg's brace was cracked once: a batten laid along it, and cord wound round the two
    th = rad(-135); top, foot = P(th, RO + 0.02, 1.78), P(th, 3.62, 0.17)
    a, b = P(th, 2.45, 0.9), lerp(top, foot, 0.5)
    d = (b - a).normalized(); up = Vector((0, 0, 1)); up = (up - d * up.dot(d)).normalized()
    c = lerp(a, b, 0.6)
    part(box(0.05, 0.03, 0.36), HONEY, 'out', basis(c + up * 0.052, d, up), bevel=0.005, jit=0.1, mat='wood')
    for u in (-0.13, 0.0, 0.13):
        for i in range(4): ring(aim(c + d * (u + 0.011 * i - 0.016), c + d), 0.062, 0.0055, 9, ROPE, 0, mat='rope', sides=4)
    # and a rag wound round the forward right one, where it weeps
    c2 = lerp(P(rad(45), 2.45, 0.9), lerp(P(rad(45), RO + 0.02, 1.78), P(rad(45), 3.62, 0.17), 0.5), 0.55); d2 = (lerp(P(rad(45), RO + 0.02, 1.78), P(rad(45), 3.62, 0.17), 0.5) - P(rad(45), 2.45, 0.9)).normalized()
    part(tube([c2 - d2 * 0.07, c2, c2 + d2 * 0.07], 0.05, 8, 2), '#b7ab8c', 'out', bevel=0, mat='canvas', rough=0.006, grit=30, jit=0.06)
    for u in (-0.045, 0.04): ring(aim(c2 + d2 * u, c2 + d2), 0.052, 0.004, 8, ROPE, 0, mat='rope', sides=4)
    # bolts round the rim of the belly
    for k in range(48):
        a = (k + 0.5) * 2 * pi / 48
        if abs(abs(ang(a)) - pi) < rad(14): continue
        bolt(T(*P(a, RO + 0.023, 0.915)) @ R(-a, 'Z') @ R(-pi / 2 - 0.25, 'X'), 0.011, 0.008, STEEL)
    # the hatch: two dogs to screw it down by, a handle worn bright
    Mh = wall(62, 1.42, 0.01)
    for z in (-0.11, 0.11):
        part(box(0.05, 0.016, 0.024), BRASS, 'out', Mh @ T(0.225, -0.028, z), bevel=0.003, gloss=0.6)
        part(cyl(0.007, 0.03, 6), STEEL, 'out', Mh @ T(0.238, -0.04, z) @ YA, bevel=0, gloss=0.6)
        part(box(0.012, 0.01, 0.05), BRASS, 'out', Mh @ T(0.238, -0.056, z), bevel=0.002, gloss=0.6)


# ============================================================================================== the window
def window_more():
    c = 2 * (RO - 0.085) * sin(rad(12)); rm = (RO - 0.085) * cos(rad(12)); PUTTY = '#bfb497'
    for k in range(5):
        th = rad(-48 + 24 * k); M = at(th, rm - 0.0025, (SILL + HEAD) / 2)
        # (where glass meets glass, in the middle, there is no putty up the joint: it runs on along the head and the sill)
        joinL, joinR = k in (2, 3), k in (1, 2)
        xl = -(c / 2 - (0.046 if k == 0 else 0.0 if joinL else 0.031)); xr = c / 2 - (0.046 if k == 4 else 0.0 if joinR else 0.031)
        for x, joined in ((xl, joinL), (xr, joinR)):
            if not joined: part(box(0.014, 0.012, HEAD - SILL - 0.05), PUTTY, 'out', M @ T(x, 0, 0), bevel=0.003, mat='paint', jit=0.04)
        for z in (-(HEAD - SILL) / 2 + 0.027, (HEAD - SILL) / 2 - 0.027): part(box(xr - xl, 0.012, 0.014), PUTTY, 'out', M @ T((xl + xr) / 2, 0, z), bevel=0.003, mat='paint', jit=0.04)
    # a sill of copper over the ends of the staves, with a lip to drip from
    part(lathe([(RO - 0.046, 1.937), (RO + 0.05, 1.915), (RO + 0.064, 1.915), (RO + 0.064, 1.89), (RO + 0.052, 1.89), (RO + 0.052, 1.9), (RO - 0.046, 1.905)], 40, rad(-60.9), rad(60.9), close=True), COPPER, 'out', bevel=0, gloss=0.55, jit=0.05)
    for a in range(-56, 57, 8): rivet(at(rad(a), RO + 0.03, 1.92) @ R(-0.21, 'X'), 0.007, COPPER, gloss=0.55)
    # shutters for the two end panes, folded back on the wall and hooked there
    GREEN = '#66796a'
    for sgn in (-1, 1):
        M = wall(sgn * 66.8, 2.53, 0.012)
        for leaf, (y, dx) in enumerate(((-0.016, 0.0), (-0.05, 0.012 * sgn))):
            L = M @ T(dx, y, 0)
            for sx in (-1, 1): part(box(0.05, 0.03, 1.2), GREEN, 'out', L @ T(sx * 0.205, 0, 0), bevel=0.005, mat='pwood', jit=0.07)
            for z in (-0.575, 0.0, 0.575): part(box(0.36, 0.03, 0.05), GREEN, 'out', L @ T(0, 0, z), bevel=0.005, mat='pwood', jit=0.07)
            for bay in (-1, 1):
                for j in range(8):
                    part(box(0.362, 0.006, 0.062), GREEN, 'out', L @ T(0, 0, bay * 0.2875 - 0.228 + j * 0.065) @ R(rad(-36), 'X'), bevel=0, mat='pwood', jit=0.09)
        hx = sgn * 0.238
        for z in (-0.46, 0.0, 0.46):
            part(cyl(0.01, 0.075, 8), IRON, 'out', M @ T(hx, -0.034, z), bevel=0, gloss=0.4)
            part(box(0.1, 0.004, 0.036), IRON, 'out', M @ T(hx - sgn * 0.055, -0.067, z), bevel=0, gloss=0.4)
            for d in (0.03, 0.075): bolt(M @ T(hx - sgn * d, -0.069, z) @ YA, 0.005, 0.004, STEEL, 5, 0.6)
        part(tube([(-hx * 1.08, 0.0, 0.2), (-hx * 1.08, -0.085, 0.2), (-hx * 0.86, -0.085, 0.2), (-hx * 0.86, -0.07, 0.2)], 0.006, 5, 2), IRON, 'out', M, bevel=0, gloss=0.4)
        bolt(M @ T(-hx * 1.08, -0.002, 0.2) @ YA, 0.012, 0.006)
        part(ball(0.014, 8, 6), BRASS, 'out', M @ T(-sgn * 0.13, -0.07, -0.02), bevel=0, gloss=0.6)


def door_more():
    # iron at the corners of the door's frame; a strap of rubber for the door to shut against
    for sgn in (-1, 1):
        Mp = out_at(pi - sgn * asin(0.60 / 2.47), 2.594, 2.9)
        part(box(0.1, 0.008, 0.26), IRON, 'out', Mp @ T(0, -0.002, 0), bevel=0.002, gloss=0.4)
        for z in (-0.1, 0.0, 0.1): bolt(Mp @ T(0, -0.006, z) @ YA, 0.009, 0.006, STEEL)
        Mh = out_at(pi, 2.563, DOOR_TOP + 0.04) @ T(sgn * 0.53, 0, 0)
        part(box(0.24, 0.008, 0.095), IRON, 'out', Mh @ T(0, -0.002, 0), bevel=0.002, gloss=0.4)
        for x in (-0.08, 0.0, 0.08): bolt(Mh @ T(x, -0.006, 0) @ YA, 0.009, 0.006, STEEL)
        Mb = out_at(pi - sgn * asin(0.60 / 2.47), 2.594, 1.3)
        part(box(0.1, 0.008, 0.2), IRON, 'out', Mb @ T(0, -0.002, 0), bevel=0.002, gloss=0.4)
        for z in (-0.07, 0.07): bolt(Mb @ T(0, -0.006, z) @ YA, 0.009, 0.006, STEEL)


# ================================================================================================ the roof
def roof_more():
    # ---- the gutter: three lengths of it (none over the window), stopped at their ends; iron hangers; a spout
    gr, gz, g = 2.957, 3.316, 0.045
    prof = [(gr + g * cos(a), gz + g * sin(a)) for a in [pi + i * pi / 6 for i in range(7)]] + [(gr + (g - 0.007) * cos(a), gz + (g - 0.007) * sin(a)) for a in [2 * pi - i * pi / 6 for i in range(7)]]
    for a0, a1 in ((62, 130.5), (139.5, 220.5), (229.5, 298)):
        part(lathe(prof, 18, rad(a0), rad(a1), close=True), COPPER, 'out', bevel=0, gloss=0.55, jit=0.06)
        for a in (a0, a1): part(lathe([(gr - g, gz), (gr - g * 0.7, gz - g * 0.72), (gr, gz - g), (gr + g * 0.7, gz - g * 0.72), (gr + g, gz)], 1, rad(a) - 0.002, rad(a) + 0.002, close=True), COPPER, 'out', bevel=0, gloss=0.55)
    for k in range(32):
        th = (k + 0.5) * 2 * pi / 32
        if k % 2 or abs(ang(th)) < rad(63) or min(abs(ang(th - rad(p))) for p in (45, 135, -45, -135)) < rad(5): continue
        part(tube([P(th, 2.865, 3.245), P(th, 2.92, 3.262), P(th, 2.99, 3.283), P(th, 3.012, 3.325)], 0.006, 5, 2), IRON, 'out', bevel=0, gloss=0.4)
    sp = rad(-159)
    part(lathe([(0.03, 0), (0.07, 0.07), (0.076, 0.07), (0.036, 0)], 8, close=True), COPPER, 'out', T(*P(sp, gr, 3.2)), bevel=0, gloss=0.55)
    wh, L = pipe([P(sp, gr, 3.21), P(sp, 2.93, 3.14), P(sp, 2.74, 3.07), P(sp, RO + 0.066, 2.94), P(sp, RO + 0.066, 2.0), P(sp, RO + 0.066, 1.3), P(sp, RO + 0.085, 1.2), P(sp, RO + 0.18, 1.12)], 0.03, COPPER, sub=4, unions=(0.36, 0.7), ucol=COPPER)
    clips(wh, (0.3, 0.52, 0.78), radial, 0.03, 0.034)
    # (the other two empty through a short spout apiece)
    for a in (126, -118):
        part(tube([P(rad(a), gr, 3.275), P(rad(a), gr + 0.03, 3.23), P(rad(a), gr + 0.1, 3.19)], 0.018, 6, 3), COPPER, 'out', bevel=0, gloss=0.55)

    # ---- the copper: here and there a sheet is in two lengths, lapped; two patches soldered on; rivets along the eave
    NR = 20
    for i, r0 in ((1, 2.0), (4, 1.15), (6, 1.5), (11, 1.9), (13, 1.45), (15, 1.3), (17, 1.7)):
        a0 = (i - 0.5) * 2 * pi / NR; a1 = a0 + 2 * pi / NR
        part(lathe([(r0, zr(r0) + 0.002), (r0 + 0.05, zr(r0 + 0.05) + 0.002), (r0 + 0.05, zr(r0 + 0.05) + 0.009), (r0, zr(r0) + 0.011)], 3, a0 + 0.02, a1 - 0.02, close=True), COPPER, 'out', bevel=0, gloss=0.55, jit=0.1)
    for th, r0, w, h, col in ((rad(54), 1.7, 0.3, 0.36, COPPER), (rad(162), 2.0, 0.26, 0.26, '#8f948f'), (rad(-108), 2.35, 0.34, 0.24, COPPER)):
        M = on_roof(th, r0, 0.004) @ R(random.uniform(-0.2, 0.2), 'Z')
        part(box(w, h, 0.006), col, 'out', M, bevel=0.002, gloss=0.5, jit=0.12, mat='tin' if col != COPPER else None)
        for sx in (-1, 0, 1):
            for sy in (-1, 0, 1):
                if sx or sy: rivet(M @ T(sx * (w / 2 - 0.025), sy * (h / 2 - 0.025), 0.004), 0.008, col, gloss=0.55)
    for i in range(NR):
        for da in (-0.2, 0.0, 0.2): rivet(on_roof(i * 2 * pi / NR + da / 2.8, 2.8, 0.002), 0.009, COPPER, gloss=0.55)

    # ---- the stovepipe: two bands, a collar to shed the rain, soot at its mouth
    S = T(-0.925, -1.60, 0)
    for z in (4.12, 4.4): band(S, 0.075, z - 0.018, z + 0.018, 0.006, 14, IRON, 0.4, nb=4, br=0.006)
    part(lathe([(0.076, 4.075), (0.135, 4.012), (0.13, 4.004), (0.076, 4.05)], 14, close=True), COPPER, 'out', S, bevel=0, gloss=0.55)
    part(slab(0.0745, 0.081, 4.435, 4.474, 0, 2 * pi, 14), '#141012', 'out', S, bevel=0, mat='soot')
    part(cyl(0.16, 0.006, 14), '#141012', 'out', S @ T(0, 0, 4.512), bevel=0, mat='soot')
    for k in range(8): rivet(S @ R(k * pi / 4, 'Z') @ T(0.2, 0, 3.77) @ R(pi / 2, 'Y'), 0.008, COPPER, gloss=0.55)

    # ---- the skylight: bolts round its collar, two hinges up the slope, a catch below
    Ms = T(0, 1.30, zr(1.30)) @ R(-BETA, 'X')
    for k in range(12): bolt(Ms @ R((k + 0.5) * pi / 6, 'Z') @ T(0.425, 0, 0.1), 0.01, 0.007, BRASS, 6, 0.6)
    for x in (-0.13, 0.13):
        part(cyl(0.013, 0.07, 8), BRASS, 'out', Ms @ T(x, -0.455, 0.09) @ R(pi / 2, 'Y'), bevel=0, gloss=0.6)
        part(box(0.05, 0.05, 0.006), BRASS, 'out', Ms @ T(x, -0.425, 0.103), bevel=0, gloss=0.6)
    part(box(0.03, 0.07, 0.014), BRASS, 'out', Ms @ T(0, 0.45, 0.106), bevel=0.003, gloss=0.6)
    part(ball(0.014, 8, 6), BRASS, 'out', Ms @ T(0, 0.48, 0.12), bevel=0, gloss=0.6)


def roof_cargo():
    # ---- spare boards, lashed down on two bearers with two straps
    F = on_roof(rad(80), 1.9, 0.062)
    for y in (-0.36, 0.36): part(box(0.56, 0.05, 0.05), WOOD_D, 'out', F @ T(0, y, -0.03), bevel=0.006, jit=0.06)
    for j, (x, z, turn, yo, col) in enumerate(((-0.15, 0.011, 0.02, 0.0, WOOD), (0.0, 0.011, -0.012, 0.05, HONEY), (0.15, 0.011, 0.015, -0.04, FLOOR), (-0.07, 0.035, -0.03, 0.08, HONEY), (0.085, 0.035, 0.035, -0.02, WOOD))):
        part(box(0.135, 1.16, 0.022), col, 'out', F @ T(x, yo, z) @ R(turn, 'Z'), bevel=0.004, jit=0.1, mat='wood')
    for y in (-0.28, 0.3):
        strap([F @ Vector((-0.3, y, -0.06)), F @ Vector((-0.245, y, 0.01)), F @ Vector((-0.22, y, 0.05)), F @ Vector((0, y, 0.054)), F @ Vector((0.22, y, 0.05)), F @ Vector((0.245, y, 0.01)), F @ Vector((0.3, y, -0.06))], 0.04, F.to_3x3() @ Vector((0, 1, 0)), 0.005, sub=2)
        part(box(0.05, 0.05, 0.012), BRASS, 'out', F @ T(0.06, y, 0.058), bevel=0.003, gloss=0.6)
        for sx in (-1, 1): eye(F @ T(sx * 0.31, y, -0.058), 0.014, 0.004)
    # ---- a crate lashed down with cord, and a coil of rope beside the skylight
    C = on_roof(rad(-18), 2.28, 0.0)
    for y in (-0.11, 0.11): part(box(0.34, 0.04, 0.03), WOOD_D, 'out', C @ T(0, y, 0.015), bevel=0.004, jit=0.06)
    part(box(0.3, 0.26, 0.19), HONEY, 'out', C @ T(0, 0, 0.125), bevel=0.006, jit=0.08, mat='wood')
    for z in (0.05, 0.2):
        for sx, sy, x, y in ((0.32, 0.03, 0, 0.135), (0.32, 0.03, 0, -0.135), (0.03, 0.28, 0.155, 0), (0.03, 0.28, -0.155, 0)):
            part(box(sx, sy, 0.045), WOOD, 'out', C @ T(x, y, z), bevel=0.004, jit=0.08)
    for x in (-0.08, 0.08):
        part(tube([C @ Vector((x, -0.2, 0.0)), C @ Vector((x, -0.16, 0.2)), C @ Vector((x, -0.13, 0.228)), C @ Vector((x, 0.13, 0.228)), C @ Vector((x, 0.16, 0.2)), C @ Vector((x, 0.2, 0.0))], 0.006, 5, 2), ROPE, 'out', bevel=0, mat='rope')
        for y in (-0.21, 0.21): eye(C @ T(x, y, 0.0), 0.012, 0.004)
    K = on_roof(rad(18), 2.3, 0.012)
    for k in range(5):
        Rk = 0.15 - 0.012 * (k % 3)
        part(tube([(Rk * cos(i * pi / 9 + k), Rk * sin(i * pi / 9 + k), 0.012 + 0.019 * k + 0.004 * sin(i * 1.1 + k)) for i in range(18)], 0.011, 5, 1, cyclic=True), ROPE, 'out', K, bevel=0, mat='rope', jit=0.07)
    eye(K @ T(0, -0.21, -0.012), 0.014, 0.004)
    part(tube([K @ Vector((0, -0.15, 0.02)), K @ Vector((0.01, -0.19, 0.04)), K @ Vector((0, -0.21, 0.03))], 0.006, 5, 2), ROPE, 'out', bevel=0, mat='rope')
    # ---- a small louvred box on legs, for reading the weather
    th, r = rad(-72), 1.78; zb = zr(r) + 0.31
    B = at(th, r, zb)
    for sx in (-1, 1):
        for sy in (-1, 1):
            foot = zr(r + sy * 0.1) + 0.0
            part(box(0.022, 0.022, zb - 0.1 - foot + 0.01), ENAMEL, 'out', B @ T(sx * 0.105, sy * 0.1, (foot - zb - 0.1) / 2 + 0.0), bevel=0.003, mat='pwood', jit=0.05)
    part(box(0.27, 0.25, 0.02), ENAMEL, 'out', B @ T(0, 0, -0.1), bevel=0.004, mat='pwood', jit=0.05)
    part(box(0.2, 0.18, 0.2), '#22211f', 'out', B @ T(0, 0, 0.01), bevel=0, mat='soot')
    for sx in (-1, 1):
        for sy in (-1, 1): part(box(0.024, 0.024, 0.22), ENAMEL, 'out', B @ T(sx * 0.118, sy * 0.108, 0.01), bevel=0.003, mat='pwood', jit=0.05)
    for j in range(6):
        z = -0.075 + j * 0.035
        for sy in (-1, 1): part(box(0.22, 0.005, 0.042), ENAMEL, 'out', B @ T(0, sy * 0.108, z) @ R(sy * rad(38), 'X'), bevel=0, mat='pwood', jit=0.08)
        for sx in (-1, 1): part(box(0.005, 0.2, 0.042), ENAMEL, 'out', B @ T(sx * 0.118, 0, z) @ R(-sx * rad(38), 'Y'), bevel=0, mat='pwood', jit=0.08)
    for sy in (-1, 1): part(box(0.32, 0.19, 0.008), '#8f948f', 'out', B @ T(0, sy * 0.082, 0.155) @ R(sy * rad(-24), 'X'), bevel=0.002, gloss=0.4, mat='tin', jit=0.06)
    part(tube([(-0.165, 0, 0.192), (0.165, 0, 0.192)], 0.008, 5, 1), '#8f948f', 'out', B, bevel=0, gloss=0.4, mat='tin')
    # ---- a board with cleats to climb the roof by, hooked over the cap
    F = on_roof(rad(-168), 1.86, 0.058)
    for sx in (-1, 1): part(box(0.04, 1.84, 0.03), WOOD_D, 'out', F @ T(sx * 0.14, 0, 0), bevel=0.005, jit=0.06)
    for j in range(10): part(box(0.34, 0.045, 0.024), WOOD, 'out', F @ T(0, -0.86 + j * 0.19, 0.026), bevel=0.004, jit=0.1)
    for sx in (-1, 1):
        part(tube([F @ Vector((sx * 0.14, -0.92, 0.0)), F @ Vector((sx * 0.14, -1.2, 0.02)), F @ Vector((sx * 0.13, -1.45, 0.05))], 0.007, 5, 2), IRON, 'out', bevel=0, gloss=0.4)
    # ---- two hoops to hold by, where the ladder comes up
    for r in (2.62, 2.2):
        G = on_roof(rad(-152), r, 0.0)
        part(tube([(-0.16, 0, 0.0), (-0.16, 0, 0.1), (-0.12, 0, 0.14), (0.12, 0, 0.14), (0.16, 0, 0.1), (0.16, 0, 0.0)], 0.011, 6, 2), BRASS, 'out', G, bevel=0, gloss=0.6)
        for sx in (-1, 1): part(cyl(0.024, 0.008, 8), BRASS, 'out', G @ T(sx * 0.16, 0, 0.006), bevel=0, gloss=0.6)


def mast_more():
    # bands and a cleat on the mast; each stay drawn tight by a screw, and made fast to an eye in the roof
    for z in (4.76, 5.12, 5.5): band(I4, 0.03 - 0.012 * (z - 4.68) / 1.42, z - 0.02, z + 0.02, 0.006, 8, IRON, 0.4)
    part(box(0.012, 0.11, 0.02), BRASS, 'out', T(0.03, 0, 4.95), bevel=0.003, gloss=0.6)
    for a in (rad(60), rad(180), rad(300)):
        A, B = Vector((0, 0, 5.5)), P(a, 1.2, zr(1.2))
        d = (B - A).normalized()
        part(cyl(0.011, 0.09, 6), BRASS, 'out', aim(B - d * 0.2, B), bevel=0, gloss=0.6)
        for s in (0.145, 0.255): part(cyl(0.006, 0.02, 5), STEEL, 'out', aim(B - d * s, B), bevel=0, gloss=0.6)
        Mr = on_roof(a, 1.2, 0.0)
        part(box(0.07, 0.07, 0.006), IRON, 'out', Mr @ T(0, 0, 0.003), bevel=0, gloss=0.4)
        ring(Mr @ T(0, 0, 0.03) @ R(pi / 2, 'X') @ R(a, 'Y'), 0.02, 0.005, 8, IRON, 0.4, sides=4)
    # the lamp at the masthead in its cage; a vane under it
    for a in (0, pi / 2): part(tube([(0.0, 0, 6.08), (0.09, 0, 6.1), (0.1, 0, 6.17), (0.06, 0, 6.24), (0, 0, 6.26), (-0.06, 0, 6.24), (-0.1, 0, 6.17), (-0.09, 0, 6.1), (0, 0, 6.08)], 0.004, 4, 2), STEEL, 'out', R(a, 'Z'), bevel=0, gloss=0.6)
    part(cyl(0.02, 0.02, 8), BRASS, 'out', T(0, 0, 6.27), bevel=0.003, gloss=0.6)
    part(cyl(0.028, 0.03, 8), BRASS, 'out', T(0, 0, 6.08), bevel=0.003, gloss=0.6)
    V = T(0, 0, 5.72) @ R(0.7, 'Z')
    part(cyl(0.024, 0.04, 8), BRASS, 'out', V, bevel=0.003, gloss=0.6)
    part(tube([(-0.26, 0, 0), (0.24, 0, 0)], 0.006, 5, 1), BRASS, 'out', V, bevel=0, gloss=0.6)
    part(cyl(0.022, 0.07, 8, r2=0.001), BRASS, 'out', V @ T(0.27, 0, 0) @ R(pi / 2, 'Y'), bevel=0, gloss=0.6)
    part(box(0.13, 0.004, 0.11), COPPER, 'out', V @ T(-0.21, 0, 0), bevel=0, gloss=0.55, jit=0.08)
    # the yard's ends: an insulator each, and a wire from it down to the roof
    for sgn in (-1, 1):
        e = Vector((sgn * 0.35, 0, 5.55))
        for k in (0, 1): part(ball(0.02, 8, 6, s=(1, 1, 0.8)), '#e9e4d6', 'out', T(e.x + sgn * (0.015 + 0.036 * k), 0, 5.55 - 0.012 * k) @ R(pi / 2, 'Y'), bevel=0, gloss=0.5, mat='glaze')
        Bf = P(sgn * rad(90), 2.35, zr(2.35) + 0.035)
        part(tube([e + Vector((sgn * 0.07, 0, -0.02)), Bf], 0.003, 4, 1), COPPER, 'out', bevel=0, gloss=0.6)
        eye(on_roof(sgn * rad(90), 2.35, 0.0), 0.012, 0.004)


def dish_more():
    base = P(rad(140), 1.9, zr(1.9)); top = base + Vector((0, 0, 0.55))
    Md = aim(top, top + Vector((sin(rad(140)) * 0.6, cos(rad(140)) * 0.6, 0.7)))
    # ribs on its back, a hoop round its rim, three struts to what it listens with, a boss where it is held
    for k in range(6): part(tube([(0.07, 0, -0.016), (0.15, 0, -0.008), (0.3, 0, 0.032), (0.445, 0, 0.104)], 0.007, 5, 2), IRON, 'out', Md @ R(k * pi / 3 + 0.2, 'Z'), bevel=0, gloss=0.4)
    ring(Md @ T(0, 0, 0.116), 0.458, 0.009, 24, BRASS, 0.6)
    # (it was beaten from three rings of sheet: a seam where each meets the next, and rivets along it)
    for r, z in ((0.15, 0.014), (0.3, 0.052)):
        ring(Md @ T(0, 0, z), r, 0.004, 24, CREAM, 0.0, sides=4, mat='enamel')
        for k in range(12): rivet(Md @ R(k * pi / 6 + r, 'Z') @ T(r + 0.016, 0, z + 0.006), 0.006, CREAM, gloss=0.2)
    for k in range(3): part(tube([(0.44, 0, 0.12), (0.03, 0, 0.3)], 0.005, 4, 1), BRASS, 'out', Md @ R(k * 2.094 + 0.5, 'Z'), bevel=0, gloss=0.6)
    part(cyl(0.06, 0.05, 10), IRON, 'out', Md @ T(0, 0, -0.035), bevel=0.006, gloss=0.4)
    for k in range(6): bolt(Md @ R(k * pi / 3, 'Z') @ T(0.045, 0, -0.06) @ R(pi, 'X'), 0.007, 0.006, STEEL)
    # the fork it tips in, on the head of the post; the post's foot bolted to the roof; its wire down the post into a gland
    Y = T(*top) @ R(-rad(140), 'Z')
    for sx in (-1, 1):
        part(box(0.014, 0.05, 0.15), IRON, 'out', Y @ T(sx * 0.07, 0.01, -0.03), bevel=0.004, gloss=0.4)
        part(cyl(0.012, 0.02, 6), STEEL, 'out', Y @ T(sx * 0.082, 0.015, 0.0) @ R(pi / 2, 'Y'), bevel=0, gloss=0.6)
    part(box(0.16, 0.05, 0.016), IRON, 'out', Y @ T(0, 0.01, -0.1), bevel=0.004, gloss=0.4)
    part(cyl(0.034, 0.05, 10), IRON, 'out', Y @ T(0, 0, -0.13), bevel=0.005, gloss=0.4)
    part(tube([(0.078, 0.02 + 0.12 * cos(a), -0.02 - 0.12 * sin(a)) for a in [i * pi / 12 for i in range(7)]], 0.005, 4, 1), BRASS, 'out', Y, bevel=0, gloss=0.6)
    Fb = on_roof(rad(140), 1.9, 0.0)
    part(cyl(0.07, 0.012, 10), IRON, 'out', Fb @ T(0, 0, 0.006), bevel=0, gloss=0.4)
    for k in range(4): bolt(Fb @ R(k * pi / 2 + 0.6, 'Z') @ T(0.052, 0, 0.012), 0.008, 0.006, STEEL)
    cable([Md @ Vector((0, 0, 0.3)), Md @ Vector((0.05, 0.05, 0.12)), Md @ Vector((0.03, 0.03, -0.08)), top + Vector((0.03, 0.0, -0.12)), base + Vector((0.03, 0.01, 0.12)), base + Vector((0.1, 0.06, 0.03))], 0.005)
    part(cyl(0.016, 0.03, 8), BRASS, 'out', T(*(base + Vector((0.1, 0.06, 0.02)))), bevel=0, gloss=0.6)


def ladder_more():
    """The rungs up the back get rails, and the rails go out round the eave and back in onto the roof."""
    Ml = at(rad(-152), 0, 0)
    way = [(RO + 0.09, 1.08), (RO + 0.09, 2.0), (RO + 0.09, 2.92), (2.76, 3.07), (2.98, 3.14), (3.085, 3.3), (3.09, 3.5), (3.0, 3.63), (2.82, 3.62), (2.71, zr(2.71) + 0.012)]
    for sx in (-1, 1):
        part(tube([(sx * 0.17, y, z) for y, z in way], 0.014, 6, 3), BRASS, 'out', Ml, bevel=0, gloss=0.6)
        part(cyl(0.028, 0.008, 8), BRASS, 'out', on_roof(rad(-152), 2.71, 0.004) @ T(sx * 0.17, 0, 0), bevel=0, gloss=0.6)
        part(ball(0.018, 8, 6), BRASS, 'out', Ml @ T(sx * 0.17, RO + 0.09, 1.07), bevel=0, gloss=0.6)
    for y, z in ((3.03, 3.19), (3.09, 3.4), (3.04, 3.6)):
        part(tube([(-0.17, y, z), (0.17, y, z)], 0.012, 6, 1), BRASS, 'out', Ml, bevel=0, gloss=0.6)


# ============================================================================================== the tanks
def tank_more():
    for sgn in (-1, 1):
        c = Vector((sgn * 3.03, -0.1, 1.60)); M = T(*c) @ R(-pi / 2, 'X'); out = Vector((sgn, 0, 0))
        # the pipe into the hull: a flange on the tank, a valve, a flange on the wall
        flange(T(c.x, 0.3, c.z + 0.428), 0.07, 6, 0.014, BRASS, 0.6)
        wh, L = path([(c.x, 0.3, 2.0), (c.x - sgn * 0.02, 0.3, 2.3), (sgn * 2.74, 0.3, 2.42), (sgn * 2.5, 0.3, 2.42)], 5)
        for u in (0.2,):
            p, d = wh(u); part(cyl(0.06, 0.09, 6), BRASS, 'out', aim(p, p + d), bevel=0.004, gloss=0.6)
        valve((sgn * 2.76, 0.3, 2.42), (-sgn, 0, 0), 0.036, (0, 0, 1), RED)
        flange(T(sgn * 2.545, 0.3, 2.42) @ R(sgn * pi / 2, 'Y'), 0.075, 6, 0.014, BRASS, 0.6)
        # a glass up its side that shows how full it is, between two brass elbows
        gx = c.x + sgn * 0.47; gy = c.y + 0.24
        part(tube([(gx, gy, 1.43), (gx, gy, 1.77)], 0.013, 8, 1), '#b9d6d2' if sgn > 0 else '#c9a35a', 'out', bevel=0, gloss=0.6, mat='glassy')
        for z, s in ((1.42, -1), (1.78, 1)):
            part(cyl(0.02, 0.035, 8), BRASS, 'out', T(gx, gy, z), bevel=0.003, gloss=0.6)
            part(tube([(gx, gy, z), (gx - sgn * 0.03, gy, z + s * 0.012), (c.x + sgn * 0.36, gy, z + s * 0.03)], 0.011, 6, 2), BRASS, 'out', bevel=0, gloss=0.6)
        part(slab(0.0125, 0.0165, 1.585, 1.6, 0, 2 * pi, 8), RED, 'out', T(gx, gy, 0), bevel=0, mat='enamel')
        for z in (1.5, 1.6, 1.7): part(box(0.004, 0.02, 0.003), DARK, 'out', T(gx + sgn * 0.014, gy, z), bevel=0)
        # on top: a filler with a lid on a chain, and a pipe bent over to let the air out
        Tp = T(c.x, c.y - 0.2, c.z + 0.41)
        part(cyl(0.055, 0.07, 10), BRASS, 'out', Tp @ T(0, 0, 0.03), bevel=0.004, gloss=0.6)
        part(cyl(0.066, 0.02, 10), BRASS, 'out', Tp @ T(0, 0, 0.074), bevel=0.005, gloss=0.6)
        part(box(0.016, 0.1, 0.014), BRASS, 'out', Tp @ T(0, 0, 0.09), bevel=0.003, gloss=0.6)
        part(tube([Tp @ Vector((0.066, 0, 0.07)), Tp @ Vector((0.13, 0.02, 0.0)), Tp @ Vector((0.16, 0.04, -0.03))], 0.003, 4, 3), STEEL, 'out', bevel=0, gloss=0.6)
        part(tube([(c.x, c.y + 0.56, c.z + 0.4), (c.x, c.y + 0.56, c.z + 0.52), (c.x + sgn * 0.04, c.y + 0.56, c.z + 0.56), (c.x + sgn * 0.08, c.y + 0.56, c.z + 0.52)], 0.012, 6, 3), BRASS, 'out', bevel=0, gloss=0.6)
        # under it: a cock to drain it by
        part(cyl(0.016, 0.07, 8), BRASS, 'out', T(c.x, c.y - 0.68, c.z - 0.44), bevel=0, gloss=0.6)
        part(cyl(0.022, 0.03, 8), BRASS, 'out', T(c.x, c.y - 0.68, c.z - 0.47) @ R(pi / 2, 'X'), bevel=0.003, gloss=0.6)
        part(box(0.012, 0.06, 0.012), RED, 'out', T(c.x + sgn * 0.02, c.y - 0.71, c.z - 0.47), bevel=0.003, mat='enamel')
        # its two ends are each beaten from six gores, welded
        for e in (-1, 1):
            for j in range(6):
                part(tube([(0.085, 0, e * 0.944), (0.2, 0, e * 0.923), (0.36, 0, e * 0.803), (0.421, 0, e * 0.64)], 0.0055, 4, 2), RED if (sgn < 0 or abs(e) < 0) else CREAM, 'out', M @ R(j * pi / 3 + 0.26, 'Z'), bevel=0, gloss=0.25, mat='enamel', jit=0.05)
        # where the hose is screwed on, at its after end
        flange(M @ T(0, -0.05, -0.935) @ R(pi, 'X'), 0.07, 6, 0.016, BRASS, 0.6)


# ============================================================================================== the engine
def bell_r(z):
    """How wide the big bell is outside, at a height."""
    pr = [(0.60, 0.26), (0.46, 0.30), (0.30, 0.44), (0.15, 0.60)]
    for (z0, r0), (z1, r1) in zip(pr, pr[1:]):
        if z <= z0 and z >= z1: return r0 + (r1 - r0) * (z0 - z) / (z0 - z1)
    return 0.6


def engine_more():
    BLUE = '#34303a'
    # three hoops round the bell and sixteen ribs down it, a lip rolled over, soot inside
    for z in (0.43, 0.32, 0.22): ring(T(0, 0, z), bell_r(z) + 0.01, 0.012, 32, DARK, 0.4, sides=6)
    for k in range(16):
        part(tube([(bell_r(z) + 0.005, 0, z) for z in (0.5, 0.46, 0.38, 0.30, 0.225, 0.17)], 0.008, 5, 1), DARK, 'out', R(k * pi / 8, 'Z'), bevel=0, gloss=0.4)
    ring(T(0, 0, 0.152), 0.6, 0.02, 36, BLUE, 0.5, sides=6)
    part(lathe([(0.553, 0.153), (0.403, 0.30), (0.263, 0.46), (0.257, 0.46), (0.397, 0.30), (0.547, 0.153)], 32, close=True), '#15110f', 'out', bevel=0, mat='soot', jit=0.03)
    for k in range(8): part(cyl(0.02, 0.035, 8, r2=0.012), BRASS, 'out', T(0.15 * cos(k * pi / 4), 0.15 * sin(k * pi / 4), 0.436), bevel=0, gloss=0.6)
    part(cyl(0.04, 0.045, 10, r2=0.025), BRASS, 'out', T(0, 0, 0.43), bevel=0, gloss=0.6)
    # the ring it swings in: two pins to the bell, two hangers from the belly; two rams to swing it
    ring(T(0, 0, 0.455), 0.4, 0.017, 28, STEEL, 0.6, sides=6)
    for s in (-1, 1):
        part(tube([(s * 0.3, 0, 0.455), (s * 0.43, 0, 0.455)], 0.016, 6, 1), STEEL, 'out', bevel=0, gloss=0.6)
        part(cyl(0.03, 0.02, 8), BRASS, 'out', T(s * 0.432, 0, 0.455) @ R(pi / 2, 'Y'), bevel=0, gloss=0.6)
        part(box(0.07, 0.03, 0.11), IRON, 'out', T(0, s * 0.4, 0.475), bevel=0.006, gloss=0.4)
        part(cyl(0.014, 0.05, 6), STEEL, 'out', T(0, s * 0.4, 0.455) @ R(pi / 2, 'X'), bevel=0, gloss=0.6)
    for a in (rad(40), rad(130)):
        A, B = P(a, 0.9, 0.5), P(a, bell_r(0.27) + 0.012, 0.27)
        part(tube([A, lerp(A, B, 0.58)], 0.024, 8, 1), IRON, 'out', bevel=0, gloss=0.4)
        part(tube([lerp(A, B, 0.5), B], 0.011, 6, 1), STEEL, 'out', bevel=0, gloss=0.6)
        part(cyl(0.03, 0.02, 8), COPPER, 'out', aim(lerp(A, B, 0.58), B), bevel=0, gloss=0.6)
        for e in (A, B): part(ball(0.026, 8, 6), IRON, 'out', T(*e), bevel=0, gloss=0.4)
        part(box(0.08, 0.08, 0.03), IRON, 'out', T(A.x, A.y, 0.512), bevel=0.006, gloss=0.4)
    # a guard of iron bar below the lip, on six struts, for the stones
    ring(T(0, 0, 0.105), 0.73, 0.016, 36, IRON, 0.4, sides=6)
    for k in range(6):
        a = k * pi / 3 + 0.26
        part(tube([P(a, 0.73, 0.105), P(a, 0.84, 0.3), P(a, 0.98, 0.52)], 0.012, 6, 2), IRON, 'out', bevel=0, gloss=0.4)
        bolt(T(*P(a, 0.98, 0.512)) @ R(pi, 'X'), 0.02, 0.012, STEEL)
    # ---- what feeds it: two fat pipes in, flanged; one of them lagged; a pump slung under the belly, a ball of copper for the pressure
    for a, lag in ((rad(100), True), (rad(-80), False)):
        pts = [P(a, 1.34, 0.53), P(a, 1.2, 0.46), P(a, 0.85, 0.415), P(a, 0.5, 0.42), P(a, 0.36, 0.475)]
        wh, L = pipe(pts, 0.04, COPPER, unions=(0.42,), sub=4)
        flange(basis(P(a, 1.33, 0.535), -(P(a, 1.2, 0.46) - P(a, 1.34, 0.53)), (0, 0, 1)), 0.075, 6, 0.016, BRASS, 0.6)
        flange(basis(P(a, 0.37, 0.47), (P(a, 0.36, 0.475) - P(a, 0.5, 0.42)), (0, 0, 1)), 0.07, 6, 0.016, BRASS, 0.6)
        if lag: lagging([wh(u)[0] for u in (0.5, 0.62, 0.74, 0.86)], 0.056, ties=4, sub=1)
        p, d = wh(0.24); strap([p + Vector((0, 0, 0.1)) + d.cross(Vector((0, 0, 1))) * 0.045, p + d.cross(Vector((0, 0, 1))) * 0.047, p + Vector((0, 0, -0.045)), p - d.cross(Vector((0, 0, 1))) * 0.047, p + Vector((0, 0, 0.1)) - d.cross(Vector((0, 0, 1))) * 0.045], 0.03, d, 0.004, IRON, mat='iron', sub=3, gloss=0.4)
    Pm = T(*P(rad(22), 1.08, 0.385)) @ R(-rad(22), 'Z') @ R(pi / 2, 'Y')
    part(lathe([(0, -0.21), (0.06, -0.2), (0.105, -0.165), (0.115, -0.12), (0.115, 0.12), (0.105, 0.165), (0.06, 0.2), (0, 0.21)], 16), '#8a9197', 'out', Pm, bevel=0, gloss=0.4, mat='tin', jit=0.05)
    for z in (-0.09, 0.09):
        band(Pm, 0.115, z - 0.014, z + 0.014, 0.006, 16, IRON, 0.4, nb=0)
        Hh = Pm @ T(0, 0, z)
        part(tube([Hh @ Vector((-0.12, 0, 0)), Hh @ Vector((-0.23, 0, 0))], 0.008, 5, 1), IRON, 'out', bevel=0, gloss=0.4)
    for k in range(8): bolt(Pm @ R(k * pi / 4, 'Z') @ T(0.108, 0, 0.158) @ R(pi / 2 - 0.5, 'Y'), 0.008, 0.006, STEEL)
    part(cyl(0.035, 0.05, 8), BRASS, 'out', Pm @ T(0, 0, 0.225), bevel=0.004, gloss=0.6)
    pipe([Pm @ Vector((0, 0, 0.25)), Pm @ Vector((0.02, 0.0, 0.34)), P(rad(40), 0.7, 0.4), P(rad(60), 0.38, 0.47)], 0.02, COPPER, unions=(0.15, 0.8), sub=4)
    pipe([Pm @ Vector((0, 0, -0.21)), Pm @ Vector((0.0, 0.0, -0.3)), P(rad(45), 1.25, 0.47)], 0.018, COPPER, unions=(0.3,), sub=3)
    Sb = T(*P(rad(205), 1.02, 0.4))
    part(ball(0.11, 16, 10), COPPER, 'out', Sb, bevel=0, gloss=0.6, jit=0.06, rough=0.003, grit=9)
    band(Sb, 0.109, -0.014, 0.014, 0.006, 16, BRASS, 0.6, nb=8, br=0.006)
    part(tube([(0, 0, 0.1), (0, 0, 0.16)], 0.014, 6, 1), BRASS, 'out', Sb, bevel=0, gloss=0.6)
    part(cyl(0.032, 0.012, 8), BRASS, 'out', Sb @ T(0, 0, 0.125), bevel=0, gloss=0.6)
    pipe([Sb @ Vector((0, 0, -0.105)), Sb @ Vector((0.02, 0.03, -0.15)), P(rad(215), 0.7, 0.4), P(rad(225), 0.5, 0.45)], 0.014, COPPER, unions=(0.2,), sub=4)


def belly_more():
    bz = lambda r: 0.48 + 0.02 * r / 0.8 if r < 0.8 else 0.5 + 0.1 * (r - 0.8) / 0.8 if r < 1.6 else 0.6 + 0.16 * (r - 1.6) / 0.7 if r < 2.3 else 0.76 + 0.12 * (r - 2.3) / 0.28
    # the belly is plated in three rings: a lapped strap along each join, riveted; and it is black with soot round the bell
    for r in (1.6, 2.3):
        part(lathe([(r - 0.035, bz(r - 0.035) - 0.002), (r, bz(r) - 0.002), (r + 0.035, bz(r + 0.035) - 0.002), (r + 0.035, bz(r + 0.035) - 0.01), (r, bz(r) - 0.01), (r - 0.035, bz(r - 0.035) - 0.01)], 64, close=True), IRON, 'out', bevel=0, gloss=0.3, jit=0.06)
        for k in range(32):
            a = k * pi / 16
            for d in (-0.02, 0.02): rivet(T(*P(a, r + d, bz(r + d) - 0.01)) @ R(pi, 'X'), 0.008, IRON, gloss=0.4)
    part(lathe([(0.615, bz(0.615) - 0.002), (0.8, bz(0.8) - 0.002), (1.02, bz(1.02) - 0.002), (1.02, bz(1.02) - 0.006), (0.8, bz(0.8) - 0.006), (0.615, bz(0.615) - 0.006)], 64, close=True), '#131012', 'out', bevel=0, mat='soot', jit=0.03)
    # the four small bells: a flange where each is bolted up, a hoop, a rolled lip, soot inside
    for k in range(4):
        B = T(*P(k * pi / 2, 1.55, 0))
        part(slab(0.085, 0.14, 0.565, 0.588, 0, 2 * pi, 14), IRON, 'out', B, bevel=0, gloss=0.4)
        for j in range(6): bolt(B @ R(j * pi / 3, 'Z') @ T(0.118, 0, 0.565) @ R(pi, 'X'), 0.009, 0.007, STEEL)
        ring(B @ T(0, 0, 0.5), 0.177, 0.007, 16, DARK, 0.4)
        ring(B @ T(0, 0, 0.422), 0.22, 0.009, 18, '#34303a', 0.5)
        part(lathe([(0.196, 0.425), (0.146, 0.5), (0.076, 0.62), (0.072, 0.62), (0.142, 0.5), (0.192, 0.425)], 16, close=True), '#15110f', 'out', B, bevel=0, mat='soot')
        part(cyl(0.085, 0.01, 12), '#120f10', 'out', B @ T(0, 0, 0.6), bevel=0, mat='soot')
    # the four pipes along the belly: where each is joined, and what it hangs by
    for k in range(4):
        th = pi / 4 + k * pi / 2
        wh, L = path([P(th, 0.45, 0.47), P(th, 1.2, 0.46), P(th, 2.0, 0.6), P(th, 2.45, 0.8)], 4)
        for u in (0.3, 0.74):
            p, d = wh(u); part(cyl(0.05, 0.07, 6), BRASS, 'out', aim(p, p + d), bevel=0.003, gloss=0.6)
        for u in (0.16, 0.5, 0.88):
            p, d = wh(u); r = hypot(p.x, p.y)
            part(tube([p + Vector((0, 0, 0.03)), Vector((p.x, p.y, bz(r) + 0.01))], 0.008, 5, 1), IRON, 'out', bevel=0, gloss=0.4)
            ring(aim(p, p + d), 0.034, 0.005, 8, IRON, 0.4, sides=4)
    # a bolt wherever a rib crosses a seam of the belly; a plate that comes off, with a handle; a plug to drain it
    for k in range(16):
        th = k * pi / 8 + pi / 16
        for r in (1.6, 2.3): bolt(T(*P(th, r, bz(r) - 0.036)) @ R(pi, 'X'), 0.013, 0.01, STEEL)
    a0, a1 = rad(96), rad(107)
    part(lathe([(1.72, bz(1.72) - 0.003), (2.16, bz(2.16) - 0.003), (2.16, bz(2.16) - 0.012), (1.72, bz(1.72) - 0.012)], 2, a0, a1, close=True), '#4a4c58', 'out', bevel=0, gloss=0.4, mat='iron', jit=0.08)
    for a in (a0 + 0.02, (a0 + a1) / 2, a1 - 0.02):
        for r in (1.76, 2.12): bolt(T(*P(a, r, bz(r) - 0.012)) @ R(pi, 'X'), 0.009, 0.007, STEEL)
    am = (a0 + a1) / 2
    part(tube([P(am, 1.86, bz(1.86) - 0.012), P(am, 1.88, bz(1.88) - 0.05), P(am, 2.0, bz(2.0) - 0.052), P(am, 2.02, bz(2.02) - 0.012)], 0.007, 5, 2), STEEL, 'out', bevel=0, gloss=0.6)
    part(cyl(0.035, 0.02, 6), BRASS, 'out', T(*P(rad(-20), 0.62, 0.475)), bevel=0.003, gloss=0.6)
    part(cyl(0.05, 0.008, 10), IRON, 'out', T(*P(rad(-20), 0.62, 0.49)), bevel=0, gloss=0.4)
    # the wires to the engine: two of them along the belly in clips, into a box by the ring
    for a, r in ((rad(250), 0.007), (rad(252.5), 0.005)):
        cable([P(a, 2.3, bz(2.3) - 0.02), P(a, 1.6, bz(1.6) - 0.018), P(a, 0.9, bz(0.9) - 0.016), P(a, 0.62, 0.455)], r, '#2a2422' if r > 0.006 else '#6a2a20', sub=3)
    for r in (2.0, 1.3, 0.8): part(box(0.09, 0.03, 0.012), IRON, 'out', T(*P(rad(251.2), r, bz(r) - 0.026)) @ R(-rad(251.2), 'Z'), bevel=0, gloss=0.4)
    part(box(0.12, 0.09, 0.05), ENAMEL, 'out', T(*P(rad(251), 0.58, 0.468)) @ R(-rad(251), 'Z'), bevel=0.006, gloss=0.3, mat='enamel')


# =========================================================================================== the four pods
def pods2():
    """Four pods of small jets out past the eaves, one at each corner: each pushes outward, to either side, and down."""
    bell = lambda: lathe([(0.04, 0), (0.05, 0.05), (0.085, 0.14), (0.1, 0.2), (0.092, 0.2), (0.078, 0.14), (0.042, 0.05), (0.03, 0)], 18, close=True)
    scorch = lambda Mi: (lambda p: '#2a2630' if (Mi @ p).z > 0.15 else '#6d4a3a' if (Mi @ p).z > 0.1 else COPPER)
    BLUE = '#34303a'
    for k, th in enumerate((rad(45), rad(135), rad(-135), rad(-45))):
        c = P(th, POD_R, POD_Z); M = at(th, POD_R, POD_Z)
        # the chest the four jets share: a ball of enamelled iron in two halves, bolted round its middle; a pump on its head
        part(ball(0.15, 18, 12), ENAMEL, 'out', M, bevel=0, gloss=0.3, jit=0.03, rough=0.003, grit=7)
        band(M, 0.149, -0.02, 0.02, 0.009, 20, IRON, 0.4, nb=12, br=0.007)
        part(lathe([(0, 0.232), (0.03, 0.228), (0.052, 0.205), (0.056, 0.16), (0.075, 0.148), (0.075, 0.125), (0, 0.125)], 14, close=True), BRASS, 'out', M, bevel=0, gloss=0.6)
        for j in range(6): bolt(M @ R(j * pi / 3, 'Z') @ T(0.066, 0, 0.148), 0.006, 0.005, STEEL, 5, 0.6)
        for Mj in (R(-pi / 2, 'X'), R(pi / 2, 'Y'), R(-pi / 2, 'Y'), R(pi, 'X')):
            Mb = M @ Mj @ T(0, 0, 0.13)
            part(bell(), scorch(Mb.inverted()), 'out', Mb, bevel=0, gloss=0.55, jit=0.03, mat='copper')
            part(cyl(0.034, 0.012, 14), '#120f10', 'out', Mb @ T(0, 0, 0.03), bevel=0, mat='soot')
            part(lathe([(0.0895, 0.2005), (0.0755, 0.14), (0.0395, 0.05), (0.036, 0.05), (0.072, 0.14), (0.086, 0.2005)], 14, close=True), '#15110f', 'out', Mb, bevel=0, mat='soot')
            # (a collar bolted to the chest, two hoops and six ribs on the bell, its lip rolled)
            part(cyl(0.064, 0.03, 12), IRON, 'out', Mb @ T(0, 0, 0.0), bevel=0.004, gloss=0.4)
            for j in range(6): bolt(Mb @ R(j * pi / 3 + 0.3, 'Z') @ T(0.052, 0, 0.015), 0.006, 0.005, STEEL, 5, 0.6)
            for z, r in ((0.075, 0.06), (0.14, 0.085)): part(slab(r - 0.001, r + 0.006, z - 0.006, z + 0.006, 0, 2 * pi, 18), BLUE, 'out', Mb, bevel=0, gloss=0.45, mat='iron')
            for j in range(6): part(tube([(0.053, 0, 0.05), (0.071, 0, 0.1), (0.088, 0, 0.14), (0.102, 0, 0.193)], 0.004, 4, 1), BLUE, 'out', Mb @ R(j * pi / 3, 'Z'), bevel=0, gloss=0.45, mat='iron')
            ring(Mb @ T(0, 0, 0.2), 0.097, 0.0075, 18, BLUE, 0.5, mat='iron')
        # it stands off the roof on three struts, each with a foot bolted down; a plate of iron takes their heads
        Mp = M @ T(0, -0.165, 0)
        part(box(0.22, 0.022, 0.17), IRON, 'out', Mp, bevel=0.005, gloss=0.4)
        for sx in (-1, 1):
            for sz in (-1, 1): bolt(Mp @ T(sx * 0.09, -0.011, sz * 0.065) @ YA, 0.008, 0.006, STEEL)
        heads = (M @ Vector((-0.08, -0.176, 0.04)), M @ Vector((0.08, -0.176, 0.04)), M @ Vector((0, -0.176, -0.05)))
        feet = ((th - 0.16, 2.6), (th + 0.16, 2.6), (th, 2.42))
        for (a, r), h in zip(feet, heads):
            Fr = on_roof(a, r, 0.04 if a == th else 0.0); f = Fr @ Vector((0, 0, 0.012))
            part(tube([f, h], 0.019, 8, 1), IRON, 'out', bevel=0, gloss=0.4)
            part(cyl(0.05, 0.012, 10), IRON, 'out', Fr @ T(0, 0, 0.006), bevel=0, gloss=0.4)
            for j in range(3): bolt(Fr @ R(j * 2.094 + 0.5, 'Z') @ T(0.036, 0, 0.012), 0.007, 0.006, STEEL)
            part(ball(0.027, 8, 6), IRON, 'out', T(*h), bevel=0, gloss=0.4)
            part(cyl(0.025, 0.03, 8), DARK, 'out', aim(lerp(f, h, 0.12), h), bevel=0, gloss=0.4)
        fa, fb = on_roof(feet[0][0], 2.6) @ Vector((0, 0, 0.012)), on_roof(feet[1][0], 2.6) @ Vector((0, 0, 0.012))
        part(tube([lerp(fa, heads[0], 0.45), lerp(fb, heads[1], 0.45)], 0.01, 6, 1), IRON, 'out', bevel=0, gloss=0.4)
        # what feeds it: a pipe up out of the roof through a flange, a valve, a length lagged against the heat, into the pump
        g = on_roof(th + 0.1, 2.3, 0.0)
        flange(g @ T(0, 0, 0.007), 0.042, 5, 0.014, BRASS, 0.6)
        g0 = g @ Vector((0, 0, 0.01))
        pts = [g0, g0 + Vector((0, 0, 0.13)), P(th + 0.075, 2.62, 3.8), P(th + 0.02, 2.9, 3.93), c + Vector((0, 0, 0.36)), c + Vector((0, 0, 0.232))]
        wh, L = pipe(pts, 0.014, COPPER, unions=(0.1, 0.52, 0.93), sub=4)
        p, d = wh(0.3); valve(p, d, 0.014, (0, 0, 1), RED)
        lagging([wh(u)[0] for u in (0.58, 0.66, 0.74, 0.82, 0.88)], 0.025, ties=4, sub=1)
        # a small bottle for the pressure, strapped to a board on the roof beside it, and piped in
        b = on_roof(th - 0.1, 2.26, 0.0)
        part(box(0.2, 0.26, 0.02), WOOD_D, 'out', b @ T(0, 0, 0.01), bevel=0.004, jit=0.06)
        Bt = b @ T(0, 0, 0.02)
        part(lathe([(0, 0), (0.058, 0), (0.066, 0.015), (0.066, 0.19), (0.05, 0.235), (0.02, 0.255), (0.02, 0.275), (0, 0.275)], 12), '#6c9a94', 'out', Bt, bevel=0, gloss=0.4, mat='enamel', jit=0.05)
        for z in (0.05, 0.16): band(Bt, 0.066, z - 0.01, z + 0.01, 0.005, 12, IRON, 0.4)
        part(cyl(0.026, 0.02, 6), BRASS, 'out', Bt @ T(0, 0, 0.285), bevel=0, gloss=0.6)
        pipe([Bt @ Vector((0, 0, 0.29)), Bt @ Vector((0.03, 0.02, 0.36)), lerp(Bt @ Vector((0, 0, 0.3)), wh(0.2)[0], 0.6) + Vector((0, 0, 0.05)), wh(0.2)[0]], 0.007, COPPER, sub=4, n=6)
        # its wire, along the third strut in two clips, from a gland in the roof
        w0 = on_roof(th, 2.36, 0.0) @ Vector((0.05, 0, 0.01)); f3 = on_roof(th, 2.42, 0.04) @ Vector((0, 0, 0.012))
        part(cyl(0.014, 0.024, 8), BRASS, 'out', on_roof(th, 2.36, 0.012) @ T(0.05, 0, 0), bevel=0, gloss=0.6)
        cable([w0, w0 + Vector((0, 0, 0.06)), lerp(f3, heads[2], 0.25) + Vector((0, 0, 0.026)), lerp(f3, heads[2], 0.8) + Vector((0, 0, 0.026)), heads[2] + Vector((0, 0, 0.03))], 0.005, '#2a2422', sub=3)
        for u in (0.3, 0.7):
            q = lerp(f3, heads[2], u)
            ring(aim(q, heads[2]), 0.021, 0.004, 8, STEEL, 0.6, sides=4)


# ====================================================================== more again: colour in masses, bulk, and use
# What stands out from across a field is colour and shape: a cream locker and a red bottle by the door, boots on a
# shelf, a slate of chalk marks, a green butt under the downpipe, the door's posts and the ladder's rails in
# warning stripes, a rack of crates under the window, two bottles of gas piped up to a pod, bulbs strung under the
# eave, an awning rolled and stowed over the door, a spare bell, flags on a halyard, washing on a line.
OCHRE, GREENP, LINEN = '#c8962f', '#5f7d6a', '#ddd2b6'


def more3():
    door_stripes(); locker(); fire_bottle(); boots(); slate(); water_butt(); ladder_poles(); crate_rack(); new_stave()
    gas_bottles(); eave_bulbs(); awning_stowed(); spare_bell(); flags(); washing(); leg_bands(); bath(); gaff()


def screws(M, pts, r=0.005, col=None):
    """Screw heads on a face (M as wall(): they look out along its -Y), at places (x, y, z) in it."""
    for x, y, z in pts: part(cyl(r, 0.004, 6), col or STEEL, 'out', M @ T(x, y - 0.0015, z) @ YA, bevel=0, gloss=0.6)


def door_stripes():
    """A board in warning stripes up the face of each door post, between its irons."""
    for sgn in (-1, 1):
        Mp = out_at(pi - sgn * asin(0.60 / 2.47), 2.594, 2.085)
        part(box(0.096, 0.012, 1.3), RED, 'out', Mp @ T(0, -0.003, 0), bevel=0.003, mat='stripe', jit=0.03)
        screws(Mp, [(sx * 0.034, -0.009, z) for z in (-0.58, -0.2, 0.2, 0.58) for sx in (-1, 1)])


def locker():
    """By the door, on the right: a cream locker for stores on two battens, its door slit to breathe, a hasp and a padlock, a lid of tin."""
    M = wall(150.2, 1.51, 0.0)
    for x in (-0.14, 0.14): part(box(0.045, 0.034, 0.7), WOOD_D, 'out', M @ T(x, -0.013, 0), bevel=0.005, jit=0.06)
    B = M @ T(0, -0.03, 0)
    part(box(0.40, 0.15, 0.62), ENAMEL, 'out', B @ T(0, -0.075, 0), bevel=0.008, gloss=0.3, mat='enamel', jit=0.03)
    F = B @ T(0, -0.15, 0)
    part(box(0.35, 0.01, 0.56), ENAMEL, 'out', F @ T(0, -0.004, 0), bevel=0.003, gloss=0.3, mat='enamel', jit=0.05)
    # (a band of red across the door, and its name on that)
    part(box(0.35, 0.004, 0.09), RED, 'out', F @ T(0, -0.0105, 0.17), bevel=0, mat='enamel', gloss=0.3, jit=0.03)
    label('STORES', F @ T(0, -0.0135, 0.17), 0.19, 'out')
    screws(F, [(sx * 0.105, -0.0135, 0.17) for sx in (-1, 1)], 0.004, BRASS)
    for k in range(5): part(box(0.2, 0.004, 0.012), '#2a2b30', 'out', F @ T(-0.03, -0.0095, -0.02 - 0.03 * k) @ R(rad(25), 'X'), bevel=0, mat='iron')
    for z in (-0.2, 0.2):
        part(cyl(0.008, 0.075, 8), IRON, 'out', F @ T(-0.181, -0.009, z), bevel=0, gloss=0.4)
        part(box(0.06, 0.004, 0.03), IRON, 'out', F @ T(-0.146, -0.011, z), bevel=0, gloss=0.4)
        screws(F, [(-0.135, -0.013, z + dz) for dz in (-0.008, 0.008)], 0.0035)
    # (a T to turn, a hasp over a staple, a padlock hung in it)
    part(cyl(0.012, 0.028, 8), BRASS, 'out', F @ T(0.115, -0.023, 0.03) @ YA, bevel=0, gloss=0.6)
    part(box(0.014, 0.012, 0.075), BRASS, 'out', F @ T(0.115, -0.04, 0.03) @ R(0.35, 'Y'), bevel=0.003, gloss=0.6)
    part(box(0.07, 0.005, 0.03), BRASS, 'out', F @ T(0.168, -0.0115, -0.07), bevel=0.001, gloss=0.6)
    part(tube([(0.182, -0.012, -0.07), (0.182, -0.026, -0.068), (0.182, -0.03, -0.085), (0.182, -0.03, -0.1)], 0.004, 5, 2), STEEL, 'out', F, bevel=0, gloss=0.6)
    part(box(0.042, 0.018, 0.046), BRASS, 'out', F @ T(0.182, -0.03, -0.122) @ R(0.12, 'Y'), bevel=0.005, gloss=0.6)
    # (the lid: a sheet of tin, tipped to shed the rain, a rag left over its corner)
    part(box(0.45, 0.215, 0.008), '#8f948f', 'out', B @ T(0, -0.085, 0.322) @ R(rad(10), 'X'), bevel=0.002, gloss=0.4, mat='tin', jit=0.06)

    def rag(u, v):
        x = 0.06 + 0.12 * u
        if v < 0.5: y = -0.1 - 0.19 * v; z = 0.331 - (-0.085 - y) * 0.176
        else: y = -0.197 - 0.005 * sin(u * 6); z = 0.331 - 0.02 - (v - 0.5) * 0.24 * (0.75 + 0.25 * u)
        return (x, y, z + 0.004 * sin(u * 9 + v * 5))
    part(sheet(4, 6, rag, 0.005), '#b9652f', 'out', B, bevel=0, mat='cloth', sharp=80, jit=0.05)
    # (two bolts through each batten)
    screws(M, [(x, -0.03, z) for x in (-0.14, 0.14) for z in (-0.33, 0.33)], 0.007, IRON)


def fire_bottle():
    """Between the locker and the door: a red bottle against fire, strapped to a cream board, its horn clipped beside it."""
    M = wall(159.5, 1.76, 0.0)
    part(box(0.2, 0.02, 0.66), ENAMEL, 'out', M @ T(0, -0.008, 0), bevel=0.004, mat='pwood', jit=0.05)
    screws(M, [(sx * 0.08, -0.018, sz * 0.305) for sx in (-1, 1) for sz in (-1, 1)], 0.006, IRON)
    label('FIRE', M @ T(0, -0.0185, 0.275), 0.12, 'out')
    Bt = M @ T(-0.012, -0.088, -0.27)
    part(lathe([(0, 0), (0.05, 0), (0.064, 0.018), (0.064, 0.33), (0.052, 0.39), (0.024, 0.425), (0.022, 0.455), (0, 0.455)], 14), RED, 'out', Bt, bevel=0, gloss=0.4, mat='enamel', jit=0.03)
    part(cyl(0.072, 0.012, 12), IRON, 'out', Bt @ T(0, 0, -0.006), bevel=0.002, gloss=0.4)
    part(box(0.05, 0.075, 0.012), IRON, 'out', Bt @ T(0, 0.036, -0.006), bevel=0, gloss=0.4)
    for z in (0.09, 0.28):
        band(Bt, 0.064, z - 0.012, z + 0.012, 0.005, 14, IRON, 0.4)
        part(box(0.05, 0.03, 0.022), IRON, 'out', Bt @ T(0, 0.074, z), bevel=0, gloss=0.4)
        part(cyl(0.005, 0.02, 5), STEEL, 'out', Bt @ T(0, -0.074, z) @ YA, bevel=0, gloss=0.6)
        part(box(0.03, 0.005, 0.008), STEEL, 'out', Bt @ T(0, -0.084, z), bevel=0, gloss=0.6)
    part(cyl(0.026, 0.03, 8), BRASS, 'out', Bt @ T(0, 0, 0.47), bevel=0.003, gloss=0.6)
    part(box(0.1, 0.016, 0.01), BRASS, 'out', Bt @ T(-0.03, 0, 0.497) @ R(0.2, 'Y'), bevel=0.002, gloss=0.6)
    part(tube([(0.024, 0, 0.47), (0.07, -0.005, 0.46), (0.088, -0.005, 0.36), (0.086, -0.005, 0.22)], 0.008, 6, 3), RUBBER, 'out', Bt, bevel=0, mat='rubber')
    part(cyl(0.012, 0.1, 8, r2=0.03), DARK, 'out', Bt @ T(0.086, -0.005, 0.17) @ R(pi, 'X'), bevel=0, gloss=0.3)
    part(tube([(0.086, 0.076, 0.2), (0.086, 0.03, 0.2), (0.06, 0.0, 0.2), (0.086, -0.03, 0.2), (0.112, 0.0, 0.2), (0.1, 0.02, 0.2)], 0.003, 4, 2), STEEL, 'out', Bt, bevel=0, gloss=0.6)


def boot(M, lean=0.0):
    """A boot standing at M's origin, its toe along M's +X."""
    BOOT = '#4a3226'
    part(box(0.27, 0.095, 0.018), RUBBER, 'out', M @ T(0.08, 0, 0.021), bevel=0.006, mat='rubber')
    part(box(0.08, 0.09, 0.012), RUBBER, 'out', M @ T(-0.012, 0, 0.006), bevel=0.003, mat='rubber')
    part(box(0.11, 0.09, 0.012), RUBBER, 'out', M @ T(0.155, 0, 0.006), bevel=0.003, mat='rubber')
    part(ball(0.047, 12, 8, s=(2.55, 1.0, 0.95)), BOOT, 'out', M @ T(0.095, 0, 0.07), bevel=0, mat='leather', jit=0.04, rough=0.003, grit=18)
    Sh = M @ T(0, 0, 0.042) @ R(lean, 'Y')
    part(lathe([(0.043, 0.0), (0.049, 0.14), (0.057, 0.27), (0.051, 0.27), (0.043, 0.14), (0.036, 0.02)], 12, close=True), BOOT, 'out', Sh, bevel=0, mat='leather', jit=0.04, rough=0.004, grit=14)
    part(slab(0.056, 0.061, 0.215, 0.268, 0, 2 * pi, 12), LINEN, 'out', Sh, bevel=0, mat='cloth', jit=0.05)
    part(tube([(-0.055, -0.012, 0.262), (-0.066, 0, 0.3), (-0.055, 0.012, 0.262)], 0.004, 4, 2), BOOT, 'out', Sh, bevel=0, mat='leather')
    for k in range(4): part(tube([(0.062 + 0.018 * k, -0.03, 0.104), (0.066 + 0.018 * k, 0, 0.1185), (0.062 + 0.018 * k, 0.03, 0.104)], 0.003, 4, 2), LINEN, 'out', M, bevel=0, mat='rope')


def boots():
    """A shelf at the head of the ramp, and a pair of boots left on it."""
    S = wall(160.6, 1.10, 0.0)
    part(box(0.34, 0.22, 0.022), WOOD, 'out', S @ T(0, -0.11, 0), bevel=0.004, jit=0.08)
    for x in (-0.13, 0.13):
        part(box(0.024, 0.006, 0.12), IRON, 'out', S @ T(x, -0.004, -0.071), bevel=0, gloss=0.4)
        part(box(0.024, 0.2, 0.006), IRON, 'out', S @ T(x, -0.1, -0.014), bevel=0, gloss=0.4)
        part(tube([(x, -0.008, -0.125), (x, -0.19, -0.018)], 0.006, 5, 1), IRON, 'out', S, bevel=0, gloss=0.4)
        screws(S, [(x, -0.007, -0.05), (x, -0.007, -0.105)], 0.005)
    boot(S @ T(0.07, -0.065, 0.011) @ R(pi + 0.1, 'Z'), 0.06)
    boot(S @ T(0.085, -0.165, 0.011) @ R(pi - 0.22, 'Z'), -0.16)


def slate():
    """Under the door's lamp: a slate in a wooden frame, the trips out and home chalked on it, the chalk on a string."""
    M = wall(160.7, 2.48, 0.003)
    part(box(0.3, 0.014, 0.17), WOOD, 'out', M @ T(0, -0.007, 0), bevel=0.004, jit=0.08)
    label('o3_slate', M @ T(0, -0.0147, 0), 0.26, 'out')
    for x, w, h, z in ((0, 0.3, 0.022, 0.076), (0, 0.3, 0.022, -0.076)): part(box(w, 0.01, h), WOOD_D, 'out', M @ T(x, -0.017, z), bevel=0.003, jit=0.08)
    for x in (-0.14, 0.14): part(box(0.022, 0.01, 0.13), WOOD_D, 'out', M @ T(x, -0.017, 0), bevel=0.003, jit=0.08)
    part(tube([(-0.12, -0.012, 0.085), (0, -0.01, 0.16), (0.12, -0.012, 0.085)], 0.003, 4, 1), ROPE, 'out', M, bevel=0, mat='rope')
    part(cyl(0.006, 0.012, 6), DARK, 'out', M @ T(0, -0.006, 0.16) @ YA, bevel=0, gloss=0.3)
    part(tube([(-0.15, -0.014, 0.06), (-0.163, -0.018, -0.05), (-0.166, -0.016, -0.15)], 0.0018, 4, 2), ROPE, 'out', M, bevel=0, mat='rope')
    part(cyl(0.007, 0.045, 6), '#e8e4d6', 'out', M @ T(-0.166, -0.016, -0.172), bevel=0, mat='paint')


def water_butt():
    """Under the downpipe, by the ladder: a butt for the rain, painted green, on a board hung from the wall by four irons; a dipper on its rim."""
    C = at(rad(-159), RO + 0.27, 0); z0, z1 = 0.47, 1.0; zm = (z0 + z1) / 2
    part(lathe([(0, z0), (0.172, z0), (0.2, z0 + 0.14), (0.21, zm), (0.2, z1 - 0.13), (0.178, z1), (0.164, z1), (0.164, z1 - 0.09), (0, z1 - 0.09)], 18), GREENP, 'out', C, bevel=0, mat='pwood', jit=0.05)
    for z, r in ((z0 + 0.06, 0.1845), (zm - 0.09, 0.2035), (zm + 0.09, 0.204), (z1 - 0.06, 0.189)): band(C, r, z - 0.014, z + 0.014, 0.005, 18, IRON, 0.4, nb=1, br=0.006)
    part(cyl(0.1645, 0.004, 18), '#22373a', 'out', C @ T(0, 0, z1 - 0.06), bevel=0, gloss=0.7, mat='glassy')
    # (a tap low on its front, and what is in it on a plate)
    part(cyl(0.012, 0.07, 8), BRASS, 'out', C @ T(0, 0.212, z0 + 0.1) @ R(pi / 2, 'X'), bevel=0, gloss=0.6)
    part(cyl(0.009, 0.035, 8), BRASS, 'out', C @ T(0, 0.24, z0 + 0.086), bevel=0, gloss=0.6)
    part(box(0.012, 0.012, 0.05), RED, 'out', C @ T(0, 0.236, z0 + 0.13), bevel=0.003, mat='enamel')
    plate('RAIN', C @ T(0, 0.2145, zm + 0.01) @ R(pi, 'Z'), 0.1, pad=0.008, stand=0.006)
    # (what it stands on)
    part(box(0.5, 0.5, 0.028), WOOD_D, 'out', C @ T(0, 0, z0 - 0.014), bevel=0.005, jit=0.06)
    for x in (-0.2, 0.2):
        part(tube([(x, -0.262, 1.06), (x, -0.262, 0.975), (x, -0.226, 0.945), (x, -0.226, 0.872), (x, -0.25, 0.8), (x, -0.25, z0 - 0.036), (x, -0.19, z0 - 0.038)], 0.008, 6, 2), IRON, 'out', C, bevel=0, gloss=0.4)
        part(box(0.045, 0.006, 0.07), IRON, 'out', C @ T(x, -0.266, 1.03), bevel=0, gloss=0.4)
        bolt(C @ T(x, -0.263, 1.04) @ R(-pi / 2, 'X'), 0.007, 0.005, STEEL)
    for x in (-0.22, 0.22):
        a, b = C @ Vector((x, -0.25, 1.04)), C @ Vector((x, 0.225, z0 - 0.004))
        part(tube([a, b], 0.006, 5, 1), IRON, 'out', bevel=0, gloss=0.4)
        eye(C @ T(x, -0.268, 1.062) @ R(-pi / 2, 'X'), 0.012, 0.004)
        part(cyl(0.012, 0.016, 6), IRON, 'out', T(*b), bevel=0, gloss=0.4)
    # (the dipper)
    part(tube([(0.13, 0.11, z1 - 0.05), (0.13, 0.132, z1 + 0.012), (0.13, 0.158, z1 + 0.014), (0.13, 0.176, z1 - 0.03), (0.13, 0.19, z1 - 0.2)], 0.0045, 5, 3), COPPER, 'out', C, bevel=0, gloss=0.6)
    part(lathe([(0, 0), (0.034, 0), (0.04, 0.05), (0.036, 0.05), (0.031, 0.006), (0, 0.006)], 10), COPPER, 'out', C @ T(0.13, 0.226, z1 - 0.25), bevel=0, gloss=0.6)
    part(box(0.008, 0.03, 0.008), COPPER, 'out', C @ T(0.13, 0.202, z1 - 0.205), bevel=0, gloss=0.6)


def ladder_poles():
    """The ladder's rails are wound in warning stripes where a hand first takes them."""
    Ml = at(rad(-152), 0, 0)
    for sx in (-1, 1): part(tube([(sx * 0.17, RO + 0.09, 1.3), (sx * 0.17, RO + 0.09, 1.62), (sx * 0.17, RO + 0.09, 1.94)], 0.0178, 8, 1), RED, 'out', Ml, bevel=0, mat='stripe', jit=0.03)


def crate(M, w, d, h, col, mat='pwood', slats=3):
    """A crate standing on M's origin: boards with gaps between, a batten up each corner, a lid."""
    part(box(w - 0.014, d - 0.014, h - 0.01), '#1d1410', 'out', M @ T(0, 0, h / 2), bevel=0, mat='soot')
    hs = (h - 0.012) / slats
    for k in range(slats):
        z = (k + 0.5) * hs
        for sy in (-1, 1): part(box(w, 0.012, hs - 0.012), col, 'out', M @ T(0, sy * (d / 2 - 0.006), z), bevel=0.003, jit=0.1, mat=mat)
        for sx in (-1, 1): part(box(0.012, d - 0.024, hs - 0.012), col, 'out', M @ T(sx * (w / 2 - 0.006), 0, z), bevel=0.003, jit=0.1, mat=mat)
    for sx in (-1, 1):
        for sy in (-1, 1): part(box(0.035, 0.012, h - 0.012), col, 'out', M @ T(sx * (w / 2 - 0.0175), sy * (d / 2 + 0.006), (h - 0.012) / 2), bevel=0.003, jit=0.1, mat=mat)
    part(box(w + 0.006, d + 0.03, 0.012), col, 'out', M @ T(0, 0, h - 0.006), bevel=0.003, jit=0.1, mat=mat)


def crate_rack():
    """Under the window's left end: a shelf on two irons with a rail before it, a painted crate, a small one on that, a can of oil; a cord over the lot."""
    M = wall(-56.5, 1.38, 0.0)
    for y in (-0.085, -0.235): part(box(0.5, 0.14, 0.024), WOOD, 'out', M @ T(0, y, -0.012), bevel=0.004, jit=0.09)
    for x in (-0.19, 0.19):
        part(box(0.03, 0.006, 0.2), IRON, 'out', M @ T(x, -0.004, -0.124), bevel=0, gloss=0.4)
        part(box(0.03, 0.3, 0.006), IRON, 'out', M @ T(x, -0.16, -0.027), bevel=0, gloss=0.4)
        part(tube([(x, -0.008, -0.215), (x, -0.27, -0.032)], 0.007, 6, 1), IRON, 'out', M, bevel=0, gloss=0.4)
        screws(M, [(x, -0.007, -0.06), (x, -0.007, -0.19)], 0.006)
    part(tube([(-0.24, -0.3, -0.01), (-0.24, -0.3, 0.07), (0.24, -0.3, 0.07), (0.24, -0.3, -0.01)], 0.007, 6, 1), IRON, 'out', M, bevel=0, gloss=0.4)
    part(tube([(0.0, -0.3, -0.01), (0.0, -0.3, 0.07)], 0.006, 5, 1), IRON, 'out', M, bevel=0, gloss=0.4)
    A = M @ T(-0.095, -0.15, 0) @ R(0.05, 'Z')
    crate(A, 0.28, 0.24, 0.24, TEAL, 'pwood')
    label('o3_crate', A @ T(0, -0.1205, 0.117), 0.2, 'out')
    crate(M @ T(-0.08, -0.155, 0.24) @ R(-0.18, 'Z'), 0.2, 0.17, 0.12, HONEY, 'wood', 2)
    # (the can: pressed tin, a cap on a chain, a handle of three bars)
    K = M @ T(0.15, -0.15, 0) @ R(-0.12, 'Z')
    part(box(0.13, 0.2, 0.25), OCHRE, 'out', K @ T(0, 0, 0.125), bevel=0.02, seg=3, gloss=0.35, mat='tin', jit=0.04)
    for sx in (-1, 1): part(box(0.004, 0.13, 0.16), OCHRE, 'out', K @ T(sx * 0.066, 0, 0.125), bevel=0.0015, gloss=0.35, mat='tin', jit=0.06)
    part(cyl(0.022, 0.03, 8), OCHRE, 'out', K @ T(0, -0.06, 0.26), bevel=0, gloss=0.35, mat='tin')
    part(cyl(0.026, 0.014, 8), RED, 'out', K @ T(0, -0.06, 0.281), bevel=0.003, mat='enamel')
    for sx in (-0.03, 0.0, 0.03): part(tube([(sx, -0.02, 0.25), (sx, -0.01, 0.275), (sx, 0.06, 0.275), (sx, 0.07, 0.25)], 0.005, 5, 1), OCHRE, 'out', K, bevel=0, gloss=0.35, mat='tin')
    part(tube([(-0.09, -0.03, 0.0), (-0.09, -0.028, 0.25), (-0.088, -0.07, 0.374), (-0.088, -0.24, 0.374), (-0.09, -0.287, 0.25), (-0.09, -0.3, 0.07)], 0.0055, 5, 2), ROPE, 'out', M, bevel=0, mat='rope')
    eye(M @ T(-0.09, -0.002, 0.02) @ YA, 0.012, 0.004)


def new_stave():
    """Forward on the right a stave has been let in new, and is not yet tarred: the pot and its brush hang by it."""
    M = wall(54.0, 1.325, 0.003)
    part(box(0.108, 0.02, 0.58), '#c9a877', 'out', M @ T(0, -0.008, 0), bevel=0.004, mat='wood', jit=0.05)
    screws(M, [(sx * 0.03, -0.018, sz * 0.26) for sx in (-1, 1) for sz in (-1, 1)], 0.005, DARK)
    H = wall(51.9, 1.5, 0.0)
    part(tube([(0, -0.004, 0.02), (0, -0.07, 0.03), (0, -0.09, 0.005), (0, -0.09, -0.015)], 0.006, 5, 3), IRON, 'out', H, bevel=0, gloss=0.4)
    bolt(H @ T(0, 0, 0.02) @ YA, 0.011, 0.005)
    Pt = H @ T(0, -0.09, -0.2)
    part(lathe([(0, 0), (0.05, 0), (0.06, 0.11), (0.054, 0.11), (0.046, 0.01), (0, 0.01)], 12), '#1a1512', 'out', Pt, bevel=0, mat='soot')
    part(cyl(0.05, 0.004, 12), '#0c0a09', 'out', Pt @ T(0, 0, 0.085), bevel=0, gloss=0.7, mat='glassy')
    part(tube([(0.058 * cos(a), 0, 0.105 + 0.085 * sin(a)) for a in [i * pi / 8 for i in range(9)]], 0.003, 4, 1), STEEL, 'out', Pt, bevel=0, gloss=0.6)
    part(tube([(0.01, 0.01, 0.07), (0.05, -0.02, 0.2)], 0.008, 6, 1), WOOD, 'out', Pt, bevel=0)
    part(box(0.03, 0.012, 0.04), '#0c0a09', 'out', Pt @ T(0.004, 0.014, 0.05) @ R(0.3, 'Y'), bevel=0.002, mat='soot')


def gas_bottles():
    """On the right wall, aft: two bottles of gas on an iron shelf, strapped back, and their pipe along the wall, up over the eave and into the pod it feeds."""
    S = wall(121.35, 1.74, 0.0)
    part(box(0.44, 0.21, 0.012), IRON, 'out', S @ T(0, -0.105, -0.006), bevel=0.002, gloss=0.4)
    for x in (-0.185, 0.185):
        part(box(0.03, 0.006, 0.15), IRON, 'out', S @ T(x, -0.004, -0.085), bevel=0, gloss=0.4)
        part(tube([(x, -0.008, -0.15), (x, -0.19, -0.014)], 0.007, 6, 1), IRON, 'out', S, bevel=0, gloss=0.4)
        screws(S, [(x, -0.007, -0.04), (x, -0.007, -0.13)], 0.006)
    part(box(0.44, 0.006, 0.075), IRON, 'out', S @ T(0, -0.207, -0.0375), bevel=0, gloss=0.4)
    plate('GAS', S @ T(0, -0.2105, -0.04), 0.1, pad=0.008)
    for x, col in ((-0.095, OCHRE), (0.095, GREENP)):
        Bt = S @ T(x, -0.108, 0)
        part(lathe([(0, 0), (0.07, 0), (0.082, 0.018), (0.082, 0.5), (0.072, 0.58), (0.04, 0.645), (0.03, 0.66), (0.03, 0.7), (0, 0.7)], 14), col, 'out', Bt, bevel=0, gloss=0.35, mat='enamel', jit=0.04)
        part(slab(0.0815, 0.0845, 0.37, 0.45, 0, 2 * pi, 14), LINEN, 'out', Bt, bevel=0, mat='enamel', jit=0.04)
        band(Bt, 0.082, 0.2, 0.228, 0.005, 14, IRON, 0.4)
        part(box(0.05, 0.03, 0.026), IRON, 'out', Bt @ T(0, 0.093, 0.214), bevel=0, gloss=0.4)
        part(cyl(0.005, 0.02, 5), STEEL, 'out', Bt @ T(0, -0.092, 0.214) @ YA, bevel=0, gloss=0.6)
        part(cyl(0.022, 0.05, 8), BRASS, 'out', Bt @ T(0, 0, 0.725), bevel=0.003, gloss=0.6)
        part(cyl(0.005, 0.03, 5), STEEL, 'out', Bt @ T(0, 0, 0.765), bevel=0, gloss=0.6)
        W = Bt @ T(0, 0, 0.782)
        ring(W, 0.034, 0.005, 10, RED, 0.3, mat='enamel')
        for a in (0.3, 2.4, 4.5): part(tube([(0, 0, 0), (0.034 * cos(a), 0.034 * sin(a), 0)], 0.0035, 4, 1), RED, 'out', W, bevel=0, mat='enamel')
        # (out of the valve's back, to the wall, and up it to the pipe they share)
        pipe([Bt @ Vector((0, 0.018, 0.73)), Bt @ Vector((0, 0.06, 0.735)), Bt @ Vector((0, 0.086, 0.77)), Bt @ Vector((0, 0.086, 0.872))], 0.008, COPPER, sub=3, n=6, unions=(0.12,))
    ths = lambda x: 121.35 - x / (RO + 0.022) * 180 / pi
    a0, a1 = ths(0.095), ths(-0.095)
    rw = RO + 0.022; zp = 1.74 + 0.88
    pts = [P(rad(a0), rw, zp), P(rad((a0 + a1) / 2), rw, zp), P(rad(a1), rw, zp), P(rad(126), rw, zp), P(rad(129), rw, zp), P(rad(131.3), rw, zp), P(rad(132.2), rw, zp + 0.07), P(rad(132.3), rw, 2.9), P(rad(132.4), rw + 0.004, 3.13),
           P(rad(132.5), 2.76, 3.205), P(rad(132.3), 2.92, 3.27), P(rad(131.6), 2.975, 3.4), P(rad(131.0), 2.955, 3.55)]
    Mpod = at(rad(135), POD_R, POD_Z); boss = Mpod @ (Vector((-0.66, -0.66, 0.36)).normalized() * 0.15)
    out = (boss - Vector(Mpod.translation)).normalized()
    pts += [boss + out * 0.07, boss + out * 0.012]
    wh, L = pipe(pts, 0.011, COPPER, sub=4, unions=(0.3, 0.62, 0.9))
    clips(wh, (0.06, 0.2, 0.42, 0.5), radial, 0.011, 0.011)
    p, d = wh(0.36); valve(p, d, 0.012, radial(p), RED)
    part(cyl(0.024, 0.02, 8), BRASS, 'out', aim(boss + out * 0.0, boss + out), bevel=0.003, gloss=0.6)
    part(cyl(0.018, 0.02, 6), BRASS, 'out', aim(boss + out * 0.02, boss + out), bevel=0, gloss=0.6)


def eave_bulbs():
    """Small lamps on a wire, looped from rafter to rafter under the eave, round both sides toward the door."""
    cols = ('#ffd08a', '#ffb070', '#ffe6b0', '#ff9a6a')
    for sgn, ks, lit in ((1, (9, 10, 11, 12, 13), (118, 141)), (-1, (9, 10, 11, 12), (-124,))):
        tails = [sgn * (k + 0.5) * 11.25 for k in ks]
        pts = []
        for i, a in enumerate(tails):
            pts.append(P(rad(a), 2.83, 3.178))
            if i < len(tails) - 1: pts.append(P(rad(a + sgn * 5.625), 2.84, 3.085 + 0.012 * (i % 2)))
            part(tube([P(rad(a), 2.83, 3.2), P(rad(a), 2.83, 3.172)], 0.004, 4, 1), IRON, 'out', bevel=0, gloss=0.4)
        part(tube(pts, 0.0035, 4, 4), DARK, 'out', bevel=0, mat='rubber')
        way = crom([Vector(q) for q in pts], 4)
        for i, p in enumerate(way[2::3]):
            part(cyl(0.008, 0.016, 6), BRASS, 'out', T(p.x, p.y, p.z - 0.01), bevel=0, gloss=0.6)
            part(ball(0.02, 8, 6, s=(1, 1, 1.3)), cols[(i + (sgn > 0)) % 4], 'out', T(p.x, p.y, p.z - 0.04), bevel=0, glow=2.2)
        for a in lit: LIGHTS.append((P(rad(a), 2.84, 3.05), WARM, 10))


def awning_stowed():
    """On the roof over the door: the awning, rolled, in its stripes, strapped down on two chocks, its two poles beside it."""
    F = on_roof(rad(175), 2.45, 0.0); Fi = F.inverted(); Lr = 0.95; seg = Lr * 0.96 / 9
    stripes = lambda p: OCHRE if int(floor(((Fi @ p).x + Lr * 0.48) / seg + 100)) % 2 else LINEN
    part(soft(0.085, Lr, 14, 9, 0.05), stripes, 'out', F @ T(0, 0, 0.135) @ R(pi / 2, 'Y'), bevel=0, mat='canvas', rough=0.008, grit=9, jit=0.04)
    for x in (-0.3, 0.3):
        part(box(0.07, 0.3, 0.05), WOOD_D, 'out', F @ T(x, 0, 0.025), bevel=0.006, jit=0.06)
        for sy in (-1, 1): part(box(0.07, 0.05, 0.05), WOOD_D, 'out', F @ T(x, sy * 0.105, 0.07) @ R(sy * 0.5, 'X'), bevel=0.006, jit=0.06)
    side = F.to_3x3() @ Vector((1, 0, 0))
    for x in (-0.24, 0.24):
        strap([F @ Vector((x, -0.17, 0.004)), F @ Vector((x, -0.115, 0.14)), F @ Vector((x, -0.05, 0.222)), F @ Vector((x, 0.05, 0.222)), F @ Vector((x, 0.115, 0.14)), F @ Vector((x, 0.17, 0.004))], 0.036, side, 0.005, sub=3)
        part(box(0.046, 0.04, 0.012), BRASS, 'out', F @ T(x, 0.03, 0.229), bevel=0.003, gloss=0.6)
        for sy in (-1, 1): eye(F @ T(x, sy * 0.178, 0.0), 0.012, 0.004)
    for j, y in enumerate((-0.225, -0.262)):
        part(tube([(-0.6 + 0.03 * j, y, 0.056), (0.6 + 0.03 * j, y, 0.056)], 0.016, 7, 1), HONEY, 'out', F, bevel=0, mat='wood', jit=0.08)
        for x in (-0.6, 0.6): part(cyl(0.018, 0.04, 7), BRASS, 'out', F @ T(x + 0.03 * j + (0.012 if x > 0 else -0.012), y, 0.056) @ R(pi / 2, 'Y'), bevel=0, gloss=0.6)
    for x in (-0.42, 0.42):
        part(box(0.05, 0.11, 0.04), WOOD_D, 'out', F @ T(x, -0.2435, 0.02), bevel=0.005, jit=0.06)
        for i in range(3): ring(F @ T(x + 0.03 + 0.008 * i, -0.2435, 0.056) @ R(pi / 2, 'Y'), 0.038, 0.004, 9, ROPE, 0, mat='rope', sides=4)


def spare_bell():
    """On the roof, to the left: a spare bell for a jet, new and bright, bunged, in a cradle under two straps."""
    F = on_roof(rad(-92), 2.2, 0.0)
    for y in (-0.11, 0.11): part(box(0.42, 0.05, 0.045), WOOD_D, 'out', F @ T(0, y, 0.0225), bevel=0.006, jit=0.06)
    for x in (-0.12, 0.1):
        for sy in (-1, 1): part(box(0.05, 0.06, 0.07), WOOD, 'out', F @ T(x, sy * 0.1, 0.07) @ R(sy * 0.6, 'X'), bevel=0.006, jit=0.08)
    k = 1.35
    prof = [(0.04, 0), (0.05, 0.05), (0.085, 0.14), (0.1, 0.2), (0.092, 0.2), (0.078, 0.14), (0.042, 0.05), (0.03, 0)]
    Mb = F @ T(-0.14, 0, 0.045 + 0.1 * k + 0.012) @ R(pi / 2, 'Y')
    part(lathe([(r * k, z * k) for r, z in prof], 18, close=True), COPPER, 'out', Mb, bevel=0, gloss=0.65, jit=0.03)
    for z, r in ((0.075, 0.06), (0.14, 0.085)): part(slab(r * k - 0.001, r * k + 0.006, z * k - 0.007, z * k + 0.007, 0, 2 * pi, 18), BRASS, 'out', Mb, bevel=0, gloss=0.6)
    part(cyl(0.064 * k, 0.03, 12), IRON, 'out', Mb, bevel=0.004, gloss=0.4)
    part(cyl(0.089 * k, 0.03, 12, r2=0.094 * k), HONEY, 'out', Mb @ T(0, 0, 0.195 * k), bevel=0.004, mat='wood', jit=0.08)
    part(tube([(-0.02, 0, 0.215 * k), (-0.02, 0, 0.25 * k), (0.02, 0, 0.25 * k), (0.02, 0, 0.215 * k)], 0.005, 5, 1), ROPE, 'out', Mb, bevel=0, mat='rope')
    side = F.to_3x3() @ Vector((1, 0, 0))
    for x, rr in ((-0.06, 0.075), (0.07, 0.122)):
        zc = 0.045 + 0.1 * k + 0.012
        strap([F @ Vector((x, -0.2, 0.004)), F @ Vector((x, -rr - 0.012, zc - 0.02)), F @ Vector((x, -rr * 0.6, zc + rr * 0.85)), F @ Vector((x, 0, zc + rr + 0.008)), F @ Vector((x, rr * 0.6, zc + rr * 0.85)), F @ Vector((x, rr + 0.012, zc - 0.02)), F @ Vector((x, 0.2, 0.004))], 0.03, side, 0.005, sub=3)
        for sy in (-1, 1): eye(F @ T(x, sy * 0.208, 0.0), 0.012, 0.004)
    plate('SPARES', F @ T(0.15, 0.1355, 0.0225) @ R(pi, 'Z'), 0.09, pad=0.007)


def pennant(p, d, w, h, col, kind=0, seed=0.0, nv=4):
    """A flag hung by its head from a line at p (the line runs along d): square, or cut to a point, or swallow-tailed."""
    d = Vector(d).normalized(); n = Vector((d.y, -d.x, 0)).normalized()

    def fn(u, v):
        ww = w * (1 - v) if kind == 1 else w
        z = v * h * ((1 - 0.35 * (1 - abs(u - 0.5) * 2)) if (kind == 2 and v > 0.99) else 1)
        return p + d * (u - 0.5) * ww + Vector((0, 0, -0.012 - z)) + n * 0.014 * sin(v * 5 + u * 3 + seed)
    part(sheet(4, nv, fn, 0.003), col, 'out', bevel=0, mat='cloth', sharp=80, jit=0.04)


def flags():
    """A halyard from the mast down to a stanchion at the eave on the left, and six flags on it."""
    top = Vector((0, 0, 5.0)); foot = P(rad(-120), 2.7, zr(2.7)); end = foot + Vector((0, 0, 0.62))
    part(tube([foot, end], 0.012, 6, 1), IRON, 'out', bevel=0, gloss=0.4)
    Fr = on_roof(rad(-120), 2.7, 0.0)
    part(cyl(0.045, 0.01, 10), IRON, 'out', Fr @ T(0, 0, 0.005), bevel=0, gloss=0.4)
    for j in range(3): bolt(Fr @ R(j * 2.094 + 0.4, 'Z') @ T(0.032, 0, 0.01), 0.006, 0.005, STEEL)
    part(tube([end - Vector((0, 0, 0.2)), P(rad(-120), 2.48, zr(2.48) + 0.01)], 0.006, 5, 1), IRON, 'out', bevel=0, gloss=0.4)
    part(ball(0.018, 8, 6), BRASS, 'out', T(*end), bevel=0, gloss=0.6)
    ring(T(0, 0, 5.0), 0.03, 0.005, 8, BRASS, 0.6)
    line = lambda u: lerp(top, end, u) + Vector((0, 0, -0.1 * sin(pi * u)))
    part(tube([line(i / 14) for i in range(15)], 0.003, 4, 1), ROPE, 'out', bevel=0, mat='rope')
    cols = (RED, LINEN, OCHRE, TEAL, RED, LINEN)
    for i, col in enumerate(cols):
        u = 0.2 + 0.115 * i
        pennant(line(u), line(u + 0.02) - line(u - 0.02), 0.2, 0.22, col, (0, 2, 1, 0, 1, 2)[i], i * 1.7)


def washing():
    """A line from the mast to a post at the eave on the right, and the wash pegged out on it."""
    top = Vector((0, 0, 4.86)); foot = P(rad(97), 2.6, zr(2.6)); end = foot + Vector((0, 0, 0.64))
    part(tube([foot, end], 0.012, 6, 1), IRON, 'out', bevel=0, gloss=0.4)
    Fr = on_roof(rad(97), 2.6, 0.0)
    part(cyl(0.045, 0.01, 10), IRON, 'out', Fr @ T(0, 0, 0.005), bevel=0, gloss=0.4)
    for j in range(3): bolt(Fr @ R(j * 2.094 + 0.4, 'Z') @ T(0.032, 0, 0.01), 0.006, 0.005, STEEL)
    part(tube([end - Vector((0, 0, 0.2)), P(rad(97), 2.38, zr(2.38) + 0.01)], 0.006, 5, 1), IRON, 'out', bevel=0, gloss=0.4)
    part(ball(0.018, 8, 6), BRASS, 'out', T(*end), bevel=0, gloss=0.6)
    ring(T(0, 0, 4.86), 0.031, 0.005, 8, BRASS, 0.6)
    line = lambda u: lerp(top, end, u) + Vector((0, 0, -0.08 * sin(pi * u)))
    part(tube([line(i / 14) for i in range(15)], 0.003, 4, 1), ROPE, 'out', bevel=0, mat='rope')
    d = (end - top).normalized()

    def peg(u):
        q = line(u); part(box(0.008, 0.012, 0.045), HONEY, 'out', T(q.x, q.y, q.z - 0.012), bevel=0, mat='wood', jit=0.1)

    def banded(p0, w, h):
        dh = Vector((d.x, d.y, 0)); k = dh.length_squared

        def col(p):
            s = (p - p0).dot(dh) / k
            v = (p0.z + d.z * s - 0.012 - p.z) / h
            return RED if 0.25 < v < 0.375 or 0.75 < v < 0.875 else LINEN
        return col
    # (a towel with two red bands, a cloth, a pair of socks, a cloth of faded blue)
    for u, w, h, col, nv in ((0.45, 0.3, 0.24, 'towel', 8), (0.6, 0.2, 0.24, OCHRE, 4), (0.73, 0.055, 0.2, RED, 4), (0.78, 0.055, 0.2, RED, 4), (0.3, 0.24, 0.2, '#6f8ea3', 4)):
        pennant(line(u), d, w, h, banded(line(u), w, h) if col == 'towel' else col, 0, u * 9, nv)
        for du in ((-0.35, 0.35) if w > 0.1 else (0.0,)): peg(u + du * w / (end - top).length)


def leg_bands():
    """A band of warning stripes round each leg's cylinder, where a head would meet it."""
    for th in (rad(45), rad(135), rad(-135), rad(-45)):
        top, foot = P(th, RO + 0.02, 1.78), P(th, 3.62, 0.17)
        part(slab(0.0855, 0.0915, 0.665, 0.8, 0, 2 * pi, 14), RED, 'out', aim(top, foot), bevel=0, mat='stripe', jit=0.03)


def bath():
    """On the roof, forward on the left: the bath, upside down over two bearers, lashed with two cords; its four feet in the air."""
    F = on_roof(rad(-42), 1.72, 0.0); A, B, H = 0.5, 0.26, 0.36
    for x in (-0.3, 0.3): part(box(0.05, 0.64, 0.05), WOOD_D, 'out', F @ T(x, 0, 0.025), bevel=0.006, jit=0.06)
    sg = lambda t: 1 if t >= 0 else -1

    def fn(u, v):
        a = 2 * pi * u; c, sn = cos(a), sin(a)
        s = cos(v * pi / 2) ** 0.45 if v < 0.999 else 0.0
        return (A * s * abs(c) ** 0.7 * sg(c), B * s * abs(sn) ** 0.7 * sg(sn), 0.05 + H * sin(v * pi / 2) ** 0.75)
    part(sheet(28, 8, fn), ENAMEL, 'out', F, bevel=0, gloss=0.3, mat='enamel', jit=0.03, sharp=60)
    part(tube([fn(i / 28, 0) for i in range(28)], 0.014, 6, 1, cyclic=True), '#b9b29c', 'out', F, bevel=0, gloss=0.3, mat='enamel')
    for sx in (-1, 1):
        for sy in (-1, 1): part(cyl(0.03, 0.07, 8, r2=0.016), IRON, 'out', F @ T(sx * 0.28, sy * 0.13, 0.4) @ R(sx * 0.2, 'Y') @ R(-sy * 0.2, 'X'), bevel=0.003, gloss=0.4)
    part(cyl(0.026, 0.006, 10), BRASS, 'out', F @ T(0.3, 0, 0.395) @ R(0.28, 'Y'), bevel=0, gloss=0.6)
    for x in (-0.17, 0.15):
        part(tube([(x, -0.37, 0.012), (x, -0.275, 0.2), (x, -0.2, 0.378), (x, 0, 0.424), (x, 0.2, 0.378), (x, 0.275, 0.2), (x, 0.37, 0.012)], 0.006, 5, 3), ROPE, 'out', F, bevel=0, mat='rope')
        for sy in (-1, 1): eye(F @ T(x, sy * 0.375, 0.0), 0.012, 0.004)


def gaff():
    """Under the eave on the left, on two hooks: a long gaff, painted in bands, a brass hook at its end."""
    a0, a1, r, z = -107.0, -123.0, RO + 0.11, 3.12
    A, B = P(rad(a0), r, z), P(rad(a1), r, z)
    n = 6
    for i in range(n):
        part(tube([lerp(A, B, i / n), lerp(A, B, (i + 1) / n)], 0.017, 8, 1), RED if i % 2 == 0 else LINEN, 'out', bevel=0, mat='pwood', jit=0.05)
    d = (A - B).normalized()
    part(cyl(0.019, 0.05, 8), BRASS, 'out', aim(A, A + d), bevel=0, gloss=0.6)
    part(tube([A + d * 0.02, A + d * 0.1, A + d * 0.13 + Vector((0, 0, -0.03)), A + d * 0.1 + Vector((0, 0, -0.06)), A + d * 0.07 + Vector((0, 0, -0.05))], 0.006, 5, 3), BRASS, 'out', bevel=0, gloss=0.6)
    part(cyl(0.019, 0.03, 8), BRASS, 'out', aim(B, B - d), bevel=0, gloss=0.6)
    for a in (-110.5, -119.5):
        M = wall(a, z, 0.0)
        part(tube([(0, -0.004, 0.05), (0, -0.05, 0.03), (0, -0.075, -0.01), (0, -0.092, -0.022), (0, -0.112, -0.005), (0, -0.115, 0.02)], 0.006, 5, 3), IRON, 'out', M, bevel=0, gloss=0.4)
        bolt(M @ T(0, 0, 0.05) @ YA, 0.011, 0.005)

